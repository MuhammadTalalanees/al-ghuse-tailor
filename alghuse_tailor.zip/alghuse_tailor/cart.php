<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header('location:login.php');
    exit;
}

// Remove item
if (isset($_GET['remove'])) {
    $cart_id = (int)$_GET['remove'];
    $conn->query("DELETE FROM cart WHERE cart_id='$cart_id' AND user_id='$user_id'");
    $message[] = 'Item removed from cart';
    header('location:cart.php'); exit;
}

// Update quantity
if (isset($_POST['update_qty'])) {
    foreach ($_POST['qty'] as $cid => $qty) {
        $cid = (int)$cid; $qty = max(1,(int)$qty);
        $item = mysqli_fetch_assoc($conn->query("SELECT price FROM cart WHERE cart_id='$cid' AND user_id='$user_id'"));
        if ($item) {
            $total = $item['price'] * $qty;
            $conn->query("UPDATE cart SET quantity='$qty', total='$total' WHERE cart_id='$cid'");
        }
    }
    $message[] = 'Cart updated!';
}

// Clear cart
if (isset($_GET['clear'])) {
    $conn->query("DELETE FROM cart WHERE user_id='$user_id'");
    header('location:cart.php'); exit;
}

$cart_items  = $conn->query("SELECT * FROM cart WHERE user_id='$user_id' ORDER BY cart_id DESC");
$grand_total = 0;
$cart_arr    = [];
while ($row = mysqli_fetch_assoc($cart_items)) {
    $cart_arr[]   = $row;
    $grand_total += $row['total'];
}

$page_title  = 'My Cart';
$active_page = '';
include 'includes/head.php';
?>
<style>
    .cart-wrap { max-width:1200px; margin:auto; padding:48px 24px 72px; display:grid; grid-template-columns:1fr 360px; gap:36px; align-items:start; }
    .cart-table-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; }
    .cart-table-head { background:var(--cream); padding:14px 24px; display:grid; grid-template-columns:80px 1fr 120px 120px 100px 50px; gap:12px; align-items:center; }
    .cart-table-head span { font-size:10px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; color:var(--text-muted); }
    .cart-row { padding:16px 24px; display:grid; grid-template-columns:80px 1fr 120px 120px 100px 50px; gap:12px; align-items:center; border-top:1px solid var(--border); transition:background 0.2s; }
    .cart-row:hover { background:var(--ivory); }
    .cart-img { width:72px; height:88px; border-radius:6px; object-fit:cover; border:1px solid var(--border); }
    .cart-item-name { font-family:'Playfair Display',serif; font-size:14px; font-weight:500; color:var(--charcoal); margin-bottom:4px; }
    .cart-item-name a { color:inherit; text-decoration:none; }
    .cart-item-name a:hover { color:var(--maroon); }
    .cart-item-fabric { font-size:11px; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; }
    .cart-size-badge { display:inline-flex; align-items:center; gap:4px; background:var(--cream); color:var(--maroon); font-size:10px; font-weight:700; padding:3px 10px; border-radius:20px; letter-spacing:0.5px; text-transform:uppercase; margin-top:5px; }
    .cart-size-badge.custom { background:var(--gold); color:#2C2C2A; }
    .cart-measure-toggle { font-size:11px; color:var(--maroon); text-decoration:underline; cursor:pointer; margin-top:4px; display:inline-block; }
    .cart-measure-details { font-size:11px; color:var(--text-mid); margin-top:6px; background:var(--ivory); border:1px solid var(--border); border-radius:6px; padding:8px 10px; display:none; }
    .cart-measure-details.show { display:block; }
    .cart-unit-price { font-size:14px; font-weight:500; color:var(--text-mid); }
    .cart-qty-input { width:64px; border:1px solid var(--border); border-radius:6px; padding:7px 10px; font-size:13px; text-align:center; background:var(--ivory); }
    .cart-qty-input:focus { border-color:var(--maroon); outline:none; }
    .cart-item-total { font-size:14px; font-weight:700; color:var(--maroon); }
    .btn-remove { background:none; border:none; color:var(--text-muted); font-size:18px; cursor:pointer; transition:color 0.2s; }
    .btn-remove:hover { color:var(--maroon); }
    .cart-actions-row { display:flex; justify-content:space-between; align-items:center; padding:16px 24px; border-top:1px solid var(--border); background:var(--cream); flex-wrap:wrap; gap:12px; }
    .btn-update { background:transparent; border:1.5px solid var(--maroon); color:var(--maroon); border-radius:6px; padding:9px 20px; font-size:12px; font-weight:600; cursor:pointer; transition:all 0.2s; }
    .btn-update:hover { background:var(--maroon); color:var(--white); }
    .btn-clear-cart { background:transparent; border:1px solid var(--border); color:var(--text-muted); border-radius:6px; padding:9px 16px; font-size:12px; cursor:pointer; text-decoration:none; transition:all 0.2s; }
    .btn-clear-cart:hover { border-color:var(--maroon); color:var(--maroon); }
    /* Summary Card */
    .summary-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; position:sticky; top:88px; }
    .summary-head { background:var(--maroon); padding:18px 24px; }
    .summary-head h3 { font-family:'Playfair Display',serif; font-size:18px; color:var(--white); }
    .summary-body { padding:24px; }
    .summary-row { display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; }
    .summary-label { font-size:13px; color:var(--text-mid); }
    .summary-value { font-size:13px; font-weight:600; color:var(--charcoal); }
    .summary-divider { border:none; border-top:1px solid var(--border); margin:16px 0; }
    .summary-total-row { display:flex; justify-content:space-between; align-items:center; }
    .summary-total-label { font-size:15px; font-weight:700; color:var(--charcoal); }
    .summary-total-val { font-size:22px; font-weight:700; color:var(--maroon); }
    .promo-input { display:flex; gap:8px; margin-bottom:20px; }
    .promo-input input { flex:1; border:1px solid var(--border); border-radius:6px; padding:9px 12px; font-size:13px; background:var(--ivory); }
    .promo-input input:focus { border-color:var(--maroon); outline:none; }
    .promo-input button { background:var(--gold); color:var(--charcoal); border:none; border-radius:6px; padding:9px 14px; font-size:12px; font-weight:700; cursor:pointer; transition:background 0.2s; }
    .promo-input button:hover { background:var(--gold-light); }
    .btn-checkout { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:14px; font-size:14px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; text-decoration:none; }
    .btn-checkout:hover { background:var(--maroon-dark); color:var(--white); }
    .btn-wa-order { width:100%; background:#25D366; color:var(--white); border:none; border-radius:6px; padding:13px; font-size:13px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; text-decoration:none; margin-top:10px; }
    .btn-wa-order:hover { background:#1ebe5d; color:var(--white); }
    .continue-shop { display:flex; align-items:center; gap:6px; font-size:12px; color:var(--maroon); text-decoration:none; font-weight:600; }
    .continue-shop:hover { color:var(--maroon-dark); }
    @media (max-width:900px) { .cart-wrap { grid-template-columns:1fr; } .summary-card { position:static; } .cart-table-head, .cart-row { grid-template-columns:60px 1fr 90px 80px; } .cart-table-head span:nth-child(5), .cart-table-head span:nth-child(6), .cart-row > *:nth-child(5), .cart-row > *:nth-child(6) { display:none; } }
</style>

<?php include 'includes/navbar.php'; ?>

<div class="page-hero">
    <div class="page-hero-inner">
        <p class="page-hero-eyebrow">Shopping</p>
        <h1>My Cart</h1>
    </div>
</div>
<div class="breadcrumb-bar">
    <div class="inner"><a href="index.php">Home</a> / Cart</div>
</div>

<div class="cart-wrap">

    <?php if (empty($cart_arr)): ?>
    <div class="empty-state" style="grid-column:1/-1">
        <i class="bi bi-bag-x"></i>
        <h3>Your cart is empty</h3>
        <p>No suits have been added to your cart yet.</p>
        <a href="shop.php">Start Shopping</a>
    </div>

    <?php else: ?>

    <!-- CART TABLE -->
    <div>
        <form method="POST" action="">
            <div class="cart-table-card">
                <div class="cart-table-head">
                    <span>Image</span>
                    <span>Product</span>
                    <span>Price</span>
                    <span>Qty</span>
                    <span>Total</span>
                    <span></span>
                </div>

                <?php foreach ($cart_arr as $i => $item):
                    $size = $item['size'] ?? 'M';
                    $is_custom = $size === 'Custom';
                    $measurements = null;
                    if ($is_custom && !empty($item['measurements'])) {
                        $measurements = json_decode($item['measurements'], true);
                    }
                ?>
                <div class="cart-row">
                    <img src="suits/<?= htmlspecialchars($item['image']) ?>" class="cart-img" alt="<?= htmlspecialchars($item['name']) ?>">

                    <div>
                        <div class="cart-item-name">
                            <a href="suit_detail.php?id=<?= $item['suit_id'] ?>"><?= htmlspecialchars($item['name']) ?></a>
                        </div>
                        <div class="cart-item-fabric">Suit #<?= $item['suit_id'] ?></div>
                        <br>
                        <span class="cart-size-badge <?= $is_custom ? 'custom' : '' ?>">
                            <i class="bi bi-tag-fill" style="font-size:9px;"></i> Size: <?= htmlspecialchars($size) ?>
                        </span>

                        <?php if ($is_custom && $measurements): ?>
                        <br>
                        <span class="cart-measure-toggle" onclick="document.getElementById('measure-<?= $item['cart_id'] ?>').classList.toggle('show')">
                            View Measurements
                        </span>
                        <div class="cart-measure-details" id="measure-<?= $item['cart_id'] ?>">
                            Chest: <?= htmlspecialchars($measurements['chest'] ?? '-') ?>" &nbsp;
                            Shoulder: <?= htmlspecialchars($measurements['shoulder'] ?? '-') ?>" &nbsp;
                            Length: <?= htmlspecialchars($measurements['length'] ?? '-') ?>"<br>
                            Sleeve: <?= htmlspecialchars($measurements['sleeve'] ?? '-') ?>" &nbsp;
                            Waist: <?= htmlspecialchars($measurements['waist'] ?? '-') ?>" &nbsp;
                            Hip: <?= htmlspecialchars($measurements['hip'] ?? '-') ?>"
                            <?php if (!empty($measurements['notes'])): ?>
                            <br><em>Note: <?= htmlspecialchars($measurements['notes']) ?></em>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="cart-unit-price">PKR <?= number_format($item['price']) ?></div>

                    <input type="number" name="qty[<?= $item['cart_id'] ?>]"
                           class="cart-qty-input" value="<?= $item['quantity'] ?>" min="1" max="10">

                    <div class="cart-item-total">PKR <?= number_format($item['total']) ?></div>

                    <a href="cart.php?remove=<?= $item['cart_id'] ?>" class="btn-remove" title="Remove"
                       onclick="return confirm('Remove this item?')"><i class="bi bi-trash"></i></a>
                </div>
                <?php endforeach; ?>

                <div class="cart-actions-row">
                    <div style="display:flex; gap:10px; align-items:center;">
                        <button type="submit" name="update_qty" class="btn-update">
                            <i class="bi bi-arrow-clockwise me-1"></i> Update Cart
                        </button>
                        <a href="cart.php?clear=1" class="btn-clear-cart"
                           onclick="return confirm('Clear the entire cart?')">Clear Cart</a>
                    </div>
                    <a href="shop.php" class="continue-shop">
                        <i class="bi bi-arrow-left"></i> Continue Shopping
                    </a>
                </div>
            </div>
        </form>
    </div>

    <!-- SUMMARY -->
    <div>
        <div class="summary-card">
            <div class="summary-head">
                <h3>Order Summary</h3>
            </div>
            <div class="summary-body">
                <div class="summary-row">
                    <span class="summary-label">Items (<?= count($cart_arr) ?>)</span>
                    <span class="summary-value">PKR <?= number_format($grand_total) ?></span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">Delivery Charges</span>
                    <span class="summary-value" style="color:green">Free</span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">Discount</span>
                    <span class="summary-value">— PKR 0</span>
                </div>

                <!-- Promo Code -->
                <div class="promo-input">
                    <input type="text" placeholder="Enter promo code">
                    <button type="button">Apply</button>
                </div>

                <hr class="summary-divider">
                <div class="summary-total-row">
                    <span class="summary-total-label">Total</span>
                    <span class="summary-total-val">PKR <?= number_format($grand_total) ?></span>
                </div>
                <hr class="summary-divider">

                <a href="checkout.php" class="btn-checkout">
                    <i class="bi bi-lock"></i> Proceed to Checkout
                </a>

                <?php
                $wa_items = implode('%0A', array_map(fn($i) => '• ' . urlencode($i['name']) . ' (' . urlencode($i['size'] ?? 'M') . ') x' . $i['quantity'], $cart_arr));
                ?>
                <a href="https://wa.me/923001234567?text=Hello!%20My%20order%3A%0A<?= $wa_items ?>%0ATotal%3A%20PKR%20<?= number_format($grand_total) ?>"
                   target="_blank" class="btn-wa-order">
                    <i class="bi bi-whatsapp"></i> Order via WhatsApp
                </a>
            </div>
        </div>
    </div>

    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>