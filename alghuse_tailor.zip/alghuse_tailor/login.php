<?php
include 'config.php';
error_reporting(0);
session_start();

if (isset($_SESSION['user_id'])) { header('location:index.php'); exit; }

if (isset($_POST['login'])) {
    $email    = $conn->real_escape_string(trim($_POST['email']));
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $message[] = 'Please fill all fields';
    } else {
        $result = $conn->query("SELECT * FROM users WHERE email='$email'");
        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id']   = $user['user_id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_type'] = $user['user_type'];
                $message[] = 'Logged in! Welcome ' . $user['name'];

                if ($user['user_type'] === 'admin') {
                    header('location:admin/Admin_index.php'); exit;
                } else {
                    header('location:index.php'); exit;
                }
            } else {
                $message[] = 'Incorrect password';
            }
        } else {
            $message[] = 'This email is not registered';
        }
    }
}

$page_title  = 'Login';
$active_page = '';
include 'includes/head.php';
?>
<style>
    .auth-wrap { min-height: calc(100vh - 68px); display:flex; align-items:center; justify-content:center; padding:48px 24px; background:var(--ivory); }
    .auth-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow-md); width:100%; max-width:440px; }
    .auth-header { background:var(--maroon); padding:32px 36px; text-align:center; position:relative; overflow:hidden; }
    .auth-header::before { content:''; position:absolute; inset:0; background:repeating-linear-gradient(45deg,transparent,transparent 30px,rgba(255,255,255,0.03) 30px,rgba(255,255,255,0.03) 60px); }
    .auth-header-inner { position:relative; z-index:1; }
    .auth-logo { font-family:'Playfair Display',serif; font-size:22px; font-weight:700; color:var(--white); margin-bottom:6px; }
    .auth-logo span { color:var(--gold-light); }
    .auth-subtitle { font-size:13px; color:rgba(255,255,255,0.7); }
    .auth-body { padding:32px 36px; }
    .auth-tabs { display:flex; gap:0; margin-bottom:28px; border:1px solid var(--border); border-radius:6px; overflow:hidden; }
    .auth-tab { flex:1; padding:10px; text-align:center; font-size:13px; font-weight:600; color:var(--text-mid); text-decoration:none; transition:all 0.2s; }
    .auth-tab.active { background:var(--maroon); color:var(--white); }
    .auth-tab:not(.active):hover { background:var(--cream); }
    .form-group { margin-bottom:20px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-control { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus { border-color:var(--maroon); box-shadow:0 0 0 3px rgba(123,26,26,0.08); outline:none; }
    .input-icon-wrap { position:relative; }
    .input-icon-wrap .form-control { padding-right:42px; }
    .input-icon { position:absolute; right:12px; top:50%; transform:translateY(-50%); color:var(--text-muted); font-size:16px; cursor:pointer; }
    .btn-auth { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:13px; font-size:14px; font-weight:700; cursor:pointer; letter-spacing:0.4px; transition:background 0.2s; margin-top:8px; }
    .btn-auth:hover { background:var(--maroon-dark); }
    .auth-divider { display:flex; align-items:center; gap:12px; margin:20px 0; color:var(--text-muted); font-size:12px; }
    .auth-divider::before, .auth-divider::after { content:''; flex:1; height:1px; background:var(--border); }
    .btn-google { width:100%; background:var(--white); color:var(--charcoal); border:1.5px solid var(--border); border-radius:6px; padding:11px; font-size:13px; font-weight:600; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:10px; transition:border-color 0.2s; text-decoration:none; }
    .btn-google:hover { border-color:var(--maroon); }
    .forgot-link { font-size:12px; color:var(--maroon); text-decoration:none; float:right; margin-top:-4px; }
    .forgot-link:hover { text-decoration:underline; }
    .auth-footer { text-align:center; margin-top:20px; font-size:13px; color:var(--text-muted); }
    .auth-footer a { color:var(--maroon); text-decoration:none; font-weight:600; }
    .auth-footer a:hover { text-decoration:underline; }
    .error-msg { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; border-radius:6px; padding:10px 14px; font-size:13px; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
    .remember-row { display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; }
    .check-label { display:flex; align-items:center; gap:8px; font-size:13px; color:var(--text-mid); cursor:pointer; }
    .check-label input { accent-color:var(--maroon); }
</style>

<!-- Navbar (minimal - no trust strip) -->
<nav class="navbar-main">
    <div class="navbar-inner">
        <a href="index.php" class="brand-logo">AL-Ghuse <span>Tailor</span></a>
        <div></div>
        <a href="register.php" class="btn-login-nav">Register</a>
    </div>
</nav>

<?php if (isset($message)): ?>
    <?php foreach ($message as $msg): ?>
        <div class="toast-msg" id="toast-msg">
            <i class="bi bi-exclamation-circle-fill"></i>
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<div class="auth-wrap">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-header-inner">
                <div class="auth-logo">AL-Ghuse <span>Tailor</span></div>
                <p class="auth-subtitle">Welcome back!</p>
            </div>
        </div>
        <div class="auth-body">
            <!-- Tabs -->
            <div class="auth-tabs">
                <a href="login.php"    class="auth-tab active">Login</a>
                <a href="register.php" class="auth-tab">Register</a>
            </div>

            <?php if (isset($message)): ?>
            <div class="error-msg">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <?= htmlspecialchars($message[0]) ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <div class="input-icon-wrap">
                        <input type="email" name="email" class="form-control" placeholder="your@email.com"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        <i class="bi bi-envelope input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Password</label>
                    <div class="input-icon-wrap">
                        <input type="password" name="password" id="pwd-field" class="form-control" placeholder="••••••••" required>
                        <i class="bi bi-eye input-icon" id="toggle-pwd" onclick="togglePwd()"></i>
                    </div>
                </div>

                <div class="remember-row">
                    <label class="check-label">
                        <input type="checkbox" name="remember"> Remember me
                    </label>
                    <a href="forgot_password.php" class="forgot-link">Forgot password?</a>
                </div>

                <button type="submit" name="login" class="btn-auth">
                    <i class="bi bi-box-arrow-in-right me-2"></i> Login
                </button>
            </form>

            <div class="auth-divider">OR</div>

            <a href="https://wa.me/923001234567?text=Hello!%20Main%20bina%20login%20ke%20order%20karna%20chahta%20hun"
               target="_blank" class="btn-google">
                <i class="bi bi-whatsapp" style="color:#25D366;font-size:18px;"></i>
                Order via WhatsApp
            </a>

            <div class="auth-footer">
                Don't have an account? <a href="register.php">Register</a>
            </div>
        </div>
    </div>
</div>

<a href="https://wa.me/923001234567" class="wa-float" target="_blank">
    <i class="bi bi-whatsapp"></i>
</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePwd() {
    const field = document.getElementById('pwd-field');
    const icon  = document.getElementById('toggle-pwd');
    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.replace('bi-eye','bi-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.replace('bi-eye-slash','bi-eye');
    }
}
setTimeout(() => {
    const t = document.getElementById('toast-msg');
    if (t) { t.style.opacity='0'; t.style.transition='opacity 0.5s'; setTimeout(()=>t.remove(),500); }
}, 5000);
</script>
</body>
</html>
