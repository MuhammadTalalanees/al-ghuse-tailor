<?php
$page_title = 'Contact Messages';
include 'includes/admin_header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM contact_messages WHERE msg_id='$id'");
    header('location: manage_messages.php'); exit;
}
if (isset($_GET['read'])) {
    $id = (int)$_GET['read'];
    $conn->query("UPDATE contact_messages SET is_read=1 WHERE msg_id='$id'");
    header('location: manage_messages.php'); exit;
}
?>

<div class="admin-card">
    <h5 class="mb-3">Contact Messages</h5>
    <table class="admin-table">
        <tr><th>Name</th><th>Email</th><th>Phone</th><th>Message</th><th>Date</th><th>Actions</th></tr>
        <?php
        $msgs = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
        if ($msgs && mysqli_num_rows($msgs) > 0):
            while ($m = mysqli_fetch_assoc($msgs)):
        ?>
        <tr style="<?= $m['is_read']==0 ? 'font-weight:600;background:#fffbea' : '' ?>">
            <td><?= htmlspecialchars($m['name']) ?></td>
            <td><?= htmlspecialchars($m['email']) ?></td>
            <td><?= htmlspecialchars($m['phone']) ?></td>
            <td style="max-width:300px"><?= htmlspecialchars($m['message']) ?></td>
            <td><?= date('d M Y', strtotime($m['created_at'])) ?></td>
            <td>
                <?php if (!$m['is_read']): ?>
                <a href="manage_messages.php?read=<?= $m['msg_id'] ?>" class="btn btn-sm btn-outline-secondary" title="Mark as read"><i class="bi bi-envelope-open"></i></a>
                <?php endif; ?>
                <a href="manage_messages.php?delete=<?= $m['msg_id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this message?')"><i class="bi bi-trash"></i></a>
            </td>
        </tr>
        <?php
            endwhile;
        else: ?>
        <tr><td colspan="6" class="text-center text-muted py-3">No messages yet</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include 'includes/admin_footer.php'; ?>
