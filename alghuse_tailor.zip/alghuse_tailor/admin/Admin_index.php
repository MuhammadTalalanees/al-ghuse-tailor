<?php
$page_title = 'Dashboard';
include 'includes/admin_header.php';

$total_suits    = mysqli_fetch_assoc($conn->query("SELECT COUNT(*) c FROM suits_info"))['c'];
$total_users    = mysqli_fetch_assoc($conn->query("SELECT COUNT(*) c FROM users WHERE user_type='user'"))['c'];
$total_orders   = mysqli_fetch_assoc($conn->query("SELECT COUNT(*) c FROM orders"))['c'];
$pending_orders = mysqli_fetch_assoc($conn->query("SELECT COUNT(*) c FROM orders WHERE status='Pending'"))['c'];
$total_msgs     = mysqli_fetch_assoc($conn->query("SELECT COUNT(*) c FROM contact_messages WHERE is_read=0"))['c'];
$revenue        = mysqli_fetch_assoc($conn->query("SELECT SUM(total_amount) t FROM orders WHERE status != 'Cancelled'"))['t'] ?? 0;
?>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="admin-card">
            <small class="text-muted">Total Suits</small>
            <h2><?= $total_suits ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="admin-card">
            <small class="text-muted">Total Customers</small>
            <h2><?= $total_users ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="admin-card">
            <small class="text-muted">Total Orders</small>
            <h2><?= $total_orders ?> <span class="text-warning" style="font-size:13px"><?= $pending_orders ?> pending</span></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="admin-card">
            <small class="text-muted">Unread Messages</small>
            <h2><?= $total_msgs ?></h2>
        </div>
    </div>
</div>

<div class="admin-card mb-4">
    <small class="text-muted">Total Revenue (excluding cancelled orders)</small>
    <h2>PKR <?= number_format($revenue) ?></h2>
</div>

<div class="admin-card">
    <h5 class="mb-3">Recent Orders</h5>
    <table class="admin-table">
        <tr><th>Order ID</th><th>Customer</th><th>Amount</th><th>Status</th><th>Date</th></tr>
        <?php
        $recent = $conn->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 5");
        if ($recent && mysqli_num_rows($recent) > 0):
            while ($o = mysqli_fetch_assoc($recent)):
        ?>
        <tr>
            <td>#<?= $o['order_id'] ?></td>
            <td><?= htmlspecialchars($o['name']) ?></td>
            <td>PKR <?= number_format($o['total_amount']) ?></td>
            <td><span class="badge-status badge-<?= $o['status'] ?>"><?= $o['status'] ?></span></td>
            <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
        </tr>
        <?php
            endwhile;
        else: ?>
        <tr><td colspan="5" class="text-center text-muted py-3">No orders yet</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include 'includes/admin_footer.php'; ?>
