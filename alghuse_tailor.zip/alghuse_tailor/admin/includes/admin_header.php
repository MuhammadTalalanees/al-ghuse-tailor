<?php
include '../config.php';
error_reporting(0);
session_start();

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('location: ../login.php');
    exit;
}

$admin_name   = $_SESSION['user_name'];
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $page_title ?? 'Admin Panel' ?> — AL-Ghuse Tailor</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<style>
:root{
  --maroon:#7B1A1A; --maroon-dark:#5C1010; --gold:#C9A84C; --gold-light:#E5C96C;
  --ivory:#FAF7F2; --cream:#F3EDE3; --charcoal:#2C2C2A; --text-mid:#5A5751;
  --text-muted:#9A9590; --white:#fff; --border:#E8E2D9; --radius:10px;
  --shadow-sm:0 1px 4px rgba(44,44,42,.08); --shadow-md:0 4px 20px rgba(44,44,42,.12);
}
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Inter',sans-serif;background:var(--ivory);color:var(--charcoal);}
.admin-wrap{display:flex;min-height:100vh;}
.admin-sidebar{width:250px;background:var(--charcoal);color:#fff;flex-shrink:0;padding:24px 0;}
.admin-logo{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,.08);margin-bottom:16px;}
.admin-logo span{color:var(--gold-light);}
.admin-nav{list-style:none;}
.admin-nav a{display:flex;align-items:center;gap:12px;padding:12px 24px;color:rgba(255,255,255,.7);text-decoration:none;font-size:13px;font-weight:500;letter-spacing:.3px;transition:background .2s,color .2s;border-left:3px solid transparent;}
.admin-nav a i{font-size:16px;width:18px;}
.admin-nav a:hover{background:rgba(255,255,255,.05);color:#fff;}
.admin-nav a.active{background:rgba(201,168,76,.12);color:var(--gold-light);border-left-color:var(--gold);}
.admin-main{flex:1;display:flex;flex-direction:column;min-width:0;}
.admin-topbar{background:#fff;border-bottom:1px solid var(--border);padding:16px 32px;display:flex;justify-content:space-between;align-items:center;}
.admin-topbar h1{font-family:'Playfair Display',serif;font-size:20px;font-weight:600;}
.admin-user{display:flex;align-items:center;gap:14px;font-size:13px;color:var(--text-mid);}
.admin-content{padding:32px;flex:1;}
.toast-msg{position:fixed;top:20px;right:20px;background:#fff;border:1.5px solid var(--gold);border-radius:var(--radius);padding:12px 20px;font-size:13px;color:var(--maroon);font-weight:500;box-shadow:var(--shadow-md);z-index:9999;}
.admin-card{background:#fff;border:1px solid var(--border);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow-sm);}
.btn-maroon{background:var(--maroon);color:#fff;border:none;border-radius:6px;padding:9px 18px;font-size:13px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px;}
.btn-maroon:hover{background:var(--maroon-dark);color:#fff;}
table.admin-table{width:100%;border-collapse:collapse;font-size:13px;}
table.admin-table th{background:var(--cream);text-align:left;padding:10px 14px;font-size:11px;letter-spacing:.5px;text-transform:uppercase;color:var(--text-mid);}
table.admin-table td{padding:10px 14px;border-bottom:1px solid var(--border);vertical-align:middle;}
table.admin-table img{width:44px;height:44px;object-fit:cover;border-radius:6px;}
.badge-status{padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;white-space:nowrap;}
.badge-Pending{background:#fef3c7;color:#92400e;}
.badge-Processing{background:#dbeafe;color:#1e40af;}
.badge-Shipped{background:#e0e7ff;color:#3730a3;}
.badge-Delivered{background:#dcfce7;color:#166534;}
.badge-Cancelled{background:#fee2e2;color:#991b1b;}
</style>
</head>
<body>
<?php if (isset($message)): foreach ($message as $msg): ?>
<div class="toast-msg" id="toast-msg"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($msg) ?></div>
<?php endforeach; endif; ?>
<div class="admin-wrap">
  <aside class="admin-sidebar">
    <div class="admin-logo">AL-Ghuse <span>Admin</span></div>
    <ul class="admin-nav">
      <li><a href="Admin_index.php" class="<?= $current_page=='Admin_index.php'?'active':'' ?>"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
      <li><a href="manage_suits.php" class="<?= $current_page=='manage_suits.php'?'active':'' ?>"><i class="bi bi-scissors"></i> Manage Suits</a></li>
      <li><a href="manage_orders.php" class="<?= $current_page=='manage_orders.php'?'active':'' ?>"><i class="bi bi-bag-check"></i> Orders</a></li>
      <li><a href="manage_messages.php" class="<?= $current_page=='manage_messages.php'?'active':'' ?>"><i class="bi bi-envelope"></i> Messages</a></li>
      <li><a href="manage_users.php" class="<?= $current_page=='manage_users.php'?'active':'' ?>"><i class="bi bi-people"></i> Users</a></li>
      <li><a href="../index.php"><i class="bi bi-globe"></i> View Site</a></li>
      <li><a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
  </aside>
  <div class="admin-main">
    <div class="admin-topbar">
      <h1><?= $page_title ?? 'Dashboard' ?></h1>
      <div class="admin-user"><i class="bi bi-person-circle"></i> <?= htmlspecialchars($admin_name) ?></div>
    </div>
    <div class="admin-content">
