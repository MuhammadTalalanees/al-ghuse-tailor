<?php
$page_title = 'Manage Users';
include 'includes/admin_header.php';
?>

<div class="admin-card">
    <h5 class="mb-3">Registered Customers</h5>
    <table class="admin-table">
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th></tr>
        <?php
        $users = $conn->query("SELECT * FROM users WHERE user_type='user' ORDER BY created_at DESC");
        while ($u = mysqli_fetch_assoc($users)):
        ?>
        <tr>
            <td><?= $u['user_id'] ?></td>
            <td><?= htmlspecialchars($u['name']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= htmlspecialchars($u['phone']) ?></td>
            <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/admin_footer.php'; ?>
