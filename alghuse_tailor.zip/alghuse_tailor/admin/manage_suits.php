<?php
$page_title = 'Manage Suits';
include 'includes/admin_header.php';

// DELETE SUIT
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM suits_info WHERE sid='$id'");
    header('location: manage_suits.php'); exit;
}

// ADD NEW SUIT
if (isset($_POST['add_suit'])) {
    $name        = $conn->real_escape_string(trim($_POST['name']));
    $category    = $conn->real_escape_string($_POST['category']);
    $fabric      = $conn->real_escape_string(trim($_POST['fabric']));
    $price       = (float)$_POST['price'];
    $description = $conn->real_escape_string(trim($_POST['description'] ?? ''));

    $image_name = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $ext        = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $image_name = 'suit_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], '../suits/' . $image_name);
    }

    $conn->query("INSERT INTO suits_info (name, category, fabric, price, image, description, date)
                  VALUES ('$name','$category','$fabric','$price','$image_name','$description', NOW())")
        or die('Insert failed: ' . $conn->error);

    $message[] = 'Suit added successfully!';
}

// EDIT SUIT
if (isset($_POST['edit_suit'])) {
    $sid      = (int)$_POST['sid'];
    $name     = $conn->real_escape_string(trim($_POST['name']));
    $category = $conn->real_escape_string($_POST['category']);
    $fabric   = $conn->real_escape_string(trim($_POST['fabric']));
    $price    = (float)$_POST['price'];

    $conn->query("UPDATE suits_info SET name='$name', category='$category', fabric='$fabric', price='$price' WHERE sid='$sid'")
        or die('Update failed: ' . $conn->error);

    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $ext        = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $image_name = 'suit_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], '../suits/' . $image_name);
        $conn->query("UPDATE suits_info SET image='$image_name' WHERE sid='$sid'");
    }

    $message[] = 'Suit updated successfully!';
}
?>

<div class="admin-card mb-4">
    <h5 class="mb-3"><i class="bi bi-plus-circle"></i> Add New Suit</h5>
    <form method="POST" enctype="multipart/form-data" class="row g-3">
        <div class="col-md-4">
            <label class="form-label">Suit Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="col-md-3">
            <label class="form-label">Category</label>
            <select name="category" class="form-select" required>
                <option value="Bridal">Bridal</option>
                <option value="Formal">Formal</option>
                <option value="Casual">Casual</option>
                <option value="Unstitched">Unstitched</option>
                <option value="Kids">Kids</option>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">Fabric</label>
            <input type="text" name="fabric" class="form-control" placeholder="e.g. Lawn">
        </div>
        <div class="col-md-2">
            <label class="form-label">Price (PKR)</label>
            <input type="number" name="price" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="2"></textarea>
        </div>
        <div class="col-md-4">
            <label class="form-label">Image</label>
            <input type="file" name="image" class="form-control" accept="image/*" required>
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <button type="submit" name="add_suit" class="btn-maroon w-100"><i class="bi bi-plus-lg"></i> Add Suit</button>
        </div>
    </form>
</div>

<div class="admin-card">
    <h5 class="mb-3">All Suits</h5>
    <table class="admin-table">
        <tr><th>Image</th><th>Name</th><th>Category</th><th>Fabric</th><th>Price</th><th>Actions</th></tr>
        <?php
        $suits = $conn->query("SELECT * FROM suits_info ORDER BY date DESC");
        while ($s = mysqli_fetch_assoc($suits)):
        ?>
        <tr>
            <td><img src="../suits/<?= htmlspecialchars($s['image']) ?>" alt=""></td>
            <td><?= htmlspecialchars($s['name']) ?></td>
            <td><?= htmlspecialchars($s['category']) ?></td>
            <td><?= htmlspecialchars($s['fabric']) ?></td>
            <td>PKR <?= number_format($s['price']) ?></td>
            <td>
                <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editModal<?= $s['sid'] ?>"><i class="bi bi-pencil"></i></button>
                <a href="manage_suits.php?delete=<?= $s['sid'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this suit?')"><i class="bi bi-trash"></i></a>
            </td>
        </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editModal<?= $s['sid'] ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Suit</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="sid" value="<?= $s['sid'] ?>">
                            <div class="mb-2">
                                <label class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($s['name']) ?>" required>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Category</label>
                                <select name="category" class="form-select">
                                    <?php foreach (['Bridal','Formal','Casual','Unstitched','Kids'] as $c): ?>
                                    <option value="<?= $c ?>" <?= $s['category']==$c?'selected':'' ?>><?= $c ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Fabric</label>
                                <input type="text" name="fabric" class="form-control" value="<?= htmlspecialchars($s['fabric']) ?>">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Price</label>
                                <input type="number" name="price" class="form-control" value="<?= $s['price'] ?>" required>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Replace Image (optional)</label>
                                <input type="file" name="image" class="form-control" accept="image/*">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" name="edit_suit" class="btn-maroon">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/admin_footer.php'; ?>
