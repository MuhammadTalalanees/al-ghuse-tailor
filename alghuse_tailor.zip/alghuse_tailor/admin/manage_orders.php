<?php
$page_title = 'Manage Orders';
include 'includes/admin_header.php';

if (isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status   = $conn->real_escape_string($_POST['status']);
    $conn->query("UPDATE orders SET status='$status' WHERE order_id='$order_id'");
    $message[] = 'Order status updated!';
}
?>

<div class="admin-card">
    <h5 class="mb-3">All Orders</h5>
    <table class="admin-table">
        <tr>
            <th></th><th>Order ID</th><th>Customer</th><th>Phone</th><th>City</th><th>Payment</th>
            <th>Amount</th><th>Status</th><th>Date</th><th>Action</th>
        </tr>
        <?php
        $orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
        if ($orders && mysqli_num_rows($orders) > 0):
            while ($o = mysqli_fetch_assoc($orders)):
        ?>
        <tr>
            <td>
                <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#items<?= $o['order_id'] ?>">
                    <i class="bi bi-chevron-down"></i>
                </button>
            </td>
            <td>#<?= $o['order_id'] ?></td>
            <td><?= htmlspecialchars($o['name']) ?></td>
            <td><?= htmlspecialchars($o['phone']) ?></td>
            <td><?= htmlspecialchars($o['city']) ?></td>
            <td><?= htmlspecialchars($o['payment_method']) ?></td>
            <td>PKR <?= number_format($o['total_amount']) ?></td>
            <td><span class="badge-status badge-<?= $o['status'] ?>"><?= $o['status'] ?></span></td>
            <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
            <td>
                <form method="POST" class="d-flex gap-1">
                    <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                    <select name="status" class="form-select form-select-sm">
                        <?php foreach (['Pending','Processing','Shipped','Delivered','Cancelled'] as $st): ?>
                        <option value="<?= $st ?>" <?= $o['status']==$st?'selected':'' ?>><?= $st ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="update_status" class="btn btn-sm btn-maroon"><i class="bi bi-check"></i></button>
                </form>
            </td>
        </tr>
        <tr class="collapse" id="items<?= $o['order_id'] ?>">
            <td colspan="10" style="background:var(--cream);padding:16px 24px;">
                <strong style="font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:var(--text-mid);">Order Items:</strong>
                <table class="admin-table mt-2" style="background:#fff;">
                    <tr><th>Suit</th><th>Qty</th><th>Size</th><th>Measurements</th><th>Item Total</th></tr>
                    <?php
                    $items = $conn->query("SELECT * FROM order_items WHERE order_id='{$o['order_id']}'");
                    while ($it = mysqli_fetch_assoc($items)):
                        $m = null;
                        if (!empty($it['measurements'])) {
                            $m = json_decode($it['measurements'], true);
                        }
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($it['name']) ?></td>
                        <td><?= $it['quantity'] ?></td>
                        <td><span class="badge-status" style="background:var(--gold);color:#2C2C2A;"><?= htmlspecialchars($it['size'] ?? 'M') ?></span></td>
                        <td>
                            <?php if ($m): ?>
                                Chest: <?= htmlspecialchars($m['chest'] ?? '-') ?>",
                                Shoulder: <?= htmlspecialchars($m['shoulder'] ?? '-') ?>",
                                Length: <?= htmlspecialchars($m['length'] ?? '-') ?>",
                                Sleeve: <?= htmlspecialchars($m['sleeve'] ?? '-') ?>",
                                Waist: <?= htmlspecialchars($m['waist'] ?? '-') ?>",
                                Hip: <?= htmlspecialchars($m['hip'] ?? '-') ?>"
                                <?php if (!empty($m['notes'])): ?><br><em>Note: <?= htmlspecialchars($m['notes']) ?></em><?php endif; ?>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <td>PKR <?= number_format($it['total']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </td>
        </tr>
        <?php
            endwhile;
        else: ?>
        <tr><td colspan="10" class="text-center text-muted py-3">No orders yet</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php include 'includes/admin_footer.php'; ?>
