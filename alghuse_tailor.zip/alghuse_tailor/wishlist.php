<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) { header('location:login.php'); exit; }

// Remove from wishlist
if (isset($_GET['remove'])) {
    $wish_id = (int)$_GET['remove'];
    $conn->query("DELETE FROM wishlist WHERE wish_id='$wish_id' AND user_id='$user_id'");
    header('location:wishlist.php'); exit;
}

// Move to cart
if (isset($_POST['move_to_cart'])) {
    $suit_id    = (int)$_POST['suit_id'];
    $suit_name  = $conn->real_escape_string($_POST['suit_name']);
    $suit_price = (float)$_POST['suit_price'];
    $suit_image = $conn->real_escape_string($_POST['suit_image']);
    $total      = $suit_price;
    $check = $conn->query("SELECT * FROM cart WHERE suit_id='$suit_id' AND user_id='$user_id'");
    if (mysqli_num_rows($check) === 0) {
        $conn->query("INSERT INTO cart (user_id,suit_id,name,price,image,quantity,total) VALUES ('$user_id','$suit_id','$suit_name','$suit_price','$suit_image','1','$total')");
    }
    $conn->query("DELETE FROM wishlist WHERE suit_id='$suit_id' AND user_id='$user_id'");
    $message[] = 'Moved to cart!';
}

$wishlist   = $conn->query("SELECT * FROM wishlist WHERE user_id='$user_id' ORDER BY added_at DESC");
$wish_count = mysqli_num_rows($wishlist);
// Re-query after possible update
$wishlist   = $conn->query("SELECT * FROM wishlist WHERE user_id='$user_id' ORDER BY added_at DESC");

$page_title  = 'My Wishlist';
$active_page = '';
include 'includes/head.php';
?>
<style>
    .wishlist-wrap { max-width:1200px; margin:auto; padding:48px 24px 72px; }
    .wish-header-row { display:flex; justify-content:space-between; align-items:center; margin-bottom:28px; padding-bottom:16px; border-bottom:1px solid var(--border); }
    .wish-header-row h2 { font-family:'Playfair Display',serif; font-size:28px; color:var(--charcoal); }
    .wish-count { font-size:13px; color:var(--text-muted); }
    .wishlist-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:24px; }
    .wish-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; transition:box-shadow 0.25s,transform 0.25s; position:relative; }
    .wish-card:hover { box-shadow:var(--shadow-md); transform:translateY(-3px); }
    .wish-img-wrap { height:280px; overflow:hidden; background:var(--cream); position:relative; }
    .wish-img-wrap img { width:100%; height:100%; object-fit:cover; transition:transform 0.4s; }
    .wish-card:hover .wish-img-wrap img { transform:scale(1.04); }
    .btn-remove-wish { position:absolute; top:10px; right:10px; width:32px; height:32px; background:var(--white); border:none; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:16px; color:var(--maroon); cursor:pointer; box-shadow:var(--shadow-sm); transition:all 0.2s; text-decoration:none; }
    .btn-remove-wish:hover { background:var(--maroon); color:var(--white); }
    .wish-added { position:absolute; top:10px; left:10px; background:var(--gold); color:var(--charcoal); font-size:9px; font-weight:700; padding:4px 10px; border-radius:4px; letter-spacing:0.8px; }
    .wish-body { padding:16px 18px 18px; }
    .wish-fabric { font-size:10px; letter-spacing:1.5px; text-transform:uppercase; color:var(--text-muted); margin-bottom:5px; }
    .wish-name { font-family:'Playfair Display',serif; font-size:16px; font-weight:500; color:var(--charcoal); margin-bottom:8px; }
    .wish-name a { color:inherit; text-decoration:none; }
    .wish-name a:hover { color:var(--maroon); }
    .wish-price { font-size:17px; font-weight:700; color:var(--maroon); margin-bottom:14px; }
    .wish-price .currency { font-size:11px; font-weight:400; color:var(--text-muted); }
    .wish-actions { display:flex; gap:8px; }
    .btn-move-cart { flex:1; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:9px 12px; font-size:12px; font-weight:600; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:5px; transition:background 0.2s; }
    .btn-move-cart:hover { background:var(--maroon-dark); }
    .btn-view-detail { border:1px solid var(--border); background:var(--white); color:var(--text-mid); border-radius:6px; padding:9px 12px; font-size:12px; font-weight:500; text-decoration:none; display:inline-flex; align-items:center; transition:all 0.2s; }
    .btn-view-detail:hover { border-color:var(--maroon); color:var(--maroon); }
</style>

<?php include 'includes/navbar.php'; ?>

<div class="page-hero">
    <div class="page-hero-inner">
        <p class="page-hero-eyebrow">Favorite Items</p>
        <h1>My Wishlist</h1>
    </div>
</div>
<div class="breadcrumb-bar">
    <div class="inner"><a href="index.php">Home</a> / Wishlist</div>
</div>

<div class="wishlist-wrap">
    <div class="wish-header-row">
        <h2>My Wishlist <span style="font-size:16px;color:var(--gold);">(<?= $wish_count ?>)</span></h2>
        <a href="shop.php" style="font-size:13px;color:var(--maroon);text-decoration:none;font-weight:600;">
            <i class="bi bi-arrow-left me-1"></i> Continue Shopping
        </a>
    </div>

    <?php if ($wish_count === 0): ?>
    <div class="empty-state">
        <i class="bi bi-heart"></i>
        <h3>Your wishlist is empty</h3>
        <p>Add suits you like to your wishlist using the heart button</p>
        <a href="shop.php">View Collection</a>
    </div>
    <?php else: ?>
    <div class="wishlist-grid">
        <?php while ($w = mysqli_fetch_assoc($wishlist)): ?>
        <div class="wish-card">
            <div class="wish-img-wrap">
                <img src="suits/<?= htmlspecialchars($w['image']) ?>" alt="<?= htmlspecialchars($w['name']) ?>" loading="lazy">
                <span class="wish-added"><i class="bi bi-heart-fill me-1"></i> Saved</span>
                <a href="wishlist.php?remove=<?= $w['wish_id'] ?>" class="btn-remove-wish"
                   title="Remove from wishlist" onclick="return confirm('Remove from wishlist?')">
                    <i class="bi bi-x-lg"></i>
                </a>
            </div>
            <div class="wish-body">
                <p class="wish-fabric">Suit</p>
                <h3 class="wish-name">
                    <a href="suit_detail.php?id=<?= $w['suit_id'] ?>&name=<?= urlencode($w['name']) ?>">
                        <?= htmlspecialchars($w['name']) ?>
                    </a>
                </h3>
                <div class="wish-price"><span class="currency">PKR</span><?= number_format($w['price']) ?></div>
                <div class="wish-actions">
                    <form method="POST" action="" style="flex:1;display:flex;">
                        <input type="hidden" name="suit_id"    value="<?= $w['suit_id'] ?>">
                        <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($w['name']) ?>">
                        <input type="hidden" name="suit_price" value="<?= $w['price'] ?>">
                        <input type="hidden" name="suit_image" value="<?= htmlspecialchars($w['image']) ?>">
                        <button type="submit" name="move_to_cart" class="btn-move-cart">
                            <i class="bi bi-bag-plus"></i> Add to Cart
                        </button>
                    </form>
                    <a href="suit_detail.php?id=<?= $w['suit_id'] ?>&name=<?= urlencode($w['name']) ?>" class="btn-view-detail">
                        <i class="bi bi-eye"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
