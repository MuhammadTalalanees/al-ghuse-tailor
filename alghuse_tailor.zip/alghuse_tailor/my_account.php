<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) { header('location:login.php'); exit; }

$user = mysqli_fetch_assoc($conn->query("SELECT * FROM users WHERE user_id='$user_id'"));

// Update profile
if (isset($_POST['update_profile'])) {
    $name    = $conn->real_escape_string(trim($_POST['name']));
    $phone   = $conn->real_escape_string(trim($_POST['phone']));
    $address = $conn->real_escape_string(trim($_POST['address']));
    $conn->query("UPDATE users SET name='$name', phone='$phone', address='$address' WHERE user_id='$user_id'");
    $_SESSION['user_name'] = $name;
    $message[] = 'Profile updated!';
    $user = mysqli_fetch_assoc($conn->query("SELECT * FROM users WHERE user_id='$user_id'"));
}

// Change password
if (isset($_POST['change_password'])) {
    $old  = trim($_POST['old_password']);
    $new  = trim($_POST['new_password']);
    $conf = trim($_POST['confirm_new']);
    if (!password_verify($old, $user['password'])) {
        $pwd_error = 'Old password is incorrect';
    } elseif (strlen($new) < 6) {
        $pwd_error = 'New password must be at least 6 characters';
    } elseif ($new !== $conf) {
        $pwd_error = 'New passwords do not match';
    } else {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET password='$hashed' WHERE user_id='$user_id'");
        $message[] = 'Password changed successfully!';
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('location:login.php'); exit;
}

// Fetch orders
$orders     = $conn->query("SELECT * FROM orders WHERE user_id='$user_id' ORDER BY created_at DESC LIMIT 10");
$order_count= mysqli_num_rows($conn->query("SELECT * FROM orders WHERE user_id='$user_id'"));
$cart_count = mysqli_num_rows($conn->query("SELECT * FROM cart WHERE user_id='$user_id'"));
$wish_count = mysqli_num_rows($conn->query("SELECT * FROM wishlist WHERE user_id='$user_id'"));

$active_tab  = $_GET['tab'] ?? 'profile';
$page_title  = 'My Account';
$active_page = '';
include 'includes/head.php';
?>
<style>
    .account-wrap { max-width:1200px; margin:auto; padding:48px 24px 72px; display:grid; grid-template-columns:280px 1fr; gap:32px; align-items:start; }
    /* Sidebar */
    .account-sidebar { position:sticky; top:88px; }
    .user-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); padding:28px 24px; margin-bottom:16px; text-align:center; }
    .user-avatar { width:72px; height:72px; border-radius:50%; background:var(--maroon); display:flex; align-items:center; justify-content:center; font-size:28px; color:var(--white); margin:0 auto 14px; font-family:'Playfair Display',serif; }
    .user-name-display { font-family:'Playfair Display',serif; font-size:18px; font-weight:700; color:var(--charcoal); margin-bottom:4px; }
    .user-email-display { font-size:12px; color:var(--text-muted); }
    .stats-row { display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; margin-top:16px; }
    .stat-box { background:var(--cream); border-radius:6px; padding:10px 6px; text-align:center; }
    .stat-num { font-size:18px; font-weight:700; color:var(--maroon); }
    .stat-lbl { font-size:9px; color:var(--text-muted); letter-spacing:0.5px; text-transform:uppercase; }
    .account-nav { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; }
    .account-nav a { display:flex; align-items:center; gap:12px; padding:14px 20px; font-size:13px; color:var(--text-mid); text-decoration:none; border-bottom:1px solid var(--border); transition:all 0.2s; font-weight:500; }
    .account-nav a:last-child { border-bottom:none; }
    .account-nav a:hover, .account-nav a.active { background:var(--cream); color:var(--maroon); }
    .account-nav a i { font-size:16px; width:20px; }
    .account-nav a.logout { color:#e53e3e; }
    .account-nav a.logout:hover { background:#fef2f2; }
    /* Content */
    .account-content { }
    .content-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; margin-bottom:24px; }
    .content-card-head { padding:20px 28px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; }
    .content-card-head h3 { font-family:'Playfair Display',serif; font-size:20px; color:var(--charcoal); }
    .content-card-head p { font-size:12px; color:var(--text-muted); }
    .content-card-body { padding:28px; }
    .form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
    .form-group { margin-bottom:20px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-control { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus { border-color:var(--maroon); outline:none; box-shadow:0 0 0 3px rgba(123,26,26,0.08); }
    .form-control:disabled { opacity:0.6; cursor:not-allowed; }
    .btn-save { background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:11px 28px; font-size:13px; font-weight:600; cursor:pointer; transition:background 0.2s; }
    .btn-save:hover { background:var(--maroon-dark); }
    /* Orders Table */
    .order-table { width:100%; border-collapse:collapse; }
    .order-table th { font-size:10px; letter-spacing:1.5px; text-transform:uppercase; color:var(--text-muted); padding:12px 16px; border-bottom:1px solid var(--border); text-align:left; background:var(--cream); }
    .order-table td { padding:14px 16px; border-bottom:1px solid var(--border); font-size:13px; color:var(--charcoal); }
    .order-table tr:last-child td { border-bottom:none; }
    .order-table tr:hover td { background:var(--ivory); }
    .status-badge { display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:20px; font-size:11px; font-weight:600; }
    .status-pending   { background:#fef3c7; color:#92400e; }
    .status-confirmed { background:#d1fae5; color:#065f46; }
    .status-delivered { background:#dbeafe; color:#1e40af; }
    .status-cancelled { background:#fee2e2; color:#991b1b; }
    .error-msg { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; border-radius:6px; padding:10px 14px; font-size:13px; margin-bottom:16px; }
    @media (max-width:900px) { .account-wrap { grid-template-columns:1fr; } .account-sidebar { position:static; } .form-row-2 { grid-template-columns:1fr; } }
</style>

<?php include 'includes/navbar.php'; ?>

<div class="page-hero">
    <div class="page-hero-inner">
        <p class="page-hero-eyebrow">Welcome Back</p>
        <h1>My Account</h1>
    </div>
</div>
<div class="breadcrumb-bar">
    <div class="inner"><a href="index.php">Home</a> / My Account</div>
</div>

<div class="account-wrap">

    <!-- SIDEBAR -->
    <aside class="account-sidebar">
        <div class="user-card">
            <div class="user-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
            <div class="user-name-display"><?= htmlspecialchars($user['name']) ?></div>
            <div class="user-email-display"><?= htmlspecialchars($user['email']) ?></div>
            <div class="stats-row">
                <div class="stat-box"><div class="stat-num"><?= $order_count ?></div><div class="stat-lbl">Orders</div></div>
                <div class="stat-box"><div class="stat-num"><?= $cart_count ?></div><div class="stat-lbl">Cart</div></div>
                <div class="stat-box"><div class="stat-num"><?= $wish_count ?></div><div class="stat-lbl">Wishlist</div></div>
            </div>
        </div>

        <nav class="account-nav">
            <a href="?tab=profile"  class="<?= $active_tab==='profile'?'active':'' ?>"><i class="bi bi-person"></i> My Profile</a>
            <a href="?tab=orders"   class="<?= $active_tab==='orders'?'active':'' ?>"><i class="bi bi-bag"></i> My Orders</a>
            <a href="?tab=password" class="<?= $active_tab==='password'?'active':'' ?>"><i class="bi bi-lock"></i> Change Password</a>
            <a href="wishlist.php"><i class="bi bi-heart"></i> Wishlist</a>
            <a href="cart.php"><i class="bi bi-cart"></i> My Cart</a>
            <a href="?logout=1" class="logout" onclick="return confirm('Logout?')"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </nav>
    </aside>

    <!-- CONTENT -->
    <div class="account-content">
        <?php if ($active_tab === 'profile'): ?>
        <div class="content-card">
            <div class="content-card-head">
                <div>
                    <h3>Profile Details</h3>
                    <p>Update your personal information</p>
                </div>
            </div>
            <div class="content-card-body">
                <?php if (isset($message)): ?>
                <div style="background:#d1fae5;border:1px solid #6ee7b7;color:#065f46;border-radius:6px;padding:10px 14px;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:8px;">
                    <i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($message[0]) ?>
                </div>
                <?php endif; ?>
                <form method="POST" action="">
                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Delivery Address</label>
                        <textarea name="address" class="form-control" rows="3" placeholder="Complete home address..."><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" name="update_profile" class="btn-save">
                        <i class="bi bi-check-lg me-1"></i> Save Profile
                    </button>
                </form>
            </div>
        </div>

        <?php elseif ($active_tab === 'orders'): ?>
        <div class="content-card">
            <div class="content-card-head">
                <div><h3>My Orders</h3><p>Details of all your orders</p></div>
            </div>
            <div class="content-card-body" style="padding:0">
                <?php if (mysqli_num_rows($orders) > 0): ?>
                <table class="order-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Payment</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($o = mysqli_fetch_assoc($orders)): ?>
                        <tr>
                            <td><strong>#<?= $o['order_id'] ?></strong></td>
                            <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                            <td><strong>PKR <?= number_format($o['total_amount']) ?></strong></td>
                            <td><?= htmlspecialchars($o['payment_method']) ?></td>
                            <td>
                                <?php
                                $status_class = [
                                    'Pending'   => 'status-pending',
                                    'Confirmed' => 'status-confirmed',
                                    'Delivered' => 'status-delivered',
                                    'Cancelled' => 'status-cancelled',
                                ][$o['status']] ?? 'status-pending';
                                ?>
                                <span class="status-badge <?= $status_class ?>">
                                    <?= htmlspecialchars($o['status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="order_detail.php?id=<?= $o['order_id'] ?>"
                                   style="color:var(--maroon);font-size:12px;font-weight:600;text-decoration:none;">
                                    View
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="empty-state">
                    <i class="bi bi-bag-x"></i>
                    <h3>No Orders</h3>
                    <p>You haven't placed any orders yet</p>
                    <a href="shop.php">Start Shopping</a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <?php elseif ($active_tab === 'password'): ?>
        <div class="content-card">
            <div class="content-card-head">
                <div><h3>Change Password</h3><p>Use a strong password to keep your account secure</p></div>
            </div>
            <div class="content-card-body">
                <?php if (isset($pwd_error)): ?>
                <div class="error-msg"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($pwd_error) ?></div>
                <?php endif; ?>
                <?php if (isset($message)): ?>
                <div style="background:#d1fae5;border:1px solid #6ee7b7;color:#065f46;border-radius:6px;padding:10px 14px;font-size:13px;margin-bottom:16px;">
                    <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($message[0]) ?>
                </div>
                <?php endif; ?>
                <form method="POST" action="" style="max-width:420px">
                    <div class="form-group">
                        <label class="form-label">Old Password</label>
                        <input type="password" name="old_password" class="form-control" placeholder="••••••••" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" placeholder="At least 6 characters" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Confirm Password</label>
                        <input type="password" name="confirm_new" class="form-control" placeholder="Re-enter" required>
                    </div>
                    <button type="submit" name="change_password" class="btn-save">
                        <i class="bi bi-lock me-1"></i> Change Password
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
