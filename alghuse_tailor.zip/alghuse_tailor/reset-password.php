<?php
include 'config.php';
error_reporting(0);
session_start();

if (!isset($_SESSION['reset_email']) || !isset($_SESSION['reset_verified'])) {
    header('location:forgot-password.php'); exit;
}
$email = $_SESSION['reset_email'];

if (isset($_POST['reset_password'])) {
    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm_password']);

    if (empty($password) || empty($confirm)) {
        $error = 'Please fill all fields';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match';
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET password='$hashed', reset_otp=NULL, reset_otp_expiry=NULL WHERE email='" . $conn->real_escape_string($email) . "'");

        unset($_SESSION['reset_email']);
        unset($_SESSION['reset_verified']);

        $_SESSION['reset_success'] = true;
        header('location:login.php'); exit;
    }
}

$page_title = 'Reset Password';
include 'includes/head.php';
?>
<style>
    .auth-wrap { min-height:calc(100vh - 68px); display:flex; align-items:center; justify-content:center; padding:48px 24px; background:var(--ivory); }
    .auth-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow-md); width:100%; max-width:440px; }
    .auth-header { background:var(--maroon); padding:28px 36px; text-align:center; position:relative; overflow:hidden; }
    .auth-header::before { content:''; position:absolute; inset:0; background:repeating-linear-gradient(45deg,transparent,transparent 30px,rgba(255,255,255,0.03) 30px,rgba(255,255,255,0.03) 60px); }
    .auth-header-inner { position:relative; z-index:1; }
    .auth-logo { font-family:'Playfair Display',serif; font-size:22px; font-weight:700; color:var(--white); margin-bottom:6px; }
    .auth-logo span { color:var(--gold-light); }
    .auth-subtitle { font-size:13px; color:rgba(255,255,255,0.7); }
    .auth-body { padding:32px 36px; }
    .form-group { margin-bottom:18px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-control { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus { border-color:var(--maroon); box-shadow:0 0 0 3px rgba(123,26,26,0.08); outline:none; }
    .input-icon-wrap { position:relative; }
    .input-icon-wrap .form-control { padding-right:42px; }
    .input-icon { position:absolute; right:12px; top:50%; transform:translateY(-50%); color:var(--text-muted); font-size:16px; cursor:pointer; }
    .btn-auth { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:13px; font-size:14px; font-weight:700; cursor:pointer; letter-spacing:0.4px; transition:background 0.2s; margin-top:8px; }
    .btn-auth:hover { background:var(--maroon-dark); }
    .error-msg { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; border-radius:6px; padding:10px 14px; font-size:13px; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
    .strength-bar { height:3px; border-radius:2px; margin-top:6px; transition:all 0.3s; }
    .strength-weak   { background:#ef4444; width:33%; }
    .strength-medium { background:#f59e0b; width:66%; }
    .strength-strong { background:#10b981; width:100%; }
</style>

<nav class="navbar-main">
    <div class="navbar-inner">
        <a href="index.php" class="brand-logo">AL-Ghuse <span>Tailor</span></a>
        <div></div>
        <a href="login.php" class="btn-login-nav">Login</a>
    </div>
</nav>

<div class="auth-wrap">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-header-inner">
                <div class="auth-logo">AL-Ghuse <span>Tailor</span></div>
                <p class="auth-subtitle">Set a new password</p>
            </div>
        </div>
        <div class="auth-body">
            <?php if (isset($error)): ?>
            <div class="error-msg">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label">New Password <span style="color:#e53e3e">*</span></label>
                    <div class="input-icon-wrap">
                        <input type="password" name="password" id="pwd1" class="form-control"
                               placeholder="New password" required oninput="checkStrength(this.value)">
                        <i class="bi bi-eye input-icon" id="t1" onclick="toggleField('pwd1','t1')"></i>
                    </div>
                    <div class="strength-bar" id="strength-bar"></div>
                </div>

                <div class="form-group">
                    <label class="form-label">Confirm New Password <span style="color:#e53e3e">*</span></label>
                    <div class="input-icon-wrap">
                        <input type="password" name="confirm_password" id="pwd2" class="form-control"
                               placeholder="Confirm new password" required>
                        <i class="bi bi-eye input-icon" id="t2" onclick="toggleField('pwd2','t2')"></i>
                    </div>
                </div>

                <button type="submit" name="reset_password" class="btn-auth">
                    <i class="bi bi-key-fill me-2"></i> Reset Password
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleField(id, iconId) {
    const f = document.getElementById(id);
    const i = document.getElementById(iconId);
    f.type = f.type === 'password' ? 'text' : 'password';
    i.classList.toggle('bi-eye'); i.classList.toggle('bi-eye-slash');
}
function checkStrength(pwd) {
    const bar = document.getElementById('strength-bar');
    bar.className = 'strength-bar';
    if (!pwd) return;
    if (pwd.length < 6)  { bar.classList.add('strength-weak'); return; }
    const strong = /(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%])/.test(pwd);
    const medium = /(?=.*[a-zA-Z])(?=.*[0-9])/.test(pwd);
    bar.classList.add(strong ? 'strength-strong' : medium ? 'strength-medium' : 'strength-weak');
}
</script>
</body>
</html>
