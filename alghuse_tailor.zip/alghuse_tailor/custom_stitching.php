<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;

if (isset($_POST['submit_order'])) {
    $name        = $conn->real_escape_string(trim($_POST['name']));
    $phone       = $conn->real_escape_string(trim($_POST['phone']));
    $email       = $conn->real_escape_string(trim($_POST['email'] ?? ''));
    $fabric      = $conn->real_escape_string(trim($_POST['fabric'] ?? ''));
    $style       = $conn->real_escape_string(trim($_POST['style'] ?? ''));
    $budget      = $conn->real_escape_string(trim($_POST['budget'] ?? ''));
    $special_req = $conn->real_escape_string(trim($_POST['special_req'] ?? ''));

    $measurements = "Seena: {$_POST['seena']} | Kamar: {$_POST['kamar']} | Kullah: {$_POST['kullah']} | Qad: {$_POST['qad']} | Sleeve: {$_POST['sleeve']} | Gardan: {$_POST['gardan']}";
    $measurements = $conn->real_escape_string($measurements);

    if (empty($name) || empty($phone)) {
        $form_error = 'Name and phone number are required';
    } else {
        $conn->query("INSERT INTO custom_orders (user_id,name,phone,email,fabric,style,measurements,special_req,budget)
                      VALUES ('".($user_id ?: 'NULL')."','$name','$phone','$email','$fabric','$style','$measurements','$special_req','$budget')");
        $success = true;
        $order_no = $conn->insert_id;
    }
}

$page_title  = 'Custom Stitching';
$active_page = 'custom';
include 'includes/head.php';
?>
<style>
    .custom-hero { position:relative; overflow:hidden; background:var(--maroon); padding:72px 24px; }
    .custom-hero::before { content:''; position:absolute; inset:0; background:repeating-linear-gradient(45deg,transparent,transparent 40px,rgba(255,255,255,0.03) 40px,rgba(255,255,255,0.03) 80px); }
    .custom-hero-inner { max-width:640px; margin:auto; text-align:center; position:relative; z-index:1; }
    .custom-hero-inner p.eyebrow { font-size:10px; letter-spacing:3px; text-transform:uppercase; color:var(--gold-light); font-weight:600; margin-bottom:14px; }
    .custom-hero-inner h1 { font-family:'Playfair Display',serif; font-size:42px; color:var(--white); margin-bottom:14px; }
    .custom-hero-inner h1 span { color:var(--gold-light); }
    .custom-hero-inner .hero-sub { font-size:15px; color:rgba(255,255,255,0.75); line-height:1.7; }
    .process-section { max-width:1200px; margin:auto; padding:56px 24px; }
    .process-steps { display:grid; grid-template-columns:repeat(4,1fr); gap:24px; }
    .process-step { text-align:center; padding:28px 20px; background:var(--white); border:1px solid var(--border); border-radius:var(--radius); position:relative; }
    .step-num { width:40px; height:40px; background:var(--maroon); color:var(--white); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700; margin:0 auto 14px; }
    .step-icon { font-size:28px; color:var(--gold); margin-bottom:10px; display:block; }
    .step-title { font-family:'Playfair Display',serif; font-size:16px; font-weight:700; color:var(--charcoal); margin-bottom:6px; }
    .step-desc { font-size:12px; color:var(--text-muted); line-height:1.6; }
    .form-section { max-width:900px; margin:auto; padding:0 24px 72px; }
    .form-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow-sm); }
    .form-section-head { background:var(--cream); padding:18px 28px; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:10px; }
    .form-section-head h3 { font-family:'Playfair Display',serif; font-size:18px; color:var(--charcoal); }
    .form-section-head i { color:var(--gold); font-size:18px; }
    .form-body { padding:28px; }
    .form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
    .form-row-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; }
    .form-group { margin-bottom:18px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-label span { color:#e53e3e; }
    .form-control, .form-select { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus, .form-select:focus { border-color:var(--maroon); outline:none; box-shadow:0 0 0 3px rgba(123,26,26,0.08); }
    .measurement-helper { background:var(--cream); border:1px solid var(--border); border-radius:6px; padding:14px 16px; margin-bottom:20px; font-size:13px; color:var(--text-mid); display:flex; align-items:center; gap:10px; }
    .measurement-helper i { color:var(--maroon); font-size:16px; flex-shrink:0; }
    .btn-submit-order { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:15px; font-size:14px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; }
    .btn-submit-order:hover { background:var(--maroon-dark); }
    .btn-wa-custom { width:100%; background:#25D366; color:var(--white); border:none; border-radius:6px; padding:14px; font-size:14px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; text-decoration:none; margin-top:10px; }
    .btn-wa-custom:hover { background:#1ebe5d; color:var(--white); }
    .success-card { background:#d1fae5; border:1px solid #6ee7b7; border-radius:var(--radius); padding:32px; text-align:center; }
    .success-card i { font-size:48px; color:#059669; display:block; margin-bottom:14px; }
    .success-card h2 { font-family:'Playfair Display',serif; font-size:26px; color:#065f46; margin-bottom:8px; }
    .success-card p { font-size:14px; color:#047857; }
    @media (max-width:768px) { .process-steps { grid-template-columns:1fr 1fr; } .form-row-2, .form-row-3 { grid-template-columns:1fr; } .custom-hero-inner h1 { font-size:28px; } }
</style>

<?php include 'includes/navbar.php'; ?>

<!-- HERO -->
<div class="custom-hero">
    <div class="custom-hero-inner">
        <p class="eyebrow">Especially For You</p>
        <h1>Custom Stitching<br><span>Exactly Your Way</span></h1>
        <p class="hero-sub">
            Bring your own fabric or choose from ours —<br>
            give us your measurements and we'll create your dream suit
        </p>
    </div>
</div>

<!-- HOW IT WORKS -->
<div class="process-section">
    <div style="text-align:center; margin-bottom:36px;">
        <p class="section-eyebrow">Simple Process</p>
        <h2 class="section-title">How Does It Work?</h2>
    </div>
    <div class="process-steps">
        <div class="process-step">
            <div class="step-num">1</div>
            <i class="bi bi-ui-checks step-icon"></i>
            <div class="step-title">Fill the Form</div>
            <p class="step-desc">Tell us your measurements and style preferences</p>
        </div>
        <div class="process-step">
            <div class="step-num">2</div>
            <i class="bi bi-whatsapp step-icon"></i>
            <div class="step-title">WhatsApp Contact</div>
            <p class="step-desc">Our team will contact you within 24 hours</p>
        </div>
        <div class="process-step">
            <div class="step-num">3</div>
            <i class="bi bi-scissors step-icon"></i>
            <div class="step-title">Stitching Begins</div>
            <p class="step-desc">Once confirmed, we'll start preparing your suit</p>
        </div>
        <div class="process-step">
            <div class="step-num">4</div>
            <i class="bi bi-truck step-icon"></i>
            <div class="step-title">Delivery</div>
            <p class="step-desc">We'll deliver it to your doorstep once ready</p>
        </div>
    </div>
</div>

<!-- FORM -->
<div class="form-section">
    <?php if (isset($success) && $success): ?>
    <div class="success-card">
        <i class="bi bi-check-circle-fill"></i>
        <h2>Order Submitted Successfully!</h2>
        <p>Order #<?= $order_no ?> — Our team will contact you shortly.</p>
        <br>
        <a href="index.php" style="color:var(--maroon);font-weight:600;">Back to Home</a>
        &nbsp; | &nbsp;
        <a href="custom_stitching.php" style="color:var(--maroon);font-weight:600;">Place New Order</a>
    </div>

    <?php else: ?>

    <?php if (isset($form_error)): ?>
    <div style="background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;border-radius:6px;padding:12px 16px;font-size:13px;margin-bottom:20px;display:flex;align-items:center;gap:8px;">
        <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($form_error) ?>
    </div>
    <?php endif; ?>

    <form method="POST" action="">
        <!-- Personal Info -->
        <div class="form-card" style="margin-bottom:24px;">
            <div class="form-section-head"><i class="bi bi-person-fill"></i><h3>Personal Details</h3></div>
            <div class="form-body">
                <div class="form-row-2">
                    <div class="form-group">
                        <label class="form-label">Full Name <span>*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Your name"
                               value="<?= htmlspecialchars($_POST['name'] ?? ($user ? $user['name'] ?? '' : '')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone Number <span>*</span></label>
                        <input type="tel" name="phone" class="form-control" placeholder="03xx-xxxxxxx" required
                               value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Email (Optional)</label>
                    <input type="email" name="email" class="form-control" placeholder="your@email.com"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
            </div>
        </div>

        <!-- Style Info -->
        <div class="form-card" style="margin-bottom:24px;">
            <div class="form-section-head"><i class="bi bi-scissors"></i><h3>Style & Fabric</h3></div>
            <div class="form-body">
                <div class="form-row-2">
                    <div class="form-group">
                        <label class="form-label">Fabric Type</label>
                        <select name="fabric" class="form-select">
                            <option value="">Select...</option>
                            <?php foreach (['Lawn','Chiffon','Georgette','Cotton','Khaddar','Silk','Net','Organza','Velvet','Bring Your Own Fabric'] as $f): ?>
                            <option value="<?= $f ?>" <?= ($_POST['fabric'] ?? '') === $f ? 'selected' : '' ?>><?= $f ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Style</label>
                        <select name="style" class="form-select">
                            <option value="">Select style...</option>
                            <?php foreach (['Kameez Salwar','Anarkali','Peplum','Kurta Pajama','Bridal Lehenga','Sharara','Palazzo Suit','Custom Design'] as $st): ?>
                            <option value="<?= $st ?>" <?= ($_POST['style'] ?? '') === $st ? 'selected' : '' ?>><?= $st ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Budget Range</label>
                    <select name="budget" class="form-select">
                        <option value="">Select budget...</option>
                        <?php foreach (['PKR 2,000 - 5,000','PKR 5,000 - 10,000','PKR 10,000 - 20,000','PKR 20,000 - 50,000','Above PKR 50,000'] as $b): ?>
                        <option value="<?= $b ?>" <?= ($_POST['budget'] ?? '') === $b ? 'selected' : '' ?>><?= $b ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Special Requirements</label>
                    <textarea name="special_req" class="form-control" rows="3"
                              placeholder="Mention any specific design, embroidery, color or style..."><?= htmlspecialchars($_POST['special_req'] ?? '') ?></textarea>
                </div>
            </div>
        </div>

        <!-- Measurements -->
        <div class="form-card" style="margin-bottom:24px;">
            <div class="form-section-head"><i class="bi bi-rulers"></i><h3>Measurements (in inches)</h3></div>
            <div class="form-body">
                <div class="measurement-helper">
                    <i class="bi bi-info-circle-fill"></i>
                    <span>If you don't know your measurements, leave this blank — our team will guide you on WhatsApp. Enter everything in inches.</span>
                </div>
                <div class="form-row-3">
                    <div class="form-group">
                        <label class="form-label">Chest</label>
                        <input type="number" name="seena" class="form-control" placeholder='e.g. 36"'
                               value="<?= htmlspecialchars($_POST['seena'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Waist</label>
                        <input type="number" name="kamar" class="form-control" placeholder='e.g. 32"'
                               value="<?= htmlspecialchars($_POST['kamar'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Hips</label>
                        <input type="number" name="kullah" class="form-control" placeholder='e.g. 40"'
                               value="<?= htmlspecialchars($_POST['kullah'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Height/Length</label>
                        <input type="number" name="qad" class="form-control" placeholder='e.g. 54"'
                               value="<?= htmlspecialchars($_POST['qad'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Sleeve Length</label>
                        <input type="number" name="sleeve" class="form-control" placeholder='e.g. 22"'
                               value="<?= htmlspecialchars($_POST['sleeve'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Neck</label>
                        <input type="number" name="gardan" class="form-control" placeholder='e.g. 14"'
                               value="<?= htmlspecialchars($_POST['gardan'] ?? '') ?>">
                    </div>
                </div>
            </div>
        </div>

        <button type="submit" name="submit_order" class="btn-submit-order">
            <i class="bi bi-send-fill"></i> Submit Custom Order
        </button>
    </form>

    <a href="https://wa.me/923001234567?text=Hello!%20I%20need%20custom%20stitching%20done"
       target="_blank" class="btn-wa-custom">
        <i class="bi bi-whatsapp"></i> Or Contact via WhatsApp Directly
    </a>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
