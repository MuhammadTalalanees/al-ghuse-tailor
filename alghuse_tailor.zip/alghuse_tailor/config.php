<?php
// =============================================
// AL-Ghuse Tailor — Database Configuration
// =============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'alghuse_tailor');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die('<div style="font-family:sans-serif;padding:40px;text-align:center;color:#7B1A1A;">
        <h2>⚠️ Database connection failed</h2>
        <p>Please check your database configuration.</p>
        <p style="color:#999;font-size:12px;">' . $conn->connect_error . '</p>
    </div>');
}
// --- Add these lines to your existing config.php ---
// (Below your $conn database connection lines)

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'iqplayz456@gmail.com');   // <-- apna Gmail address
define('SMTP_PASS', 'xyec cwhj essz oqix');     // <-- Google App Password (spaces hata dena)
define('SMTP_FROM_NAME', 'AL-Ghuse Tailor');
$conn->set_charset('utf8mb4');

// =============================================
// DB TABLES SQL (run once to setup):
// =============================================
/*
CREATE DATABASE alghuse_tailor CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE alghuse_tailor;

CREATE TABLE users (
  user_id    INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) UNIQUE NOT NULL,
  password   VARCHAR(255) NOT NULL,
  phone      VARCHAR(20),
  address    TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE suits_info (
  sid        INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(150) NOT NULL,
  category   VARCHAR(50)  NOT NULL,
  fabric     VARCHAR(100),
  price      DECIMAL(10,2) NOT NULL,
  description TEXT,
  image      VARCHAR(255),
  stock      INT DEFAULT 1,
  date       DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cart (
  cart_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  suit_id    INT NOT NULL,
  name       VARCHAR(150),
  price      DECIMAL(10,2),
  image      VARCHAR(255),
  quantity   INT DEFAULT 1,
  total      DECIMAL(10,2),
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE wishlist (
  wish_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  suit_id    INT NOT NULL,
  name       VARCHAR(150),
  price      DECIMAL(10,2),
  image      VARCHAR(255),
  added_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE orders (
  order_id      INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  name          VARCHAR(100),
  phone         VARCHAR(20),
  address       TEXT,
  city          VARCHAR(100),
  payment_method VARCHAR(50) DEFAULT 'COD',
  total_amount  DECIMAL(10,2),
  status        VARCHAR(50) DEFAULT 'Pending',
  notes         TEXT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE order_items (
  item_id    INT AUTO_INCREMENT PRIMARY KEY,
  order_id   INT NOT NULL,
  suit_id    INT NOT NULL,
  name       VARCHAR(150),
  price      DECIMAL(10,2),
  quantity   INT,
  total      DECIMAL(10,2),
  FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
);

CREATE TABLE custom_orders (
  custom_id  INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT,
  name       VARCHAR(100) NOT NULL,
  phone      VARCHAR(20)  NOT NULL,
  email      VARCHAR(150),
  fabric     VARCHAR(100),
  style      VARCHAR(100),
  measurements TEXT,
  special_req  TEXT,
  budget     VARCHAR(50),
  status     VARCHAR(50) DEFAULT 'Pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
*/
?>
