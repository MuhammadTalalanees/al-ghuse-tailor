<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) { header('location:index.php'); exit; }

$order_id = (int)($_GET['id'] ?? 0);
$order    = $order_id ? mysqli_fetch_assoc($conn->query("SELECT * FROM orders WHERE order_id='$order_id' AND user_id='$user_id'")) : null;
$items    = $order_id ? $conn->query("SELECT * FROM order_items WHERE order_id='$order_id'") : null;

$page_title  = 'Order Successful!';
$active_page = '';
include 'includes/head.php';
?>
<style>
    .success-wrap { max-width:720px; margin:0 auto; padding:64px 24px 80px; text-align:center; }
    .success-icon-circle { width:100px; height:100px; background:linear-gradient(135deg, #d1fae5, #a7f3d0); border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 24px; border:4px solid #6ee7b7; }
    .success-icon-circle i { font-size:44px; color:#059669; }
    .success-title { font-family:'Playfair Display',serif; font-size:36px; color:var(--charcoal); margin-bottom:10px; }
    .success-title span { color:var(--maroon); }
    .success-sub { font-size:16px; color:var(--text-mid); margin-bottom:32px; line-height:1.7; }
    .order-summary-box { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; text-align:left; margin-bottom:32px; box-shadow:var(--shadow-sm); }
    .order-summ-head { background:var(--maroon); padding:16px 24px; display:flex; justify-content:space-between; align-items:center; }
    .order-summ-head h3 { font-family:'Playfair Display',serif; font-size:18px; color:var(--white); }
    .order-summ-head span { font-size:13px; color:var(--gold-light); font-weight:600; }
    .order-summ-body { padding:20px 24px; }
    .order-detail-row { display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border); font-size:13px; }
    .order-detail-row:last-child { border-bottom:none; }
    .od-label { color:var(--text-muted); }
    .od-val { font-weight:600; color:var(--charcoal); }
    .order-items-list { margin-top:16px; }
    .oi-row { display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--border); font-size:13px; }
    .oi-row:last-child { border-bottom:none; }
    .total-row { display:flex; justify-content:space-between; background:var(--cream); padding:14px 24px; }
    .total-row span { font-size:16px; font-weight:700; color:var(--maroon); }
    .action-btns { display:flex; gap:14px; justify-content:center; flex-wrap:wrap; }
    .btn-track { background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:13px 28px; font-size:13px; font-weight:700; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:8px; transition:background 0.2s; }
    .btn-track:hover { background:var(--maroon-dark); color:var(--white); }
    .btn-continue { background:transparent; border:1.5px solid var(--border); color:var(--text-mid); border-radius:6px; padding:13px 28px; font-size:13px; font-weight:600; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:8px; transition:all 0.2s; }
    .btn-continue:hover { border-color:var(--maroon); color:var(--maroon); }
    .wa-follow-up { background:#25D366; color:var(--white); border:none; border-radius:6px; padding:13px 28px; font-size:13px; font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:8px; transition:background 0.2s; }
    .wa-follow-up:hover { background:#1ebe5d; color:var(--white); }
    @keyframes bounceIn { 0%{transform:scale(0.3);opacity:0} 60%{transform:scale(1.05)} 100%{transform:scale(1);opacity:1} }
    .success-icon-circle { animation:bounceIn 0.6s ease; }
</style>

<?php include 'includes/navbar.php'; ?>

<div class="success-wrap">
    <div class="success-icon-circle"><i class="bi bi-check-lg"></i></div>
    <h1 class="success-title">Thank You! <span>Your Order Is Placed</span></h1>
    <p class="success-sub">
        Your order has been received successfully.<br>
        Our team will contact you shortly to confirm delivery.
    </p>

    <?php if ($order): ?>
    <div class="order-summary-box">
        <div class="order-summ-head">
            <h3>Order #<?= $order['order_id'] ?></h3>
            <span>
                <i class="bi bi-circle-fill" style="font-size:8px;color:#fbbf24;vertical-align:middle;"></i>
                <?= htmlspecialchars($order['status']) ?>
            </span>
        </div>
        <div class="order-summ-body">
            <div class="order-detail-row"><span class="od-label">Customer Name</span><span class="od-val"><?= htmlspecialchars($order['name']) ?></span></div>
            <div class="order-detail-row"><span class="od-label">Phone</span><span class="od-val"><?= htmlspecialchars($order['phone']) ?></span></div>
            <div class="order-detail-row"><span class="od-label">Delivery Address</span><span class="od-val"><?= htmlspecialchars($order['address']) ?>, <?= htmlspecialchars($order['city']) ?></span></div>
            <div class="order-detail-row"><span class="od-label">Payment Method</span><span class="od-val"><?= htmlspecialchars($order['payment_method']) ?></span></div>
            <div class="order-detail-row"><span class="od-label">Order Date</span><span class="od-val"><?= date('d M Y, g:i A', strtotime($order['created_at'])) ?></span></div>

            <?php if ($items && mysqli_num_rows($items) > 0): ?>
            <div style="margin-top:12px; padding-top:12px; border-top:1px solid var(--border);">
                <p style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:var(--text-muted);margin-bottom:8px;font-weight:600;">Ordered Items</p>
                <div class="order-items-list">
                    <?php while ($item = mysqli_fetch_assoc($items)): ?>
                    <div class="oi-row">
                        <span><?= htmlspecialchars($item['name']) ?> <span style="color:var(--text-muted)">× <?= $item['quantity'] ?></span></span>
                        <span style="font-weight:600; color:var(--maroon)">PKR <?= number_format($item['total']) ?></span>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="total-row">
            <span>Total Amount</span>
            <span>PKR <?= number_format($order['total_amount']) ?></span>
        </div>
    </div>
    <?php endif; ?>

    <div class="action-btns">
        <a href="my_account.php?tab=orders" class="btn-track">
            <i class="bi bi-bag-check"></i> My Orders
        </a>
        <a href="https://wa.me/923001234567?text=Hello!%20My%20Order%20#<?= $order_id ?>%20has%20been%20confirmed.%20Please%20provide%20an%20update."
           target="_blank" class="wa-follow-up">
            <i class="bi bi-whatsapp"></i> WhatsApp Update
        </a>
        <a href="shop.php" class="btn-continue">
            <i class="bi bi-arrow-left"></i> Continue Shopping
        </a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
