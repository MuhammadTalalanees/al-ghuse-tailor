-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2026 at 02:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alghuse_tailor`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `suit_id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `size` varchar(20) DEFAULT NULL,
  `measurements` text DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `suit_id`, `name`, `price`, `image`, `quantity`, `size`, `measurements`, `total`) VALUES
(25, 2, 1, 'suuuuuuuuuuuu', 1800.00, 'suit_1783338211.jpg', 1, 'M', NULL, 1800.00),
(26, 2, 1, 'suuuuuuuuuuuu', 1800.00, 'suit_1783338211.jpg', 1, 'XL', NULL, 1800.00);

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `msg_id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_orders`
--

CREATE TABLE `custom_orders` (
  `custom_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `fabric` varchar(100) DEFAULT NULL,
  `style` varchar(100) DEFAULT NULL,
  `measurements` text DEFAULT NULL,
  `special_req` text DEFAULT NULL,
  `budget` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custom_orders`
--

INSERT INTO `custom_orders` (`custom_id`, `user_id`, `name`, `phone`, `email`, `fabric`, `style`, `measurements`, `special_req`, `budget`, `status`, `created_at`) VALUES
(1, 2, 'talalal', '033333333', 'muneeb66262@gmail.com', 'Cotton', 'Kameez Salwar', 'Seena: 16 | Kamar: 23 | Kullah: 24 | Qad: 40 | Sleeve: 23 | Gardan: 13', 'logo on front', 'PKR 2,000 - 5,000', 'Pending', '2026-07-01 17:54:51'),
(2, 4, 'TALAL ANEES', '6666666666', 'ttt@gmail.com', 'Velvet', 'Sharara', 'Seena: 22 | Kamar: 22 | Kullah: 22 | Qad: 22 | Sleeve: 22 | Gardan: 22', 'weeeeeeeeeee', 'PKR 20,000 - 50,000', 'Pending', '2026-07-06 16:27:40'),
(3, 2, 'talalal', '6666666666', 'muneeb66262@gmail.com', 'Net', 'Sharara', 'Seena: 11 | Kamar: 11 | Kullah: 11 | Qad: 11 | Sleeve: 111 | Gardan: 111', 'hgggggggggggggggg', 'PKR 2,000 - 5,000', 'Pending', '2026-07-06 17:02:14');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT 'COD',
  `total_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `name`, `phone`, `address`, `city`, `payment_method`, `total_amount`, `status`, `notes`, `created_at`) VALUES
(6, 2, 'TALAL ANEES', '6666666666', 'L-543 5C/2 North karachi', 'Karachi', 'COD', 7800.00, 'Pending', '', '2026-07-07 17:36:33'),
(7, 4, 'Muhammad Talal', '6666666666', 'North Karachi\r\nL543-5C/2', 'Karachi', 'COD', 1800.00, 'Pending', '', '2026-07-07 17:43:39'),
(8, 4, 'Muhammad Talal', '6666666666', 'North Karachi\r\nL543-5C/2', 'Karachi', 'COD', 3000.00, 'Pending', '', '2026-07-07 17:43:53'),
(9, 4, 'Muhammad Talal', '6666666666', 'North Karachi\r\nL543-5C/2', 'Islamabad', 'COD', 1800.00, 'Pending', '', '2026-07-07 17:44:19'),
(10, 2, 'TALAL ANEES', '6666666666', 'North Karachi\r\nL543-5C/2', 'Karachi', 'EasyPaisa', 1800.00, 'Pending', '', '2026-07-07 17:45:53');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `suit_id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `measurements` text DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `suit_id`, `name`, `price`, `quantity`, `size`, `measurements`, `total`) VALUES
(8, 6, 2, 'wdw', 3000.00, 1, 'Custom', '{\"chest\":\"40\",\"shoulder\":\"23\",\"length\":\"32\",\"sleeve\":\"34\",\"waist\":\"32\",\"hip\":\"23\",\"notes\":\"\"}', 3000.00),
(9, 6, 1, 'suuuuuuuuuuuu', 1800.00, 1, 'Custom', '{\"chest\":\"20\",\"shoulder\":\"20\",\"length\":\"20\",\"sleeve\":\"210\",\"waist\":\"20\",\"hip\":\"20\",\"notes\":\"\"}', 1800.00),
(10, 6, 2, 'wdw', 3000.00, 1, 'M', NULL, 3000.00),
(11, 7, 1, 'suuuuuuuuuuuu', 1800.00, 1, 'XL', NULL, 1800.00),
(12, 8, 2, 'wdw', 3000.00, 1, 'M', NULL, 3000.00),
(13, 9, 1, 'suuuuuuuuuuuu', 1800.00, 1, 'Custom', '{\"chest\":\"12\",\"shoulder\":\"23\",\"length\":\"23\",\"sleeve\":\"23\",\"waist\":\"23\",\"hip\":\"23\",\"notes\":\"\"}', 1800.00),
(14, 10, 1, 'suuuuuuuuuuuu', 1800.00, 1, 'L', NULL, 1800.00);

-- --------------------------------------------------------

--
-- Table structure for table `suits_info`
--

CREATE TABLE `suits_info` (
  `sid` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `category` varchar(50) NOT NULL,
  `fabric` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT 1,
  `date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suits_info`
--

INSERT INTO `suits_info` (`sid`, `name`, `category`, `fabric`, `price`, `description`, `image`, `stock`, `date`) VALUES
(1, 'suuuuuuuuuuuu', 'Casual', 'titu', 1800.00, 'vip', 'suit_1783338211.jpg', 1, '2026-07-06 16:43:31'),
(2, 'wdw', 'Casual', 'titu', 3000.00, 'kk', 'suit_1783426521.jpg', 1, '2026-07-07 17:15:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `user_type` enum('admin','user') NOT NULL DEFAULT 'user',
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `user_type`, `email`, `password`, `phone`, `address`, `created_at`) VALUES
(1, 'TALAL ANEES', 'user', 'iqplayz456@gmail.com', '$2y$10$LBYPy./I1/nEZtoqxAiNSOzPC8KyMHVMv2EBQUp5nYH0TNyWqqU4a', '6666666666', '', '2026-06-29 16:38:31'),
(2, 'TALAL ANEES', 'user', 't@gmail.com', '$2y$10$kPnSAeD/FY1r8eHWPpqHxeBr/u0K226zZPQTORVmTEjhB0MXjsqfu', '6666666666', NULL, '2026-07-01 17:51:07'),
(3, 'talalal', 'admin', 'muneeb66262@gmail.com', '$2y$10$IQCTx82xQ32.MZLC6imwVufwd36pzLBqAtbgRscM9nOmlBwElYmG6', '6666666666', NULL, '2026-07-06 15:55:56'),
(4, 'Muhammad Talal', 'user', 'ttt@gmail.com', '$2y$10$o470.JMNzU2HoC3.TgciquZz0MTUFOj/NTxVPM/mCeFCo6nr2xJZu', '6666666666', NULL, '2026-07-06 16:21:05');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wish_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `suit_id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `added_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wish_id`, `user_id`, `suit_id`, `name`, `price`, `image`, `added_at`) VALUES
(1, 2, 1, 'suuuuuuuuuuuu', 1800.00, 'suit_1783338211.jpg', '2026-07-06 17:05:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `custom_orders`
--
ALTER TABLE `custom_orders`
  ADD PRIMARY KEY (`custom_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `suits_info`
--
ALTER TABLE `suits_info`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`wish_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_orders`
--
ALTER TABLE `custom_orders`
  MODIFY `custom_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `suits_info`
--
ALTER TABLE `suits_info`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wish_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
