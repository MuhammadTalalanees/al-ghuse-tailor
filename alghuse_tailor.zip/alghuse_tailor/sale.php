<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;

// Add to cart
if (isset($_POST['add_to_cart'])) {
    if (!$user_id) { $message[] = 'Please login first'; }
    else {
        $sid = (int)$_POST['suit_id'];
        $check = $conn->query("SELECT * FROM cart WHERE suit_id='$sid' AND user_id='$user_id'");
        if (mysqli_num_rows($check) === 0) {
            $n = $conn->real_escape_string($_POST['suit_name']);
            $p = (float)$_POST['suit_price'];
            $i = $conn->real_escape_string($_POST['suit_image']);
            $conn->query("INSERT INTO cart (user_id,suit_id,name,price,image,quantity,total) VALUES ('$user_id','$sid','$n','$p','$i','1','$p')");
            $message[] = 'Added to cart!';
        } else { $message[] = 'Already in cart'; }
    }
}

// For demo — show all products as "on sale" (in real app, add a discount_price column)
$suits  = $conn->query("SELECT * FROM suits_info ORDER BY RAND() LIMIT 24");
$count  = mysqli_num_rows($conn->query("SELECT sid FROM suits_info"));

$page_title  = 'Sale — Best Deals';
$active_page = 'shop';
include 'includes/head.php';
?>
<style>
    .sale-hero { background:linear-gradient(135deg, #7B1A1A 0%, #C9A84C 100%); padding:64px 24px; text-align:center; position:relative; overflow:hidden; }
    .sale-hero::before { content:'SALE'; position:absolute; font-size:240px; font-weight:900; color:rgba(255,255,255,0.05); font-family:'Playfair Display',serif; top:50%; left:50%; transform:translate(-50%,-50%); letter-spacing:-8px; }
    .sale-hero-inner { position:relative; z-index:1; }
    .sale-badge { display:inline-block; background:var(--white); color:var(--maroon); font-size:11px; font-weight:800; padding:6px 18px; border-radius:20px; letter-spacing:2px; text-transform:uppercase; margin-bottom:16px; }
    .sale-hero h1 { font-family:'Playfair Display',serif; font-size:56px; color:var(--white); margin-bottom:10px; }
    .sale-hero h1 span { color:var(--gold-light); }
    .sale-hero p { font-size:16px; color:rgba(255,255,255,0.8); }
    .timer-strip { background:var(--charcoal); padding:16px; text-align:center; }
    .timer-inner { display:flex; align-items:center; justify-content:center; gap:16px; flex-wrap:wrap; }
    .timer-label { font-size:13px; color:rgba(255,255,255,0.7); letter-spacing:0.5px; }
    .timer-units { display:flex; gap:10px; }
    .timer-box { background:var(--maroon); color:var(--white); border-radius:6px; padding:10px 14px; text-align:center; min-width:52px; }
    .timer-num { font-size:22px; font-weight:700; display:block; font-family:'Playfair Display',serif; }
    .timer-unit { font-size:9px; letter-spacing:1px; text-transform:uppercase; color:rgba(255,255,255,0.7); }
    .sale-content { max-width:1240px; margin:auto; padding:40px 24px 72px; }
    .sale-section-head { display:flex; justify-content:space-between; align-items:center; margin-bottom:28px; padding-bottom:16px; border-bottom:1px solid var(--border); }
    .sale-section-head h2 { font-family:'Playfair Display',serif; font-size:26px; color:var(--charcoal); }
    .sale-section-head p { font-size:13px; color:var(--text-muted); }
    .sale-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(250px,1fr)); gap:24px; }
    .discount-badge { position:absolute; top:12px; left:12px; background:linear-gradient(135deg,#ef4444,#b91c1c); color:var(--white); font-size:12px; font-weight:700; padding:4px 12px; border-radius:4px; letter-spacing:0.5px; }
    .original-price { font-size:12px; color:var(--text-muted); text-decoration:line-through; margin-right:4px; }
    @media (max-width:768px) { .sale-hero h1 { font-size:36px; } }
</style>

<?php include 'includes/navbar.php'; ?>

<!-- SALE HERO -->
<div class="sale-hero">
    <div class="sale-hero-inner">
        <div class="sale-badge">🔥 Limited Time Offer</div>
        <h1>Mega <span>Sale</span></h1>
        <p>Amazing discounts on the best suits — Limited stock!</p>
    </div>
</div>

<!-- COUNTDOWN TIMER -->
<div class="timer-strip">
    <div class="timer-inner">
        <span class="timer-label">Sale ends in:</span>
        <div class="timer-units">
            <div class="timer-box"><span class="timer-num" id="t-days">00</span><span class="timer-unit">Days</span></div>
            <div class="timer-box"><span class="timer-num" id="t-hours">00</span><span class="timer-unit">Hours</span></div>
            <div class="timer-box"><span class="timer-num" id="t-mins">00</span><span class="timer-unit">Mins</span></div>
            <div class="timer-box"><span class="timer-num" id="t-secs">00</span><span class="timer-unit">Secs</span></div>
        </div>
    </div>
</div>

<div class="sale-content">
    <div class="sale-section-head">
        <div>
            <h2>Sale Items</h2>
            <p>The best deals</p>
        </div>
        <span style="background:var(--gold); color:var(--charcoal); font-size:12px; font-weight:700; padding:6px 14px; border-radius:20px;">
            <?= $count ?>+ Items On Sale
        </span>
    </div>

    <div class="sale-grid">
        <?php
        // Simulate different discount percentages
        $discounts = [10, 15, 20, 25, 30];
        $i = 0;
        while ($s = mysqli_fetch_assoc($suits)):
            $discount = $discounts[$i % count($discounts)];
            $orig_price = round($s['price'] / (1 - $discount/100));
            $i++;
        ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <span class="discount-badge">−<?= $discount ?>%</span>
                <button class="card-wish"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? $s['category']) ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div>
                        <span class="original-price">PKR <?= number_format($orig_price) ?></span>
                        <div class="card-price"><span class="currency">PKR</span><?= number_format($s['price']) ?></div>
                    </div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
// Countdown Timer — ends after 3 days
const endDate = new Date();
endDate.setDate(endDate.getDate() + 3);
function updateTimer() {
    const now  = new Date();
    const diff = endDate - now;
    if (diff <= 0) { clearInterval(timer); return; }
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000)  / 60000);
    const s = Math.floor((diff % 60000)    / 1000);
    document.getElementById('t-days').textContent  = String(d).padStart(2,'0');
    document.getElementById('t-hours').textContent = String(h).padStart(2,'0');
    document.getElementById('t-mins').textContent  = String(m).padStart(2,'0');
    document.getElementById('t-secs').textContent  = String(s).padStart(2,'0');
}
updateTimer();
const timer = setInterval(updateTimer, 1000);
</script>
