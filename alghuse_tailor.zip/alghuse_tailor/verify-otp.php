<?php
include 'config.php';
error_reporting(0);
session_start();

if (!isset($_SESSION['reset_email'])) { header('location:forgot-password.php'); exit; }
$email = $_SESSION['reset_email'];

if (isset($_POST['verify_otp'])) {
    $otp_entered = trim($_POST['otp']);

    $result = $conn->query("SELECT reset_otp, reset_otp_expiry FROM users WHERE email='" . $conn->real_escape_string($email) . "'");
    $row = $result->fetch_assoc();

    if (!$row || empty($row['reset_otp'])) {
        $error = 'Something went wrong. Please request a new code.';
    } elseif (strtotime($row['reset_otp_expiry']) < time()) {
        $error = 'This code has expired. Please request a new one.';
    } elseif (!password_verify($otp_entered, $row['reset_otp'])) {
        $error = 'Incorrect code. Please try again.';
    } else {
        $_SESSION['reset_verified'] = true;
        header('location:reset-password.php'); exit;
    }
}

if (isset($_GET['resend'])) {
    $otp        = strval(random_int(100000, 999999));
    $otp_hashed = password_hash($otp, PASSWORD_DEFAULT);
    $expiry     = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    $conn->query("UPDATE users SET reset_otp='$otp_hashed', reset_otp_expiry='$expiry' WHERE email='" . $conn->real_escape_string($email) . "'");

    $subject = 'Password Reset Code - AL-Ghuse Tailor';
    $message = "Your new password reset code is: $otp\n\nThis code will expire in 10 minutes.";
    $headers = "From: no-reply@alghusetailor.com\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    @mail($email, $subject, $message, $headers);

    $resent = true;
}

$page_title = 'Verify Code';
include 'includes/head.php';
?>
<style>
    .auth-wrap { min-height:calc(100vh - 68px); display:flex; align-items:center; justify-content:center; padding:48px 24px; background:var(--ivory); }
    .auth-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow-md); width:100%; max-width:440px; }
    .auth-header { background:var(--maroon); padding:28px 36px; text-align:center; position:relative; overflow:hidden; }
    .auth-header::before { content:''; position:absolute; inset:0; background:repeating-linear-gradient(45deg,transparent,transparent 30px,rgba(255,255,255,0.03) 30px,rgba(255,255,255,0.03) 60px); }
    .auth-header-inner { position:relative; z-index:1; }
    .auth-logo { font-family:'Playfair Display',serif; font-size:22px; font-weight:700; color:var(--white); margin-bottom:6px; }
    .auth-logo span { color:var(--gold-light); }
    .auth-subtitle { font-size:13px; color:rgba(255,255,255,0.7); }
    .auth-body { padding:32px 36px; }
    .form-group { margin-bottom:18px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-control { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:20px; letter-spacing:8px; text-align:center; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus { border-color:var(--maroon); box-shadow:0 0 0 3px rgba(123,26,26,0.08); outline:none; }
    .btn-auth { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:13px; font-size:14px; font-weight:700; cursor:pointer; letter-spacing:0.4px; transition:background 0.2s; margin-top:8px; }
    .btn-auth:hover { background:var(--maroon-dark); }
    .error-msg { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; border-radius:6px; padding:10px 14px; font-size:13px; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
    .success-msg { background:#f0fdf4; border:1px solid #86efac; color:#166534; border-radius:6px; padding:10px 14px; font-size:13px; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
    .helper-text { font-size:12px; color:var(--text-muted); margin-top:10px; line-height:1.6; text-align:center; }
    .helper-text a { color:var(--maroon); font-weight:600; text-decoration:none; }
</style>

<nav class="navbar-main">
    <div class="navbar-inner">
        <a href="index.php" class="brand-logo">AL-Ghuse <span>Tailor</span></a>
        <div></div>
        <a href="login.php" class="btn-login-nav">Login</a>
    </div>
</nav>

<div class="auth-wrap">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-header-inner">
                <div class="auth-logo">AL-Ghuse <span>Tailor</span></div>
                <p class="auth-subtitle">Enter the code sent to <?= htmlspecialchars($email) ?></p>
            </div>
        </div>
        <div class="auth-body">
            <?php if (isset($error)): ?>
            <div class="error-msg">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>

            <?php if (isset($resent)): ?>
            <div class="success-msg">
                <i class="bi bi-check-circle-fill"></i>
                A new code has been sent to your email.
            </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label" style="text-align:center; display:block;">6-Digit Code</label>
                    <input type="text" name="otp" class="form-control" placeholder="000000"
                           maxlength="6" pattern="[0-9]{6}" inputmode="numeric" required autofocus>
                </div>

                <button type="submit" name="verify_otp" class="btn-auth">
                    <i class="bi bi-shield-check me-2"></i> Verify Code
                </button>
            </form>

            <p class="helper-text">
                Didn't get the code? <a href="verify-otp.php?resend=1">Resend Code</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>
