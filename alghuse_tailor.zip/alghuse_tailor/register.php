<?php
include 'config.php';
error_reporting(0);
session_start();

if (isset($_SESSION['user_id'])) { header('location:index.php'); exit; }

if (isset($_POST['register'])) {
    $name     = $conn->real_escape_string(trim($_POST['name']));
    $email    = $conn->real_escape_string(trim($_POST['email']));
    $phone    = $conn->real_escape_string(trim($_POST['phone']));
    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm_password']);

    if (empty($name) || empty($email) || empty($password)) {
        $error = 'Please fill all required fields';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match';
    } else {
        $check = $conn->query("SELECT * FROM users WHERE email='$email'");
        if (mysqli_num_rows($check) > 0) {
            $error = 'This email is already registered. Please login.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $conn->query("INSERT INTO users (name, email, phone, password) VALUES ('$name','$email','$phone','$hashed')");
            $user_id = $conn->insert_id;
            $_SESSION['user_id']   = $user_id;
            $_SESSION['user_name'] = $name;
            header('location:index.php'); exit;
        }
    }
}

$page_title = 'Register';
include 'includes/head.php';
?>
<style>
    .auth-wrap { min-height:calc(100vh - 68px); display:flex; align-items:center; justify-content:center; padding:48px 24px; background:var(--ivory); }
    .auth-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow-md); width:100%; max-width:480px; }
    .auth-header { background:var(--maroon); padding:28px 36px; text-align:center; position:relative; overflow:hidden; }
    .auth-header::before { content:''; position:absolute; inset:0; background:repeating-linear-gradient(45deg,transparent,transparent 30px,rgba(255,255,255,0.03) 30px,rgba(255,255,255,0.03) 60px); }
    .auth-header-inner { position:relative; z-index:1; }
    .auth-logo { font-family:'Playfair Display',serif; font-size:22px; font-weight:700; color:var(--white); margin-bottom:6px; }
    .auth-logo span { color:var(--gold-light); }
    .auth-subtitle { font-size:13px; color:rgba(255,255,255,0.7); }
    .auth-body { padding:32px 36px; }
    .auth-tabs { display:flex; gap:0; margin-bottom:28px; border:1px solid var(--border); border-radius:6px; overflow:hidden; }
    .auth-tab { flex:1; padding:10px; text-align:center; font-size:13px; font-weight:600; color:var(--text-mid); text-decoration:none; transition:all 0.2s; }
    .auth-tab.active { background:var(--maroon); color:var(--white); }
    .auth-tab:not(.active):hover { background:var(--cream); }
    .form-group { margin-bottom:18px; }
    .form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-label span { color:#e53e3e; }
    .form-control { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus { border-color:var(--maroon); box-shadow:0 0 0 3px rgba(123,26,26,0.08); outline:none; }
    .input-icon-wrap { position:relative; }
    .input-icon-wrap .form-control { padding-right:42px; }
    .input-icon { position:absolute; right:12px; top:50%; transform:translateY(-50%); color:var(--text-muted); font-size:16px; cursor:pointer; }
    .btn-auth { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:13px; font-size:14px; font-weight:700; cursor:pointer; letter-spacing:0.4px; transition:background 0.2s; margin-top:8px; }
    .btn-auth:hover { background:var(--maroon-dark); }
    .error-msg { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; border-radius:6px; padding:10px 14px; font-size:13px; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
    .strength-bar { height:3px; border-radius:2px; margin-top:6px; transition:all 0.3s; }
    .strength-weak   { background:#ef4444; width:33%; }
    .strength-medium { background:#f59e0b; width:66%; }
    .strength-strong { background:#10b981; width:100%; }
    .terms-check { display:flex; align-items:flex-start; gap:10px; margin-bottom:8px; }
    .terms-check input { margin-top:2px; accent-color:var(--maroon); }
    .terms-check label { font-size:12px; color:var(--text-mid); line-height:1.6; }
    .terms-check a { color:var(--maroon); }
    .auth-footer { text-align:center; margin-top:20px; font-size:13px; color:var(--text-muted); }
    .auth-footer a { color:var(--maroon); text-decoration:none; font-weight:600; }
    @media (max-width:480px) { .form-row-2 { grid-template-columns:1fr; } }
</style>

<nav class="navbar-main">
    <div class="navbar-inner">
        <a href="index.php" class="brand-logo">AL-Ghuse <span>Tailor</span></a>
        <div></div>
        <a href="login.php" class="btn-login-nav">Login </a>
    </div>
</nav>

<div class="auth-wrap">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-header-inner">
                <div class="auth-logo">AL-Ghuse <span>Tailor</span></div>
                <p class="auth-subtitle">Create a new account</p>
            </div>
        </div>
        <div class="auth-body">
            <div class="auth-tabs">
                <a href="login.php"    class="auth-tab">Login</a>
                <a href="register.php" class="auth-tab active">Register</a>
            </div>

            <?php if (isset($error)): ?>
            <div class="error-msg">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-row-2">
                    <div class="form-group">
                        <label class="form-label">Full Name <span>*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Full Name"
                               value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone Number</label>
                        <input type="tel" name="phone" class="form-control" placeholder="03xx-xxxxxxx"
                               value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Email Address <span>*</span></label>
                    <div class="input-icon-wrap">
                        <input type="email" name="email" class="form-control" placeholder="your@email.com"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        <i class="bi bi-envelope input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Password <span>*</span></label>
                    <div class="input-icon-wrap">
                        <input type="password" name="password" id="pwd1" class="form-control"
                               placeholder="Password can be any combination of letters and numbers" required oninput="checkStrength(this.value)">
                        <i class="bi bi-eye input-icon" id="t1" onclick="toggleField('pwd1','t1')"></i>
                    </div>
                    <div class="strength-bar" id="strength-bar"></div>
                </div>

                <div class="form-group">
                    <label class="form-label">Confirm Password <span>*</span></label>
                    <div class="input-icon-wrap">
                        <input type="password" name="confirm_password" id="pwd2" class="form-control"
                               placeholder="Confirm Password" required>
                        <i class="bi bi-eye input-icon" id="t2" onclick="toggleField('pwd2','t2')"></i>
                    </div>
                </div>

                <div class="terms-check">
                    <input type="checkbox" id="terms" required>
                    <label for="terms">
                        I agree to the <a href="terms.php">Terms & Conditions</a> and
                        <a href="privacy.php">Privacy Policy</a>
                    </label>
                </div>

                <button type="submit" name="register" class="btn-auth">
                    <i class="bi bi-person-plus me-2"></i> Create Account
                </button>
            </form>

            <div class="auth-footer">
                Already have an account? <a href="login.php">Login Here</a>
            </div>
        </div>
    </div>
</div>

<a href="https://wa.me/923001234567" class="wa-float" target="_blank">
    <i class="bi bi-whatsapp"></i>
</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleField(id, iconId) {
    const f = document.getElementById(id);
    const i = document.getElementById(iconId);
    f.type = f.type === 'password' ? 'text' : 'password';
    i.classList.toggle('bi-eye'); i.classList.toggle('bi-eye-slash');
}
function checkStrength(pwd) {
    const bar = document.getElementById('strength-bar');
    bar.className = 'strength-bar';
    if (!pwd) return;
    if (pwd.length < 6)  { bar.classList.add('strength-weak'); return; }
    const strong = /(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%])/.test(pwd);
    const medium = /(?=.*[a-zA-Z])(?=.*[0-9])/.test(pwd);
    bar.classList.add(strong ? 'strength-strong' : medium ? 'strength-medium' : 'strength-weak');
}
</script>
</body>
</html>
