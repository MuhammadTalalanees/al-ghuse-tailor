<?php
include 'config.php';
error_reporting(0);
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
$user_id = $_SESSION['user_id'] ?? null;

// Add to cart
if (isset($_POST['add_to_cart'])) {
    if (!$user_id) {
        $message[] = 'Please login first to add to cart';
    } else {
        $suit_name  = $conn->real_escape_string($_POST['suit_name']);
        $suit_id    = (int)$_POST['suit_id'];
        $suit_image = $conn->real_escape_string($_POST['suit_image']);
        $suit_price = $conn->real_escape_string($_POST['suit_price']);
        $size       = $conn->real_escape_string($_POST['size'] ?? 'M');
        $total      = number_format($suit_price * 1);

        // Custom size -> detail page pe bhejo taake measurements le sakein
        if ($size === 'Custom') {
            header('location: suit_detail.php?id=' . $suit_id . '&name=' . urlencode($suit_name) . '&custom=1');
            exit;
        }

        $check = $conn->query("SELECT * FROM cart WHERE suit_id='$suit_id' AND user_id='$user_id' AND size='$size'");
        if (mysqli_num_rows($check) > 0) {
            $message[] = 'This suit (size ' . $size . ') is already in your cart';
        } else {
            $conn->query("INSERT INTO cart (user_id,suit_id,name,price,image,quantity,size,measurements,total) VALUES ('$user_id','$suit_id','$suit_name','$suit_price','$suit_image','1','$size',NULL,'$total')");
            $message[] = 'Suit (size ' . $size . ') added to cart!';
        }
    }
}

// Filters
$cat    = isset($_GET['cat'])    ? $conn->real_escape_string($_GET['cat'])    : '';
$sort   = isset($_GET['sort'])   ? $conn->real_escape_string($_GET['sort'])   : '';
$fabric = isset($_GET['fabric']) ? $conn->real_escape_string($_GET['fabric']) : '';
$min    = isset($_GET['min'])    ? (int)$_GET['min'] : 0;
$max    = isset($_GET['max']) && $_GET['max'] !== '' ? (int)$_GET['max'] : 999999;

$where = "WHERE price BETWEEN $min AND $max";
if ($cat)    $where .= " AND category='$cat'";
if ($fabric) $where .= " AND fabric='$fabric'";

$order = match($sort) {
    'price_asc'  => 'ORDER BY price ASC',
    'price_desc' => 'ORDER BY price DESC',
    'new'        => 'ORDER BY date DESC',
    default      => 'ORDER BY date DESC'
};

// Total count first (separate query, doesn't consume the result set we need later)
$count_result = $conn->query("SELECT COUNT(*) AS cnt FROM suits_info $where") or die('Query failed: ' . $conn->error);
$total_rows   = mysqli_fetch_assoc($count_result)['cnt'];

// Pagination
$per_page    = 12;
$total_pages = max(1, ceil($total_rows / $per_page));
$page_num    = max(1, (int)($_GET['page'] ?? 1));
$offset      = ($page_num - 1) * $per_page;

$suits = $conn->query("SELECT * FROM suits_info $where $order LIMIT $per_page OFFSET $offset") or die('Query failed: ' . $conn->error);

$page_title  = $cat ? $cat . ' Collection' : 'All Products';
$active_page = 'shop';
include 'includes/head.php';
?>
<style>
    .shop-layout { max-width:1240px; margin:auto; padding:40px 24px 64px; display:grid; grid-template-columns:260px 1fr; gap:36px; }
    .sidebar { position:sticky; top:88px; align-self:start; }
    .filter-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); padding:24px; margin-bottom:20px; }
    .filter-card h5 { font-size:11px; letter-spacing:2px; text-transform:uppercase; color:var(--gold); font-weight:600; margin-bottom:16px; }
    .filter-item { display:flex; align-items:center; gap:10px; margin-bottom:10px; cursor:pointer; }
    .filter-item input[type=radio], .filter-item input[type=checkbox] { accent-color:var(--maroon); width:15px; height:15px; cursor:pointer; }
    .filter-item label { font-size:13px; color:var(--text-mid); cursor:pointer; }
    .filter-item label:hover { color:var(--maroon); }
    .price-inputs { display:flex; gap:8px; align-items:center; }
    .price-inputs input { width:100%; border:1px solid var(--border); border-radius:6px; padding:8px 10px; font-size:13px; background:var(--ivory); }
    .price-inputs input:focus { border-color:var(--maroon); outline:none; }
    .btn-filter-apply { background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:10px; font-size:12px; font-weight:600; width:100%; cursor:pointer; margin-top:14px; transition:background 0.2s; }
    .btn-filter-apply:hover { background:var(--maroon-dark); }
    .btn-filter-clear { background:transparent; color:var(--text-muted); border:1px solid var(--border); border-radius:6px; padding:8px; font-size:12px; width:100%; cursor:pointer; margin-top:8px; transition:all 0.2s; }
    .btn-filter-clear:hover { border-color:var(--maroon); color:var(--maroon); }
    .sort-bar { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:1px solid var(--border); flex-wrap:wrap; gap:12px; }
    .sort-bar-left { font-size:14px; color:var(--text-mid); }
    .sort-bar-left strong { color:var(--charcoal); }
    .sort-select { border:1px solid var(--border); border-radius:6px; padding:8px 12px; font-size:13px; color:var(--text-mid); background:var(--white); cursor:pointer; }
    .pagination-wrap { display:flex; justify-content:center; gap:8px; padding:32px 0; }
    .page-btn { width:38px; height:38px; border:1px solid var(--border); border-radius:6px; display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:500; color:var(--text-mid); text-decoration:none; transition:all 0.2s; }
    .page-btn:hover, .page-btn.active { background:var(--maroon); color:var(--white); border-color:var(--maroon); }
    .card-size-select { border:1px solid var(--border); border-radius:6px; padding:6px 8px; font-size:12px; color:var(--text-mid); background:var(--ivory); cursor:pointer; width:100%; margin-bottom:8px; }
    .card-size-select:focus { border-color:var(--maroon); outline:none; }

    /* Product grid (same as index.php) */
    .products-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(230px, 1fr)); gap:22px; }
    .product-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; transition:box-shadow 0.25s, transform 0.25s; }
    .product-card:hover { box-shadow:var(--shadow-md); transform:translateY(-3px); }
    .card-img-wrap { position:relative; height:280px; overflow:hidden; background:var(--cream); }
    .card-img-wrap img { width:100%; height:100%; object-fit:cover; transition:transform 0.4s ease; }
    .product-card:hover .card-img-wrap img { transform:scale(1.04); }
    .card-wish { position:absolute; top:12px; right:12px; width:32px; height:32px; background:var(--white); border:none; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:16px; color:var(--text-muted); cursor:pointer; box-shadow:var(--shadow-sm); transition:color 0.2s; }
    .card-wish:hover { color:var(--maroon); }
    .card-body { padding:16px 18px 18px; }
    .card-fabric { font-size:10px; letter-spacing:1.5px; text-transform:uppercase; color:var(--text-muted); margin-bottom:5px; }
    .card-name { font-family:'Playfair Display', serif; font-size:16px; font-weight:500; color:var(--charcoal); margin-bottom:10px; line-height:1.3; }
    .card-name a { color:inherit; text-decoration:none; }
    .card-name a:hover { color:var(--maroon); }
    .card-price { font-size:17px; font-weight:600; color:var(--maroon); margin-bottom:10px; }
    .card-price .currency { font-size:11px; font-weight:400; color:var(--text-muted); margin-right:2px; }
    .card-actions { display:flex; gap:8px; }
    .btn-cart { background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:8px 14px; font-size:12px; font-weight:600; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:5px; transition:background 0.2s; letter-spacing:0.3px; flex:1; }
    .btn-cart:hover { background:var(--maroon-dark); }
    .btn-details { border:1px solid var(--border); background:var(--white); color:var(--text-mid); border-radius:6px; padding:8px 12px; font-size:12px; font-weight:500; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; transition:border-color 0.2s, color 0.2s; }
    .btn-details:hover { border-color:var(--maroon); color:var(--maroon); }
    .empty-state { text-align:center; padding:48px 24px; color:var(--text-muted); grid-column:1/-1; }
    .empty-state i { font-size:40px; margin-bottom:12px; display:block; }
    .empty-state p { font-size:14px; }

    @media (max-width:900px) { .shop-layout { grid-template-columns:1fr; } .sidebar { position:static; } }
</style>

<?php include 'includes/navbar.php'; ?>

<!-- TOAST -->
<?php if (isset($message)): ?>
    <?php foreach ($message as $msg): ?>
        <div class="toast-msg" id="toast-msg"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($msg) ?></div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- PAGE HERO -->
<div class="page-hero">
    <div class="page-hero-inner">
        <p class="page-hero-eyebrow">AL-Ghuse Tailor</p>
        <h1><?= $cat ? htmlspecialchars($cat).' Collection' : 'Full Collection' ?></h1>
        <p>Premium quality suits — the pride of Karachi</p>
    </div>
</div>
<div class="breadcrumb-bar">
    <div class="inner">
        <a href="index.php">Home</a> / <a href="shop.php">Shop</a>
        <?php if ($cat) echo ' / <span>' . htmlspecialchars($cat) . '</span>'; ?>
    </div>
</div>

<!-- SHOP LAYOUT -->
<div class="shop-layout">

    <!-- SIDEBAR FILTERS -->
    <aside class="sidebar">
        <form method="GET" action="shop.php" id="filter-form">
            <!-- Categories -->
            <div class="filter-card">
                <h5><i class="bi bi-grid me-1"></i> Category</h5>
                <?php
                $cats = ['Formal','Casual','Unstitched','Kids'];
                foreach ($cats as $c):
                ?>
                <div class="filter-item">
                    <input type="radio" name="cat" id="cat_<?= $c ?>" value="<?= $c ?>"
                           <?= $cat === $c ? 'checked' : '' ?> onchange="this.form.submit()">
                    <label for="cat_<?= $c ?>"><?= $c ?></label>
                </div>
                <?php endforeach; ?>
                <div class="filter-item">
                    <input type="radio" name="cat" id="cat_all" value="" <?= !$cat ? 'checked' : '' ?> onchange="this.form.submit()">
                    <label for="cat_all">All Categories</label>
                </div>
            </div>

            <!-- Price Range -->
            <div class="filter-card">
                <h5><i class="bi bi-cash-coin me-1"></i> Price Range (PKR)</h5>
                <div class="price-inputs">
                    <input type="number" name="min" placeholder="Min" value="<?= $min ?: '' ?>">
                    <span style="color:var(--text-muted)">—</span>
                    <input type="number" name="max" placeholder="Max" value="<?= $max < 999999 ? $max : '' ?>">
                </div>
            </div>

            <!-- Fabric -->
            <div class="filter-card">
                <h5><i class="bi bi-scissors me-1"></i> Fabric</h5>
                <?php
                $fabrics = ['Lawn','Chiffon','Georgette','Cotton','Khaddar','Silk','Net'];
                foreach ($fabrics as $f):
                ?>
                <div class="filter-item">
                    <input type="radio" name="fabric" id="fab_<?= $f ?>" value="<?= $f ?>"
                           <?= $fabric === $f ? 'checked' : '' ?> onchange="this.form.submit()">
                    <label for="fab_<?= $f ?>"><?= $f ?></label>
                </div>
                <?php endforeach; ?>
                <div class="filter-item">
                    <input type="radio" name="fabric" id="fab_all" value="" <?= !$fabric ? 'checked' : '' ?> onchange="this.form.submit()">
                    <label for="fab_all">All Fabrics</label>
                </div>
            </div>

            <!-- Sort hidden -->
            <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">

            <button type="submit" class="btn-filter-apply"><i class="bi bi-funnel me-1"></i> Apply Filters</button>
            <a href="shop.php" class="btn-filter-clear d-block text-center text-decoration-none">Clear Filters</a>
        </form>
    </aside>

    <!-- MAIN CONTENT -->
    <main>
        <!-- Sort Bar -->
        <div class="sort-bar">
            <div class="sort-bar-left">
                <strong><?= $total_rows ?></strong> suits mile
                <?= $cat ? ' in <strong>'.htmlspecialchars($cat).'</strong>' : '' ?>
            </div>
            <form method="GET" action="shop.php" id="sort-form">
                <input type="hidden" name="cat"    value="<?= htmlspecialchars($cat) ?>">
                <input type="hidden" name="fabric" value="<?= htmlspecialchars($fabric) ?>">
                <input type="hidden" name="min"    value="<?= $min ?>">
                <input type="hidden" name="max"    value="<?= $max < 999999 ? $max : '' ?>">
                <select name="sort" class="sort-select" onchange="document.getElementById('sort-form').submit()">
                    <option value="new"        <?= $sort === 'new'        ? 'selected' : '' ?>>Newest</option>
                    <option value="price_asc"  <?= $sort === 'price_asc'  ? 'selected' : '' ?>>Price: Low to High</option>
                    <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
                </select>
            </form>
        </div>

        <!-- PRODUCT GRID -->
        <div class="products-grid">
            <?php if (mysqli_num_rows($suits) > 0): ?>
                <?php while ($s = mysqli_fetch_assoc($suits)): ?>
                <div class="product-card">
                    <div class="card-img-wrap">
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                            <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                        </a>
                        <button class="card-wish" title="Add to wishlist"><i class="bi bi-heart"></i></button>
                    </div>
                    <div class="card-body">
                        <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? '') ?></p>
                        <h3 class="card-name">
                            <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                                <?= htmlspecialchars($s['name']) ?>
                            </a>
                        </h3>
                        <div class="card-price">
                            <span class="currency">PKR</span><?= number_format($s['price']) ?>
                        </div>

                        <form method="POST" action="">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">

                            <select name="size" class="card-size-select">
                                <option value="S">Size: S</option>
                                <option value="M" selected>Size: M</option>
                                <option value="L">Size: L</option>
                                <option value="XL">Size: XL</option>
                                <option value="Custom">Custom Measurements</option>
                            </select>

                            <div class="card-actions">
                                <button type="submit" name="add_to_cart" class="btn-cart">
                                    <i class="bi bi-bag-plus"></i> Add to Cart
                                </button>
                                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>"
                                   class="btn-details">Details</a>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="bi bi-bag-x"></i>
                    <p>No suits found matching your filters</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- PAGINATION -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination-wrap">
            <?php
            $base_qs = http_build_query([
                'cat'    => $cat,
                'fabric' => $fabric,
                'min'    => $min ?: '',
                'max'    => $max < 999999 ? $max : '',
                'sort'   => $sort,
            ]);
            for ($p = 1; $p <= $total_pages; $p++):
            ?>
            <a href="shop.php?<?= $base_qs ?>&page=<?= $p ?>"
               class="page-btn <?= $p === $page_num ? 'active' : '' ?>"><?= $p ?></a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    </main>
</div>

<?php include 'includes/footer.php'; ?>
<script>
setTimeout(() => {
    const t = document.getElementById('toast-msg');
    if (t) { t.style.opacity = '0'; t.style.transition = 'opacity 0.5s'; setTimeout(() => t.remove(), 500); }
}, 4000);
</script>
