<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;

$suit_id = (int)($_GET['id'] ?? 0);
if (!$suit_id) { header('location:shop.php'); exit; }

$result = $conn->query("SELECT * FROM suits_info WHERE sid='$suit_id'");
if (!$result || mysqli_num_rows($result) === 0) { header('location:shop.php'); exit; }
$s = mysqli_fetch_assoc($result);

$is_custom = isset($_GET['custom']) && $_GET['custom'] == '1';

// Add to cart
if (isset($_POST['add_to_cart'])) {
    if (!$user_id) {
        $message[] = 'Please login first to add to cart';
    } else {
        $size = $conn->real_escape_string($_POST['size'] ?? 'M');

        // Agar user ne "Custom" select kiya lekin abhi measurement form nahi bhara,
        // to usay measurement form wale page pe bhejo
        if ($size === 'Custom' && !$is_custom) {
            header('location: suit_detail.php?id=' . $suit_id . '&name=' . urlencode($s['name']) . '&custom=1');
            exit;
        }

        $check = $conn->query("SELECT * FROM cart WHERE suit_id='$suit_id' AND user_id='$user_id' AND size='$size'");
        if (mysqli_num_rows($check) > 0) {
            $message[] = 'This suit (size ' . $size . ') is already in your cart';
        } else {
            if ($size === 'Custom') {
                // Measurements ko JSON format mein save karo
                $measurements = json_encode([
                    'chest'    => $conn->real_escape_string($_POST['chest'] ?? ''),
                    'shoulder' => $conn->real_escape_string($_POST['shoulder'] ?? ''),
                    'length'   => $conn->real_escape_string($_POST['length'] ?? ''),
                    'sleeve'   => $conn->real_escape_string($_POST['sleeve'] ?? ''),
                    'waist'    => $conn->real_escape_string($_POST['waist'] ?? ''),
                    'hip'      => $conn->real_escape_string($_POST['hip'] ?? ''),
                    'notes'    => $conn->real_escape_string($_POST['measure_notes'] ?? ''),
                ]);
                $measurements_sql = "'" . $conn->real_escape_string($measurements) . "'";
                $qty = 1;
            } else {
                $measurements_sql = 'NULL';
                $qty = (int)($_POST['quantity'] ?? 1);
            }

            $total = $s['price'] * $qty;

            $conn->query("INSERT INTO cart (user_id,suit_id,name,price,image,quantity,size,measurements,total)
                          VALUES ('$user_id','$suit_id','" . addslashes($s['name']) . "','{$s['price']}',
                          '" . addslashes($s['image']) . "','$qty','$size',$measurements_sql,'$total')")
                or die('Add to cart failed: ' . $conn->error);

            $message[] = $size === 'Custom'
                ? 'Custom suit added to cart with your measurements!'
                : 'Suit (size ' . $size . ') added to cart!';
        }
    }
}

// Add to wishlist
if (isset($_POST['add_wishlist'])) {
    if (!$user_id) {
        $message[] = 'Please login first to use wishlist';
    } else {
        $wcheck = $conn->query("SELECT * FROM wishlist WHERE suit_id='$suit_id' AND user_id='$user_id'");
        if (mysqli_num_rows($wcheck) > 0) {
            $message[] = 'Already in wishlist!';
        } else {
            $conn->query("INSERT INTO wishlist (user_id,suit_id,name,price,image) VALUES ('$user_id','$suit_id','".addslashes($s['name'])."','$s[price]','".addslashes($s['image'])."')");
            $message[] = 'Added to wishlist!';
        }
    }
}

// Related suits
$related = $conn->query("SELECT * FROM suits_info WHERE category='{$s['category']}' AND sid != '$suit_id' LIMIT 4");

$page_title  = $s['name'];
$active_page = 'shop';
include 'includes/head.php';
?>
<style>
    .detail-wrap { max-width:1200px; margin:auto; padding:48px 24px 64px; }
    .detail-grid { display:grid; grid-template-columns:1fr 1fr; gap:56px; align-items:start; }
    .detail-img-main { border-radius:var(--radius); overflow:hidden; background:var(--cream); border:1px solid var(--border); aspect-ratio:3/4; }
    .detail-img-main img { width:100%; height:100%; object-fit:cover; display:block; }
    .detail-thumbs { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-top:12px; }
    .detail-thumb { border-radius:6px; overflow:hidden; border:1px solid var(--border); cursor:pointer; aspect-ratio:1; background:var(--cream); transition:border-color 0.2s; }
    .detail-thumb.active { border-color:var(--maroon); }
    .detail-thumb img { width:100%; height:100%; object-fit:cover; }
    .detail-info { position:sticky; top:88px; }
    .detail-cat { display:inline-block; background:var(--cream); color:var(--maroon); font-size:10px; font-weight:700; padding:4px 12px; border-radius:20px; letter-spacing:1px; text-transform:uppercase; margin-bottom:14px; }
    .detail-name { font-family:'Playfair Display',serif; font-size:32px; font-weight:700; color:var(--charcoal); line-height:1.2; margin-bottom:12px; }
    .detail-price { font-size:28px; font-weight:700; color:var(--maroon); margin-bottom:6px; }
    .detail-price .currency { font-size:14px; font-weight:400; color:var(--text-muted); }
    .detail-fabric-row { display:flex; gap:16px; margin-bottom:20px; flex-wrap:wrap; }
    .detail-meta-tag { background:var(--cream); border:1px solid var(--border); border-radius:6px; padding:6px 14px; font-size:12px; color:var(--text-mid); display:flex; align-items:center; gap:6px; }
    .detail-meta-tag i { color:var(--gold); }
    .detail-divider { border:none; border-top:1px solid var(--border); margin:20px 0; }
    .detail-desc { font-size:14px; line-height:1.8; color:var(--text-mid); margin-bottom:24px; }
    .qty-row { display:flex; align-items:center; gap:16px; margin-bottom:20px; flex-wrap:wrap; }
    .qty-label { font-size:12px; font-weight:600; color:var(--charcoal); letter-spacing:0.5px; text-transform:uppercase; }
    .qty-controls { display:flex; align-items:center; border:1px solid var(--border); border-radius:6px; overflow:hidden; }
    .qty-btn { width:36px; height:36px; background:var(--cream); border:none; font-size:16px; cursor:pointer; color:var(--charcoal); transition:background 0.2s; }
    .qty-btn:hover { background:var(--maroon); color:var(--white); }
    .qty-input { width:48px; height:36px; border:none; border-left:1px solid var(--border); border-right:1px solid var(--border); text-align:center; font-size:14px; font-weight:600; color:var(--charcoal); background:var(--white); }
    .size-select { border:1px solid var(--border); border-radius:6px; padding:9px 14px; font-size:13px; color:var(--charcoal); background:var(--ivory); cursor:pointer; }
    .size-select:focus { border-color:var(--maroon); outline:none; }
    .detail-actions { display:flex; gap:12px; flex-wrap:wrap; }
    .btn-add-cart { flex:1; min-width:180px; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:14px; font-size:13px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; letter-spacing:0.4px; }
    .btn-add-cart:hover { background:var(--maroon-dark); }
    .btn-wishlist-detail { background:transparent; border:1.5px solid var(--border); color:var(--text-mid); border-radius:6px; padding:14px 18px; font-size:18px; cursor:pointer; transition:all 0.2s; }
    .btn-wishlist-detail:hover { border-color:var(--maroon); color:var(--maroon); }
    .btn-whatsapp-order { flex:1; min-width:180px; background:#25D366; color:var(--white); border:none; border-radius:6px; padding:14px; font-size:13px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; text-decoration:none; }
    .btn-whatsapp-order:hover { background:#1ebe5d; color:var(--white); }
    .guarantee-strip { background:var(--cream); border:1px solid var(--border); border-radius:var(--radius); padding:16px 20px; display:flex; gap:20px; flex-wrap:wrap; margin-top:24px; }
    .g-item { display:flex; align-items:center; gap:8px; font-size:12px; color:var(--text-mid); }
    .g-item i { color:var(--maroon); font-size:16px; }
    .related-section { max-width:1200px; margin:auto; padding:0 24px 64px; }
    .related-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:24px; }

    /* Custom measurement form */
    .measure-box { background:var(--cream); border:1.5px solid var(--gold); border-radius:var(--radius); padding:22px; margin-bottom:20px; }
    .measure-box h4 { font-family:'Playfair Display',serif; font-size:16px; color:var(--maroon); margin-bottom:4px; display:flex; align-items:center; gap:8px; }
    .measure-box p.hint { font-size:12px; color:var(--text-mid); margin-bottom:16px; }
    .measure-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:14px; }
    .measure-field label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.5px; text-transform:uppercase; margin-bottom:6px; display:block; }
    .measure-field input, .measure-field textarea { width:100%; border:1px solid var(--border); border-radius:6px; padding:9px 12px; font-size:13px; background:var(--white); }
    .measure-field input:focus, .measure-field textarea:focus { border-color:var(--maroon); outline:none; }
    .measure-back-link { font-size:12px; color:var(--maroon); text-decoration:none; display:inline-flex; align-items:center; gap:4px; margin-bottom:14px; }

    @media (max-width:768px) { .detail-grid { grid-template-columns:1fr; gap:32px; } .detail-info { position:static; } .detail-name { font-size:24px; } .measure-grid { grid-template-columns:1fr; } }
</style>

<?php include 'includes/navbar.php'; ?>

<!-- TOAST -->
<?php if (isset($message)): ?>
    <?php foreach ($message as $msg): ?>
        <div class="toast-msg" id="toast-msg"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($msg) ?></div>
    <?php endforeach; ?>
<?php endif; ?>

<div class="breadcrumb-bar">
    <div class="inner">
        <a href="index.php">Home</a> / <a href="shop.php">Shop</a>
        / <a href="shop.php?cat=<?= urlencode($s['category']) ?>"><?= htmlspecialchars($s['category']) ?></a>
        / <?= htmlspecialchars($s['name']) ?>
    </div>
</div>

<div class="detail-wrap">
    <div class="detail-grid">
        <!-- IMAGE -->
        <div>
            <div class="detail-img-main" id="main-img-wrap">
                <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" id="main-img">
            </div>
            <div class="detail-thumbs">
                <div class="detail-thumb active" onclick="changeImg('suits/<?= htmlspecialchars($s['image']) ?>', this)">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="thumb 1">
                </div>
                <div class="detail-thumb" onclick="changeImg('suits/<?= htmlspecialchars($s['image']) ?>', this)">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="thumb 2">
                </div>
            </div>
        </div>

        <!-- INFO -->
        <div class="detail-info">
            <span class="detail-cat"><?= htmlspecialchars($s['category']) ?></span>
            <h1 class="detail-name"><?= htmlspecialchars($s['name']) ?></h1>
            <div class="detail-price"><span class="currency">PKR </span><?= number_format($s['price']) ?></div>

            <div class="detail-fabric-row">
                <?php if ($s['fabric']): ?>
                <span class="detail-meta-tag"><i class="bi bi-scissors"></i> <?= htmlspecialchars($s['fabric']) ?></span>
                <?php endif; ?>
                <span class="detail-meta-tag"><i class="bi bi-patch-check"></i> Original Fabric</span>
                <span class="detail-meta-tag"><i class="bi bi-truck"></i> Home Delivery</span>
            </div>

            <hr class="detail-divider">

            <p class="detail-desc">
                <?= $s['description'] ? nl2br(htmlspecialchars($s['description'])) : 'This suit is made from premium quality fabric. It comes with a guarantee from AL-Ghuse Tailor. Our custom stitching service is also available for a perfect fit.' ?>
            </p>

            <?php if ($is_custom): ?>
            <!-- ================= CUSTOM MEASUREMENT FORM ================= -->
            <a href="suit_detail.php?id=<?= $suit_id ?>&name=<?= urlencode($s['name']) ?>" class="measure-back-link">
                <i class="bi bi-arrow-left"></i> Back to regular sizes
            </a>
            <div class="measure-box">
                <h4><i class="bi bi-rulers"></i> Apni Measurements Dalein (inches mein)</h4>
                <p class="hint">Ye suit khaas aapke liye stitch hoga. Sahi measurements dein taake perfect fit mile.</p>

                <form method="POST" action="">
                    <input type="hidden" name="size" value="Custom">
                    <div class="measure-grid">
                        <div class="measure-field">
                            <label>Chest</label>
                            <input type="number" step="0.5" name="chest" placeholder="e.g. 40" required>
                        </div>
                        <div class="measure-field">
                            <label>Shoulder</label>
                            <input type="number" step="0.5" name="shoulder" placeholder="e.g. 18" required>
                        </div>
                        <div class="measure-field">
                            <label>Length</label>
                            <input type="number" step="0.5" name="length" placeholder="e.g. 42" required>
                        </div>
                        <div class="measure-field">
                            <label>Sleeve</label>
                            <input type="number" step="0.5" name="sleeve" placeholder="e.g. 24" required>
                        </div>
                        <div class="measure-field">
                            <label>Waist</label>
                            <input type="number" step="0.5" name="waist" placeholder="e.g. 34" required>
                        </div>
                        <div class="measure-field">
                            <label>Hip</label>
                            <input type="number" step="0.5" name="hip" placeholder="e.g. 40" required>
                        </div>
                    </div>
                    <div class="measure-field" style="margin-bottom:16px;">
                        <label>Notes (optional)</label>
                        <textarea name="measure_notes" rows="2" placeholder="Koi khaas hidayat, style ki tafseel, wagera..."></textarea>
                    </div>
                    <button type="submit" name="add_to_cart" class="btn-add-cart w-100">
                        <i class="bi bi-bag-plus"></i> Add Custom Suit to Cart
                    </button>
                </form>
            </div>
            <?php else: ?>
            <!-- ================= REGULAR SIZE + QUANTITY ================= -->
            <form method="POST" action="">
                <div class="qty-row">
                    <span class="qty-label">Size:</span>
                    <select name="size" class="size-select">
                        <option value="S">S</option>
                        <option value="M" selected>M</option>
                        <option value="L">L</option>
                        <option value="XL">XL</option>
                        <option value="Custom">Custom Measurements</option>
                    </select>

                    <span class="qty-label">Quantity:</span>
                    <div class="qty-controls">
                        <button type="button" class="qty-btn" onclick="changeQty(-1)">−</button>
                        <input type="number" name="quantity" id="qty-input" class="qty-input" value="1" min="1" max="10">
                        <button type="button" class="qty-btn" onclick="changeQty(1)">+</button>
                    </div>
                </div>

                <div class="detail-actions">
                    <button type="submit" name="add_to_cart" class="btn-add-cart">
                        <i class="bi bi-bag-plus"></i> Add to Cart
                    </button>
                    <button type="submit" name="add_wishlist" class="btn-wishlist-detail" title="Wishlist">
                        <i class="bi bi-heart"></i>
                    </button>
                </div>
            </form>
            <?php endif; ?>

            <a href="https://wa.me/923001234567?text=Hello!%20I%20want%20this%20suit%3A%20<?= urlencode($s['name']) ?>%20-%20PKR%20<?= number_format($s['price']) ?>"
               class="btn-whatsapp-order mt-3" target="_blank">
                <i class="bi bi-whatsapp"></i> Order via WhatsApp
            </a>

            <!-- Guarantee Strip -->
            <div class="guarantee-strip">
                <div class="g-item"><i class="bi bi-patch-check-fill"></i> Genuine Fabric Guarantee</div>
                <div class="g-item"><i class="bi bi-truck"></i> Karachi Delivery</div>
                <div class="g-item"><i class="bi bi-arrow-counterclockwise"></i> 7-Day Return</div>
                <div class="g-item"><i class="bi bi-cash-coin"></i> Cash on Delivery</div>
            </div>
        </div>
    </div>
</div>

<!-- RELATED SUITS -->
<?php if ($related && mysqli_num_rows($related) > 0): ?>
<div class="related-section">
    <div class="section-header">
        <div>
            <p class="section-eyebrow">From the Same Category</p>
            <h2 class="section-title">Related Suits</h2>
        </div>
        <a href="shop.php?cat=<?= urlencode($s['category']) ?>" class="see-all-link">Sab dekhein <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="related-grid">
        <?php while ($r = mysqli_fetch_assoc($related)): ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $r['sid'] ?>&name=<?= urlencode($r['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($r['image']) ?>" alt="<?= htmlspecialchars($r['name']) ?>" loading="lazy">
                </a>
                <span class="card-badge"><?= htmlspecialchars($r['category']) ?></span>
                <button class="card-wish"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($r['fabric'] ?? '') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $r['sid'] ?>&name=<?= urlencode($r['name']) ?>">
                        <?= htmlspecialchars($r['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price"><span class="currency">PKR</span><?= number_format($r['price']) ?></div>
                    <div class="card-actions">
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($r['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $r['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($r['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $r['price'] ?>">
                            <input type="hidden" name="size" value="M">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $r['sid'] ?>&name=<?= urlencode($r['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
<script>
function changeImg(src, el) {
    document.getElementById('main-img').src = src;
    document.querySelectorAll('.detail-thumb').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
}
function changeQty(delta) {
    const input = document.getElementById('qty-input');
    let val = parseInt(input.value) + delta;
    if (val < 1) val = 1;
    if (val > 10) val = 10;
    input.value = val;
}
setTimeout(() => {
    const t = document.getElementById('toast-msg');
    if (t) { t.style.opacity = '0'; t.style.transition = 'opacity 0.5s'; setTimeout(() => t.remove(), 500); }
}, 4000);
</script>
