<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;

$success = false;
if (isset($_POST['send_message'])) {
    $name    = $conn->real_escape_string(trim($_POST['name']));
    $email   = $conn->real_escape_string(trim($_POST['email']));
    $phone   = $conn->real_escape_string(trim($_POST['phone'] ?? ''));
    $subject = $conn->real_escape_string(trim($_POST['subject']));
    $msg_txt = $conn->real_escape_string(trim($_POST['message']));
    if ($name && $email && $subject && $msg_txt) {
        // Store in DB if table exists, else just show success
        @$conn->query("INSERT INTO contact_messages (name,email,phone,subject,message,created_at)
                       VALUES ('$name','$email','$phone','$subject','$msg_txt',NOW())");
        $success = true;
    } else {
        $form_error = 'Please fill all required fields';
    }
}

$page_title  = 'Contact Us';
$active_page = 'contact';
include 'includes/head.php';
?>
<style>
    .contact-wrap { max-width:1200px; margin:auto; padding:56px 24px 72px; display:grid; grid-template-columns:1fr 1fr; gap:48px; align-items:start; }
    /* Info Side */
    .contact-info h2 { font-family:'Playfair Display',serif; font-size:32px; color:var(--charcoal); margin-bottom:12px; }
    .contact-info .subtitle { font-size:15px; color:var(--text-mid); line-height:1.7; margin-bottom:36px; }
    .info-card { display:flex; gap:16px; margin-bottom:24px; align-items:flex-start; }
    .info-icon { width:48px; height:48px; background:var(--cream); border:1px solid var(--border); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:20px; color:var(--maroon); flex-shrink:0; }
    .info-content h4 { font-size:13px; font-weight:700; color:var(--charcoal); margin-bottom:4px; letter-spacing:0.3px; }
    .info-content p, .info-content a { font-size:14px; color:var(--text-mid); text-decoration:none; line-height:1.6; }
    .info-content a:hover { color:var(--maroon); }
    .social-row { display:flex; gap:12px; margin-top:32px; }
    .social-btn { width:44px; height:44px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:20px; text-decoration:none; transition:all 0.2s; }
    .social-btn.fb   { background:#1877f2; color:#fff; }
    .social-btn.ig   { background:linear-gradient(45deg,#f58529,#dd2a7b,#8134af); color:#fff; }
    .social-btn.wa   { background:#25D366; color:#fff; }
    .social-btn.tk   { background:#010101; color:#fff; }
    .social-btn:hover { transform:translateY(-3px); box-shadow:var(--shadow-md); }
    /* Map */
    .map-card { background:var(--cream); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; height:200px; margin-top:32px; display:flex; align-items:center; justify-content:center; }
    .map-card p { font-size:14px; color:var(--text-muted); text-align:center; }
    /* Form Side */
    .form-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow-sm); }
    .form-card-head { background:var(--maroon); padding:22px 28px; }
    .form-card-head h3 { font-family:'Playfair Display',serif; font-size:20px; color:var(--white); }
    .form-card-head p { font-size:13px; color:rgba(255,255,255,0.7); margin-top:4px; }
    .form-body { padding:28px; }
    .form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
    .form-group { margin-bottom:18px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-label span { color:#e53e3e; }
    .form-control, .form-select { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus, .form-select:focus { border-color:var(--maroon); outline:none; box-shadow:0 0 0 3px rgba(123,26,26,0.08); }
    textarea.form-control { resize:vertical; }
    .btn-send { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:13px; font-size:14px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; }
    .btn-send:hover { background:var(--maroon-dark); }
    .success-msg { background:#d1fae5; border:1px solid #6ee7b7; color:#065f46; border-radius:6px; padding:16px; font-size:14px; display:flex; align-items:center; gap:10px; margin-bottom:16px; }
    .error-msg-form { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; border-radius:6px; padding:12px; font-size:13px; display:flex; align-items:center; gap:8px; margin-bottom:16px; }
    /* FAQ Strip */
    .faq-section { max-width:900px; margin:auto; padding:0 24px 72px; }
    .faq-item { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); margin-bottom:12px; overflow:hidden; }
    .faq-question { padding:16px 20px; cursor:pointer; display:flex; justify-content:space-between; align-items:center; font-size:14px; font-weight:600; color:var(--charcoal); user-select:none; }
    .faq-question:hover { color:var(--maroon); }
    .faq-answer { padding:0 20px; max-height:0; overflow:hidden; transition:max-height 0.3s ease, padding 0.3s ease; font-size:13px; color:var(--text-mid); line-height:1.7; }
    .faq-item.open .faq-answer { max-height:200px; padding:0 20px 16px; }
    .faq-item.open .faq-icon { transform:rotate(45deg); }
    .faq-icon { transition:transform 0.3s; font-size:18px; color:var(--text-muted); }
    @media (max-width:768px) { .contact-wrap { grid-template-columns:1fr; } .form-row-2 { grid-template-columns:1fr; } }
</style>

<?php include 'includes/navbar.php'; ?>

<div class="page-hero">
    <div class="page-hero-inner">
        <p class="page-hero-eyebrow">Get In Touch</p>
        <h1>Contact Us</h1>
        <p>We are always here to serve you</p>
    </div>
</div>
<div class="breadcrumb-bar">
    <div class="inner"><a href="index.php">Home</a> / Contact Us</div>
</div>

<div class="contact-wrap">
    <!-- INFO -->
    <div class="contact-info">
        <h2>Contact Us</h2>
        <p class="subtitle">
            For any questions, custom orders, or feedback,
            reach out to us directly. We respond within 24 hours.
        </p>

        <div class="info-card">
            <div class="info-icon"><i class="bi bi-geo-alt-fill"></i></div>
            <div class="info-content">
                <h4>Our Office</h4>
                <p>Tariq Road, Near Main Chowk,<br>Karachi, Pakistan</p>
            </div>
        </div>
        <div class="info-card">
            <div class="info-icon"><i class="bi bi-telephone-fill"></i></div>
            <div class="info-content">
                <h4>Call Us</h4>
                <a href="tel:+923708659593">03708659593</a><br>
                
            </div>
        </div>
        <div class="info-card">
            <div class="info-icon"><i class="bi bi-whatsapp"></i></div>
            <div class="info-content">
                <h4>WhatsApp</h4>
                <a href="https://wa.me/923708659593" target="_blank">03708659593
                </a><br>
                <span style="font-size:12px;color:var(--text-muted);">Mon–Sat: 12am – 12pm</span>
            </div>
        </div>
        <div class="info-card">
            <div class="info-icon"><i class="bi bi-envelope-fill"></i></div>
            <div class="info-content">
                <h4>Email</h4>
                <a href="mailto:alghuseinfo@edu.pk">alghuseinfo@edu.pk</a><br>
            </div>
        </div>
        <div class="info-card">
            <div class="info-icon"><i class="bi bi-clock-fill"></i></div>
            <div class="info-content">
                <h4>Opening Hours</h4>
                <p>Monday – Saturday: 12:00 AM – 12:00 PM<br>
                Sunday: Closed</p>
            </div>
        </div>

        <div class="social-row">
            <a href="#" class="social-btn fb" title="Facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="social-btn ig" title="Instagram"><i class="bi bi-instagram"></i></a>
            <a href="https://wa.me/923708659593" class="social-btn wa" title="WhatsApp"><i class="bi bi-whatsapp"></i></a>
            <a href="#" class="social-btn tk" title="TikTok"><i class="bi bi-tiktok"></i></a>
        </div>

        <div class="map-card">
            <div style="text-align:center">
                <i class="bi bi-map" style="font-size:32px;color:var(--maroon);display:block;margin-bottom:8px;"></i>
                <p><strong>AL-Ghuse Tailor</strong><br>Siddiqabad, Near Hussainabad Food Street,<br>Karachi, Pakistan</p>
                <a href="https://maps.google.com/?q=Siddiqabad, Karachi, Pakistan" target="_blank"
                   style="color:var(--maroon);font-size:12px;font-weight:600;text-decoration:none;">
                    View on Google Maps →
                </a>
            </div>
        </div>
    </div>

    <!-- FORM -->
    <div>
        <div class="form-card">
            <div class="form-card-head">
                <h3>Send Message</h3>
                <p>We'll respond within 1 to 2 hours</p>
            </div>
            <div class="form-body">
                <?php if ($success): ?>
                <div class="success-msg">
                    <i class="bi bi-check-circle-fill" style="font-size:20px;"></i>
                    <div>
                        <strong>Message sent successfully!</strong><br>
                        <span style="font-size:12px;">We'll be in touch with you shortly.</span>
                    </div>
                </div>
                <?php endif; ?>
                <?php if (isset($form_error)): ?>
                <div class="error-msg-form">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($form_error) ?>
                </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Your Name <span>*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="Full name"
                                   value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone</label>
                            <input type="tel" name="phone" class="form-control" placeholder="03xx-xxxxxxx"
                                   value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email Address <span>*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="your@email.com"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Subject <span>*</span></label>
                        <select name="subject" class="form-select" required>
                            <option value="">Select topic...</option>
                            <?php foreach (['About an Order','Custom Stitching Enquiry','Delivery Query','Return / Exchange','General Question','Feedback / Complaint','Something Else'] as $sub): ?>
                            <option value="<?= $sub ?>" <?= ($_POST['subject'] ?? '') === $sub ? 'selected' : '' ?>><?= $sub ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Message <span>*</span></label>
                        <textarea name="message" class="form-control" rows="5"
                                  placeholder="Write your question or message..." required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" name="send_message" class="btn-send">
                        <i class="bi bi-send-fill"></i> Send Message
                    </button>
                </form>

                <div style="margin-top:16px;text-align:center;">
                    <span style="font-size:12px;color:var(--text-muted);">Or contact us directly on WhatsApp:</span>
                    <a href="https://wa.me/923708659593?text=Hello!"
                       target="_blank" style="display:flex;align-items:center;justify-content:center;gap:6px;background:#25D366;color:#fff;border-radius:6px;padding:10px;font-size:13px;font-weight:600;text-decoration:none;margin-top:8px;">
                        <i class="bi bi-whatsapp"></i> Contact via WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- FAQ -->
<div class="faq-section">
    <div style="text-align:center;margin-bottom:32px;">
        <p class="section-eyebrow">Common Questions</p>
        <h2 class="section-title">Frequently Asked Questions</h2>
    </div>
    <?php
    $faqs = [
        ['q'=>'How long does delivery take?',        'a'=>'Delivery takes 1-3 days within Karachi, and 3-7 working days for the rest of Pakistan.'],
        ['q'=>'Is Cash on Delivery available?',      'a'=>'Yes! We accept Cash on Delivery in Karachi Pakistan.'],
        ['q'=>'How long does custom stitching take?','a'=>'Regular suits are ready within 5-7 working days. Custom stitched suits may take 10-15 working days depending on the design and fabric.'],
        ['q'=>'What is the return policy?',                   'a'=>'Returns or exchanges are possible within 7 days for any defect. Custom stitched items cannot be returned.'],
        ['q'=>'Can I pay online?',         'a'=>'Yes, EasyPaisa, JazzCash and bank transfer are available. COD is also available.'],
    ];
    foreach ($faqs as $faq):
    ?>
    <div class="faq-item">
        <div class="faq-question" onclick="toggleFaq(this)">
            <?= htmlspecialchars($faq['q']) ?>
            <i class="bi bi-plus-circle faq-icon"></i>
        </div>
        <div class="faq-answer"><?= htmlspecialchars($faq['a']) ?></div>
    </div>
    <?php endforeach; ?>
</div>

<?php include 'includes/footer.php'; ?>
<script>
function toggleFaq(el) {
    const item = el.closest('.faq-item');
    const wasOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
    if (!wasOpen) item.classList.add('open');
}
</script>
