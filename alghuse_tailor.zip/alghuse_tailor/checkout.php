<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) { header('location:login.php?redirect=checkout'); exit; }

// Fetch cart
$cart_items = $conn->query("SELECT * FROM cart WHERE user_id='$user_id'");
$cart_arr   = [];
$grand_total = 0;
while ($row = mysqli_fetch_assoc($cart_items)) {
    $cart_arr[]   = $row;
    $grand_total += $row['total'];
}
if (empty($cart_arr)) { header('location:cart.php'); exit; }

$user = mysqli_fetch_assoc($conn->query("SELECT * FROM users WHERE user_id='$user_id'"));

// Place order
if (isset($_POST['place_order'])) {
    $name    = $conn->real_escape_string(trim($_POST['name']));
    $phone   = $conn->real_escape_string(trim($_POST['phone']));
    $address = $conn->real_escape_string(trim($_POST['address']));
    $city    = $conn->real_escape_string(trim($_POST['city']));
    $payment = $conn->real_escape_string($_POST['payment_method']);
    $notes   = $conn->real_escape_string(trim($_POST['notes'] ?? ''));

    if (empty($name) || empty($phone) || empty($address) || empty($city)) {
        $form_error = 'Please fill all required fields';
    } else {
        $conn->query("INSERT INTO orders (user_id,name,phone,address,city,payment_method,total_amount,notes,status)
                      VALUES ('$user_id','$name','$phone','$address','$city','$payment','$grand_total','$notes','Pending')");
        $order_id = $conn->insert_id;

        foreach ($cart_arr as $item) {
            $item_size = $conn->real_escape_string($item['size'] ?? 'M');
            $item_measurements = isset($item['measurements']) && $item['measurements'] !== null
                ? "'" . $conn->real_escape_string($item['measurements']) . "'"
                : 'NULL';
            $conn->query("INSERT INTO order_items (order_id,suit_id,name,price,quantity,size,measurements,total)
                          VALUES ('$order_id','{$item['suit_id']}','".addslashes($item['name'])."',
                          '{$item['price']}','{$item['quantity']}','$item_size',$item_measurements,'{$item['total']}')");
        }
        $conn->query("DELETE FROM cart WHERE user_id='$user_id'");
        header("location:order_success.php?id=$order_id"); exit;
    }
}

$page_title  = 'Checkout';
$active_page = '';
include 'includes/head.php';
?>
<style>
    .checkout-wrap { max-width:1200px; margin:auto; padding:48px 24px 72px; display:grid; grid-template-columns:1fr 380px; gap:36px; align-items:start; }
    .checkout-section { margin-bottom:28px; }
    .checkout-heading { font-family:'Playfair Display',serif; font-size:20px; font-weight:700; color:var(--charcoal); margin-bottom:20px; padding-bottom:12px; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:10px; }
    .checkout-heading i { color:var(--gold); }
    .form-group { margin-bottom:18px; }
    .form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
    .form-label { font-size:11px; font-weight:700; color:var(--charcoal); letter-spacing:0.8px; text-transform:uppercase; margin-bottom:7px; display:block; }
    .form-label span { color:#e53e3e; }
    .form-control, .form-select { width:100%; border:1px solid var(--border); border-radius:6px; padding:11px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; font-family:'Inter',sans-serif; }
    .form-control:focus, .form-select:focus { border-color:var(--maroon); outline:none; box-shadow:0 0 0 3px rgba(123,26,26,0.08); }
    /* Payment Methods */
    .payment-options { display:flex; flex-direction:column; gap:12px; }
    .payment-option { border:1.5px solid var(--border); border-radius:8px; padding:16px 18px; cursor:pointer; display:flex; align-items:center; gap:14px; transition:all 0.2s; }
    .payment-option:hover { border-color:var(--maroon); }
    .payment-option.selected { border-color:var(--maroon); background:rgba(123,26,26,0.04); }
    .payment-option input[type=radio] { accent-color:var(--maroon); width:16px; height:16px; }
    .payment-icon { width:40px; height:28px; border-radius:4px; display:flex; align-items:center; justify-content:center; font-size:20px; }
    .payment-label { font-size:14px; font-weight:600; color:var(--charcoal); }
    .payment-sublabel { font-size:12px; color:var(--text-muted); }
    /* Order Summary Sidebar */
    .order-summary-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); position:sticky; top:88px; overflow:hidden; }
    .summary-head { background:var(--maroon); padding:18px 24px; }
    .summary-head h3 { font-family:'Playfair Display',serif; font-size:18px; color:var(--white); }
    .summary-body { padding:24px; }
    .order-item-row { display:flex; gap:12px; margin-bottom:16px; align-items:center; }
    .order-item-img { width:52px; height:64px; border-radius:6px; object-fit:cover; border:1px solid var(--border); flex-shrink:0; }
    .order-item-info { flex:1; }
    .order-item-name { font-size:13px; font-weight:500; color:var(--charcoal); margin-bottom:3px; }
    .order-item-qty { font-size:11px; color:var(--text-muted); }
    .order-item-price { font-size:13px; font-weight:700; color:var(--maroon); }
    .summary-divider { border:none; border-top:1px solid var(--border); margin:16px 0; }
    .summary-row { display:flex; justify-content:space-between; margin-bottom:10px; }
    .summary-label { font-size:13px; color:var(--text-mid); }
    .summary-value { font-size:13px; font-weight:600; color:var(--charcoal); }
    .summary-total-row { display:flex; justify-content:space-between; align-items:center; }
    .summary-total-label { font-size:15px; font-weight:700; }
    .summary-total-val { font-size:22px; font-weight:700; color:var(--maroon); }
    .btn-place-order { width:100%; background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:15px; font-size:14px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:background 0.2s; margin-top:20px; }
    .btn-place-order:hover { background:var(--maroon-dark); }
    .secure-note { display:flex; align-items:center; justify-content:center; gap:6px; font-size:11px; color:var(--text-muted); margin-top:12px; }
    .error-alert { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; border-radius:6px; padding:12px 16px; font-size:13px; margin-bottom:20px; display:flex; align-items:center; gap:8px; }
    @media (max-width:900px) { .checkout-wrap { grid-template-columns:1fr; } .order-summary-card { position:static; } .form-row-2 { grid-template-columns:1fr; } }
</style>

<?php include 'includes/navbar.php'; ?>

<div class="page-hero">
    <div class="page-hero-inner">
        <p class="page-hero-eyebrow">Final Step</p>
        <h1>Checkout</h1>
    </div>
</div>
<div class="breadcrumb-bar">
    <div class="inner"><a href="index.php">Home</a> / <a href="cart.php">Cart</a> / Checkout</div>
</div>

<div class="checkout-wrap">
    <!-- LEFT: FORM -->
    <div>
        <?php if (isset($form_error)): ?>
        <div class="error-alert"><i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($form_error) ?></div>
        <?php endif; ?>

        <form method="POST" action="" id="checkout-form">
            <!-- Delivery Info -->
            <div class="checkout-section">
                <div class="content-card">
                    <div style="padding:20px 28px; border-bottom:1px solid var(--border);">
                        <h3 class="checkout-heading" style="border:none;margin:0;padding:0"><i class="bi bi-geo-alt-fill"></i> Delivery Details</h3>
                    </div>
                    <div style="padding:28px">
                        <div class="form-row-2">
                            <div class="form-group">
                                <label class="form-label">Full Name <span>*</span></label>
                                <input type="text" name="name" class="form-control"
                                       value="<?= htmlspecialchars($_POST['name'] ?? $user['name']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Phone Number <span>*</span></label>
                                <input type="tel" name="phone" class="form-control" placeholder="03xx-xxxxxxx"
                                       value="<?= htmlspecialchars($_POST['phone'] ?? $user['phone'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Delivery Address <span>*</span></label>
                            <textarea name="address" class="form-control" rows="3"
                                      placeholder="Complete home address, area, landmark..." required><?= htmlspecialchars($_POST['address'] ?? $user['address'] ?? '') ?></textarea>
                        </div>
                        <div class="form-row-2">
                            <div class="form-group">
                                <label class="form-label">City <span>*</span></label>
                                <select name="city" class="form-select" required>
                                    <option value="">Select city</option>
                                    <?php foreach (['Karachi','Lahore','Islamabad','Rawalpindi','Peshawar','Quetta','Multan','Faisalabad','Hyderabad'] as $city): ?>
                                    <option value="<?= $city ?>" <?= ($_POST['city'] ?? '') === $city ? 'selected' : '' ?>><?= $city ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Special Notes (Optional)</label>
                            <input type="text" name="notes" class="form-control" placeholder="Any special notes or instructions..."
                                   value="<?= htmlspecialchars($_POST['notes'] ?? '') ?>">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Method -->
            <div class="checkout-section">
                <div class="content-card">
                    <div style="padding:20px 28px; border-bottom:1px solid var(--border);">
                        <h3 class="checkout-heading" style="border:none;margin:0;padding:0"><i class="bi bi-credit-card-fill"></i> Payment Method</h3>
                    </div>
                    <div style="padding:28px">
                        <div class="payment-options">
                            <label class="payment-option selected" onclick="selectPayment(this)">
                                <input type="radio" name="payment_method" value="COD" checked>
                                <div class="payment-icon" style="background:#fef3c7;">💵</div>
                                <div>
                                    <div class="payment-label">Cash on Delivery</div>
                                    <div class="payment-sublabel">Pay on delivery</div>
                                </div>
                            </label>
                            <label class="payment-option" onclick="selectPayment(this)">
                                <input type="radio" name="payment_method" value="EasyPaisa">
                                <div class="payment-icon" style="background:#d1fae5;">📱</div>
                                <div>
                                    <div class="payment-label">EasyPaisa</div>
                                    <div class="payment-sublabel">Pay via mobile wallet</div>
                                </div>
                            </label>
                            <label class="payment-option" onclick="selectPayment(this)">
                                <input type="radio" name="payment_method" value="JazzCash">
                                <div class="payment-icon" style="background:#fce7f3;">💳</div>
                                <div>
                                    <div class="payment-label">JazzCash</div>
                                    <div class="payment-sublabel">Pay via JazzCash account</div>
                                </div>
                            </label>
                            <label class="payment-option" onclick="selectPayment(this)">
                                <input type="radio" name="payment_method" value="BankTransfer">
                                <div class="payment-icon" style="background:#dbeafe;">🏦</div>
                                <div>
                                    <div class="payment-label">Bank Transfer</div>
                                    <div class="payment-sublabel">Direct to bank account</div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Submit (mobile) -->
            <button type="submit" name="place_order" class="btn-place-order d-lg-none">
                <i class="bi bi-check-circle"></i> Place Order — PKR <?= number_format($grand_total) ?>
            </button>
        </form>
    </div>

    <!-- RIGHT: ORDER SUMMARY -->
    <div>
        <div class="order-summary-card">
            <div class="summary-head"><h3>Order Summary</h3></div>
            <div class="summary-body">
                <?php foreach ($cart_arr as $item): ?>
                <div class="order-item-row">
                    <img src="suits/<?= htmlspecialchars($item['image']) ?>" class="order-item-img" alt="">
                    <div class="order-item-info">
                        <div class="order-item-name"><?= htmlspecialchars($item['name']) ?></div>
                        <div class="order-item-qty">Qty: <?= $item['quantity'] ?></div>
                    </div>
                    <div class="order-item-price">PKR <?= number_format($item['total']) ?></div>
                </div>
                <?php endforeach; ?>

                <hr class="summary-divider">
                <div class="summary-row"><span class="summary-label">Subtotal</span><span class="summary-value">PKR <?= number_format($grand_total) ?></span></div>
                <div class="summary-row"><span class="summary-label">Delivery</span><span class="summary-value" style="color:green">Free</span></div>
                <div class="summary-row"><span class="summary-label">Discount</span><span class="summary-value">—</span></div>
                <hr class="summary-divider">
                <div class="summary-total-row">
                    <span class="summary-total-label">Total</span>
                    <span class="summary-total-val">PKR <?= number_format($grand_total) ?></span>
                </div>

                <button type="submit" form="checkout-form" name="place_order" class="btn-place-order">
                    <i class="bi bi-check-circle"></i> Place Order
                </button>
                <div class="secure-note">
                    <i class="bi bi-lock-fill"></i> Secure & Trusted Checkout
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
function selectPayment(el) {
    document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
}
</script>
