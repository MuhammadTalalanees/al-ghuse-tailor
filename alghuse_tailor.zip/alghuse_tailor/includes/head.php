<?php
// Shared <head> styles — include at top of every page
// Usage: include 'includes/head.php';
// Set $page_title before including.
$page_title = $page_title ?? 'AL-Ghuse Tailor';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> — AL-Ghuse Tailor</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

    <style>
        :root {
            --ivory:       #FAF7F2;
            --cream:       #F3EDE3;
            --maroon:      #7B1A1A;
            --maroon-dark: #5C1010;
            --maroon-light:#9E2A2A;
            --gold:        #C9A84C;
            --gold-light:  #E5C96C;
            --charcoal:    #2C2C2A;
            --text-mid:    #5A5751;
            --text-muted:  #9A9590;
            --white:       #FFFFFF;
            --border:      #E8E2D9;
            --shadow-sm:   0 1px 4px rgba(44,44,42,0.08);
            --shadow-md:   0 4px 20px rgba(44,44,42,0.12);
            --radius:      10px;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Inter', sans-serif; background: var(--ivory); color: var(--charcoal); }

        /* TOAST */
        .toast-msg {
            position: fixed; top: 80px; left: 50%;
            transform: translateX(-50%);
            background: var(--white); border: 1.5px solid var(--gold);
            border-radius: var(--radius); padding: 12px 24px;
            font-size: 14px; color: var(--maroon); font-weight: 500;
            box-shadow: var(--shadow-md); z-index: 9999;
            display: flex; align-items: center; gap: 10px;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity:0; transform:translateX(-50%) translateY(-10px); }
            to   { opacity:1; transform:translateX(-50%) translateY(0); }
        }

        /* NAVBAR */
        .navbar-main { background:var(--white); border-bottom:1px solid var(--border); position:sticky; top:0; z-index:1000; box-shadow:var(--shadow-sm); }
        .navbar-inner { max-width:1240px; margin:auto; padding:0 24px; display:flex; align-items:center; justify-content:space-between; height:68px; }
        .brand-logo { font-family:'Playfair Display',serif; font-size:22px; font-weight:700; color:var(--maroon); text-decoration:none; letter-spacing:0.3px; }
        .brand-logo span { color:var(--gold); }
        .nav-links { display:flex; gap:28px; list-style:none; }
        .nav-links a { font-size:13px; font-weight:500; color:var(--text-mid); text-decoration:none; letter-spacing:0.5px; text-transform:uppercase; transition:color 0.2s; }
        .nav-links a:hover, .nav-links a.active { color:var(--maroon); }
        .nav-links a.active { border-bottom:2px solid var(--gold); padding-bottom:2px; }
        .nav-actions { display:flex; align-items:center; gap:16px; }
        .nav-icon-btn { background:none; border:none; font-size:20px; color:var(--text-mid); cursor:pointer; position:relative; transition:color 0.2s; }
        .nav-icon-btn:hover { color:var(--maroon); }
        .cart-badge { position:absolute; top:-4px; right:-6px; background:var(--gold); color:var(--white); font-size:9px; font-weight:700; width:16px; height:16px; border-radius:50%; display:flex; align-items:center; justify-content:center; }
        .btn-login-nav { background:var(--maroon); color:var(--white); font-size:12px; font-weight:600; padding:8px 18px; border-radius:6px; text-decoration:none; letter-spacing:0.4px; transition:background 0.2s; }
        .btn-login-nav:hover { background:var(--maroon-dark); color:var(--white); }

        /* TRUST STRIP */
        .trust-strip { background:var(--maroon); padding:14px 24px; }
        .trust-strip-inner { max-width:1240px; margin:auto; display:flex; justify-content:center; gap:48px; flex-wrap:wrap; }
        .trust-item { display:flex; align-items:center; gap:8px; color:var(--white); font-size:12px; font-weight:500; letter-spacing:0.4px; }
        .trust-item i { color:var(--gold-light); font-size:16px; }

        /* PAGE HERO */
        .page-hero { background:var(--maroon); padding:48px 24px; text-align:center; position:relative; overflow:hidden; }
        .page-hero::before { content:''; position:absolute; inset:0; background:repeating-linear-gradient(45deg,transparent,transparent 40px,rgba(255,255,255,0.03) 40px,rgba(255,255,255,0.03) 80px); }
        .page-hero-inner { position:relative; z-index:1; }
        .page-hero-eyebrow { font-size:10px; letter-spacing:3px; text-transform:uppercase; color:var(--gold-light); font-weight:600; margin-bottom:10px; }
        .page-hero h1 { font-family:'Playfair Display',serif; font-size:38px; font-weight:700; color:var(--white); margin-bottom:10px; }
        .page-hero p { font-size:15px; color:rgba(255,255,255,0.75); }
        .breadcrumb-bar { background:var(--white); border-bottom:1px solid var(--border); padding:10px 24px; }
        .breadcrumb-bar .inner { max-width:1240px; margin:auto; font-size:12px; color:var(--text-muted); }
        .breadcrumb-bar a { color:var(--maroon); text-decoration:none; }
        .breadcrumb-bar a:hover { text-decoration:underline; }

        /* SECTION */
        .section-wrap { max-width:1240px; margin:auto; padding:48px 24px 0; }
        .section-header { display:flex; align-items:flex-end; justify-content:space-between; margin-bottom:28px; padding-bottom:16px; border-bottom:1px solid var(--border); }
        .section-eyebrow { font-size:10px; letter-spacing:3px; text-transform:uppercase; color:var(--gold); font-weight:600; margin-bottom:6px; }
        .section-title { font-family:'Playfair Display',serif; font-size:26px; font-weight:700; color:var(--charcoal); }
        .see-all-link { font-size:12px; color:var(--maroon); text-decoration:none; font-weight:600; letter-spacing:0.5px; text-transform:uppercase; display:flex; align-items:center; gap:4px; }
        .see-all-link:hover { color:var(--maroon-dark); }

        /* PRODUCT CARD */
        .products-grid { max-width:1240px; margin:auto; padding:0 24px 56px; display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:24px; }
        .product-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; transition:box-shadow 0.25s,transform 0.25s; }
        .product-card:hover { box-shadow:var(--shadow-md); transform:translateY(-3px); }
        .card-img-wrap { position:relative; height:300px; overflow:hidden; background:var(--cream); }
        .card-img-wrap img { width:100%; height:100%; object-fit:cover; transition:transform 0.4s ease; }
        .product-card:hover .card-img-wrap img { transform:scale(1.04); }
        .card-badge { position:absolute; top:12px; left:12px; background:var(--maroon); color:var(--white); font-size:9px; font-weight:600; padding:4px 10px; border-radius:4px; letter-spacing:0.8px; text-transform:uppercase; }
        .card-badge.sale { background:var(--gold); color:var(--charcoal); }
        .card-wish { position:absolute; top:12px; right:12px; width:32px; height:32px; background:var(--white); border:none; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:16px; color:var(--text-muted); cursor:pointer; box-shadow:var(--shadow-sm); transition:color 0.2s; }
        .card-wish:hover { color:var(--maroon); }
        .card-body { padding:16px 18px 18px; }
        .card-fabric { font-size:10px; letter-spacing:1.5px; text-transform:uppercase; color:var(--text-muted); margin-bottom:5px; }
        .card-name { font-family:'Playfair Display',serif; font-size:16px; font-weight:500; color:var(--charcoal); margin-bottom:10px; line-height:1.3; }
        .card-name a { color:inherit; text-decoration:none; }
        .card-name a:hover { color:var(--maroon); }
        .card-footer-row { display:flex; align-items:center; justify-content:space-between; }
        .card-price { font-size:17px; font-weight:600; color:var(--maroon); }
        .card-price .currency { font-size:11px; font-weight:400; color:var(--text-muted); margin-right:2px; }
        .card-actions { display:flex; gap:8px; }
        .btn-cart { background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:8px 14px; font-size:12px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:5px; transition:background 0.2s; letter-spacing:0.3px; }
        .btn-cart:hover { background:var(--maroon-dark); }
        .btn-details { border:1px solid var(--border); background:var(--white); color:var(--text-mid); border-radius:6px; padding:8px 12px; font-size:12px; font-weight:500; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; transition:border-color 0.2s,color 0.2s; }
        .btn-details:hover { border-color:var(--maroon); color:var(--maroon); }

        /* FORM STYLES */
        .form-card { background:var(--white); border:1px solid var(--border); border-radius:var(--radius); padding:36px; box-shadow:var(--shadow-sm); }
        .form-label { font-size:12px; font-weight:600; color:var(--charcoal); letter-spacing:0.5px; text-transform:uppercase; margin-bottom:6px; }
        .form-control, .form-select { border:1px solid var(--border); border-radius:6px; padding:10px 14px; font-size:14px; color:var(--charcoal); background:var(--ivory); transition:border-color 0.2s; }
        .form-control:focus, .form-select:focus { border-color:var(--maroon); box-shadow:0 0 0 3px rgba(123,26,26,0.08); outline:none; }
        .btn-primary-maroon { background:var(--maroon); color:var(--white); border:none; border-radius:6px; padding:12px 28px; font-size:13px; font-weight:600; cursor:pointer; letter-spacing:0.4px; transition:background 0.2s; width:100%; }
        .btn-primary-maroon:hover { background:var(--maroon-dark); }
        .btn-gold { background:var(--gold); color:var(--charcoal); border:none; border-radius:6px; padding:12px 28px; font-size:13px; font-weight:700; cursor:pointer; letter-spacing:0.4px; transition:background 0.2s; }
        .btn-gold:hover { background:var(--gold-light); }

        /* EMPTY STATE */
        .empty-state { text-align:center; padding:64px 24px; color:var(--text-muted); }
        .empty-state i { font-size:48px; margin-bottom:14px; display:block; }
        .empty-state h3 { font-family:'Playfair Display',serif; font-size:22px; color:var(--charcoal); margin-bottom:8px; }
        .empty-state p { font-size:14px; margin-bottom:20px; }
        .empty-state a { background:var(--maroon); color:var(--white); padding:10px 24px; border-radius:6px; text-decoration:none; font-size:13px; font-weight:600; }

        /* WHATSAPP FLOAT */
        .wa-float { position:fixed; bottom:28px; right:28px; background:#25D366; width:54px; height:54px; border-radius:50%; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 16px rgba(37,211,102,0.45); z-index:999; text-decoration:none; transition:transform 0.2s; }
        .wa-float:hover { transform:scale(1.08); }
        .wa-float i { font-size:26px; color:#fff; }

        /* FOOTER */
        .footer-main { background:var(--charcoal); padding:48px 24px 24px; color:rgba(255,255,255,0.7); }
        .footer-inner { max-width:1240px; margin:auto; display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:40px; margin-bottom:32px; }
        .footer-brand-name { font-family:'Playfair Display',serif; font-size:20px; color:var(--white); margin-bottom:10px; }
        .footer-brand-name span { color:var(--gold); }
        .footer-desc { font-size:13px; line-height:1.7; margin-bottom:18px; }
        .footer-social { display:flex; gap:12px; }
        .footer-social a { width:34px; height:34px; background:rgba(255,255,255,0.08); border-radius:6px; display:flex; align-items:center; justify-content:center; color:rgba(255,255,255,0.7); font-size:16px; text-decoration:none; transition:background 0.2s,color 0.2s; }
        .footer-social a:hover { background:var(--gold); color:var(--charcoal); }
        .footer-col h4 { font-size:11px; letter-spacing:2px; text-transform:uppercase; color:var(--gold); font-weight:600; margin-bottom:16px; }
        .footer-col ul { list-style:none; }
        .footer-col ul li { margin-bottom:10px; }
        .footer-col ul li a { font-size:13px; color:rgba(255,255,255,0.65); text-decoration:none; transition:color 0.2s; }
        .footer-col ul li a:hover { color:var(--gold-light); }
        .footer-bottom { max-width:1240px; margin:auto; border-top:1px solid rgba(255,255,255,0.1); padding-top:20px; display:flex; justify-content:space-between; align-items:center; font-size:12px; }
        .footer-bottom a { color:var(--gold-light); text-decoration:none; }

        @media (max-width:768px) {
            .nav-links { display:none; }
            .footer-inner { grid-template-columns:1fr 1fr; }
            .trust-strip-inner { gap:20px; }
            .page-hero h1 { font-size:28px; }
        }
    </style>
</head>
<body>
