<?php
// Shared Navbar — include after head.php
// Set $active_page before including (e.g. 'shop', 'home', 'contact')
$active_page = $active_page ?? 'home';
?>

<!-- TOAST MESSAGES -->
<?php if (isset($message)): ?>
    <?php foreach ($message as $msg): ?>
        <div class="toast-msg" id="toast-msg">
            <i class="bi bi-check-circle-fill"></i>
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- NAVBAR -->
<nav class="navbar-main">
    <div class="navbar-inner">
        <a href="index.php" class="brand-logo">AL-Ghuse <span>Tailor</span></a>

        <ul class="nav-links">
            <li><a href="index.php"              class="<?= $active_page==='home'?'active':'' ?>">Home</a></li>
            <li><a href="shop.php"               class="<?= $active_page==='shop'?'active':'' ?>">Shop</a></li>
            <li><a href="shop.php?cat=bridal"    class="<?= $active_page==='bridal'?'active':'' ?>">Bridal</a></li>
            <li><a href="shop.php?cat=formal"    class="<?= $active_page==='formal'?'active':'' ?>">Formal</a></li>
            <li><a href="custom_stitching.php"   class="<?= $active_page==='custom'?'active':'' ?>">Custom Stitching</a></li>
            <li><a href="contact-us.php"         class="<?= $active_page==='contact'?'active':'' ?>">Contact</a></li>
        </ul>

        <div class="nav-actions">
            <button class="nav-icon-btn" onclick="location.href='search_suits.php'" title="Search">
                <i class="bi bi-search"></i>
            </button>
            <button class="nav-icon-btn" onclick="location.href='wishlist.php'" title="Wishlist">
                <i class="bi bi-heart"></i>
            </button>
            <button class="nav-icon-btn" onclick="location.href='cart.php'" title="Cart">
                <i class="bi bi-bag"></i>
                <?php
                if ($user_id) {
                    $cart_count = mysqli_num_rows($conn->query("SELECT * FROM cart WHERE user_id='$user_id'"));
                    if ($cart_count > 0) echo "<span class='cart-badge'>$cart_count</span>";
                }
                ?>
            </button>
            <?php if ($user_id): ?>
                <a href="my_account.php" class="btn-login-nav">My Account</a>
            <?php else: ?>
                <a href="login.php" class="btn-login-nav">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- TRUST STRIP -->
<div class="trust-strip">
    <div class="trust-strip-inner">
        <span class="trust-item"><i class="bi bi-truck"></i> Karachi-wide delivery</span>
        <span class="trust-item"><i class="bi bi-patch-check"></i> Genuine fabric guarantee</span>
        <span class="trust-item"><i class="bi bi-cash-coin"></i> Cash on Delivery available</span>
        <span class="trust-item"><i class="bi bi-arrow-counterclockwise"></i> Easy 7-day returns</span>
        <span class="trust-item"><i class="bi bi-whatsapp"></i> WhatsApp order support</span>
    </div>
</div>
