<!-- FOOTER -->
<footer class="footer-main">
    <div class="footer-inner">
        <div>
            <div class="footer-brand-name">AL-Ghuse <span>Tailor</span></div>
            <p class="footer-desc">
                At the heart of Karachi, at your service.<br>
                Premium fabric, perfect stitching, and your satisfaction matter most to us.
            </p>
            <div class="footer-social">
                <a href="#" title="Facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" title="Instagram"><i class="bi bi-instagram"></i></a>
                <a href="https://wa.me/92708659593" title="WhatsApp"><i class="bi bi-whatsapp"></i></a>
                <a href="#" title="TikTok"><i class="bi bi-tiktok"></i></a>
            </div>
        </div>
        <div class="footer-col">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="shop.php">All Products</a></li>
                <li><a href="shop.php?cat=Bridal">Bridal</a></li>
                <li><a href="shop.php?cat=Formal">Formal</a></li>
                <li><a href="shop.php?cat=Unstitched">Unstitched</a></li>
                <li><a href="sale.php">Sale</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Help</h4>
            <ul>
                <li><a href="size_guide.php">Size Guide</a></li>
                <li><a href="track_order.php">Track Order</a></li>
                <li><a href="returns.php">Returns Policy</a></li>
                <li><a href="faq.php">FAQs</a></li>
                <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Contact</h4>
            <ul>
                <li><a href="tel:+9270-8659593"><i class="bi bi-telephone"></i> 0370-8659593</a></li>
                <li><a href="https://wa.me/9270-8659593"><i class="bi bi-whatsapp"></i> WhatsApp</a></li>
                <li><a href="mailto:info@alghuse.pk"><i class="bi bi-envelope"></i> info@alghuse.pk</a></li>
                <li><a href="contact-us.php"><i class="bi bi-geo-alt"></i> Karachi, Pakistan</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <span>© <?= date('Y') ?> AL-Ghuse Tailor. All rights reserved.</span>
        <span><a href="privacy.php">Privacy Policy</a> · <a href="terms.php">Terms</a></span>
    </div>
</footer>

<!-- WHATSAPP FLOAT -->
<a href="https://wa.me/92708659593?text=Hello!%20I%20would%20like%20to%20place%20an%20order"
   class="wa-float" target="_blank" title="Order via WhatsApp">
    <i class="bi bi-whatsapp"></i>
</a>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Auto hide toast
    setTimeout(() => {
        const t = document.getElementById('toast-msg');
        if (t) { t.style.opacity='0'; t.style.transition='opacity 0.5s'; setTimeout(()=>t.remove(),500); }
    }, 5000);

    // Wishlist heart toggle
    document.querySelectorAll('.card-wish').forEach(btn => {
        btn.addEventListener('click', () => {
            const icon = btn.querySelector('i');
            if (icon.classList.contains('bi-heart')) {
                icon.classList.replace('bi-heart','bi-heart-fill');
                btn.style.color = '#7B1A1A';
            } else {
                icon.classList.replace('bi-heart-fill','bi-heart');
                btn.style.color = '';
            }
        });
    });
</script>
</body>
</html>
