<?php
include 'config.php';
error_reporting(0);
session_start();
$user_id = $_SESSION['user_id'] ?? null;

// Add to cart
if (isset($_POST['add_to_cart'])) {
    if (!$user_id) { $message[] = 'Please login first'; }
    else {
        $sid = (int)$_POST['suit_id'];
        $check = $conn->query("SELECT * FROM cart WHERE suit_id='$sid' AND user_id='$user_id'");
        if (mysqli_num_rows($check) === 0) {
            $name  = $conn->real_escape_string($_POST['suit_name']);
            $price = (float)$_POST['suit_price'];
            $image = $conn->real_escape_string($_POST['suit_image']);
            $total = $price;
            $conn->query("INSERT INTO cart (user_id,suit_id,name,price,image,quantity,total) VALUES ('$user_id','$sid','$name','$price','$image','1','$total')");
            $message[] = 'Added to cart!';
        } else { $message[] = 'Already in cart'; }
    }
}

$q      = $conn->real_escape_string(trim($_GET['q'] ?? ''));
$cat    = $conn->real_escape_string($_GET['cat'] ?? '');
$suits  = null;
$count  = 0;

if ($q || $cat) {
    $where = "WHERE 1=1";
    if ($q)   $where .= " AND (name LIKE '%$q%' OR description LIKE '%$q%' OR fabric LIKE '%$q%' OR category LIKE '%$q%')";
    if ($cat) $where .= " AND category='$cat'";
    $suits = $conn->query("SELECT * FROM suits_info $where ORDER BY date DESC LIMIT 40");
    $count = mysqli_num_rows($suits);
}

$page_title  = $q ? "Search: $q" : 'Search';
$active_page = '';
include 'includes/head.php';
?>
<style>
    .search-hero { background:var(--maroon); padding:56px 24px; text-align:center; }
    .search-hero h1 { font-family:'Playfair Display',serif; font-size:36px; color:var(--white); margin-bottom:24px; }
    .search-box-wrap { max-width:600px; margin:0 auto; position:relative; }
    .search-big-input { width:100%; border:none; border-radius:50px; padding:16px 60px 16px 24px; font-size:15px; color:var(--charcoal); font-family:'Inter',sans-serif; box-shadow:var(--shadow-md); }
    .search-big-input:focus { outline:none; }
    .search-big-btn { position:absolute; right:6px; top:50%; transform:translateY(-50%); background:var(--maroon); color:var(--white); border:none; border-radius:50px; padding:10px 24px; font-size:13px; font-weight:600; cursor:pointer; transition:background 0.2s; }
    .search-big-btn:hover { background:var(--maroon-dark); }
    .search-suggestions { display:flex; gap:10px; justify-content:center; margin-top:16px; flex-wrap:wrap; }
    .search-tag { background:rgba(255,255,255,0.15); color:var(--white); font-size:12px; padding:5px 14px; border-radius:20px; text-decoration:none; transition:background 0.2s; }
    .search-tag:hover { background:rgba(255,255,255,0.25); color:var(--white); }
    .search-results-wrap { max-width:1240px; margin:auto; padding:40px 24px 64px; }
    .search-result-info { margin-bottom:24px; padding-bottom:14px; border-bottom:1px solid var(--border); }
    .search-result-info h3 { font-family:'Playfair Display',serif; font-size:22px; color:var(--charcoal); }
    .search-result-info p { font-size:13px; color:var(--text-muted); margin-top:4px; }
    .search-highlight { color:var(--maroon); font-weight:700; }
    .results-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:24px; }
    .no-results { text-align:center; padding:64px 24px; }
    .no-results i { font-size:48px; color:var(--text-muted); display:block; margin-bottom:16px; }
    .no-results h3 { font-family:'Playfair Display',serif; font-size:22px; color:var(--charcoal); margin-bottom:8px; }
    .no-results p { font-size:14px; color:var(--text-muted); }
</style>

<?php include 'includes/navbar.php'; ?>

<!-- SEARCH HERO -->
<div class="search-hero">
    <h1>What Are You Looking For?</h1>
    <form method="GET" action="">
        <div class="search-box-wrap">
            <input type="text" name="q" class="search-big-input"
                   placeholder="Suit name, fabric or category..."
                   value="<?= htmlspecialchars($q) ?>" autofocus>
            <button type="submit" class="search-big-btn">
                <i class="bi bi-search me-1"></i> Search
            </button>
        </div>
    </form>
    <div class="search-suggestions">
        <span style="color:rgba(255,255,255,0.6);font-size:12px;margin-top:2px;">Popular:</span>
        <?php foreach (['Bridal','Lawn','Chiffon','Formal','Kids','Unstitched'] as $sug): ?>
        <a href="search_suits.php?q=<?= urlencode($sug) ?>" class="search-tag"><?= $sug ?></a>
        <?php endforeach; ?>
    </div>
</div>

<div class="search-results-wrap">
    <?php if ($suits !== null): ?>
    <div class="search-result-info">
        <?php if ($count > 0): ?>
        <h3><?= $count ?> suit<?= $count > 1 ? 's' : '' ?> mile</h3>
        <?php if ($q): ?>
        <p>Search results for: <span class="search-highlight">"<?= htmlspecialchars($q) ?>"</span></p>
        <?php endif; ?>
        <?php else: ?>
        <h3>No results found</h3>
        <p>"<?= htmlspecialchars($q) ?>" no suits found for</p>
        <?php endif; ?>
    </div>

    <?php if ($count > 0): ?>
    <div class="results-grid">
        <?php while ($s = mysqli_fetch_assoc($suits)): ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <span class="card-badge"><?= htmlspecialchars($s['category']) ?></span>
                <button class="card-wish"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? '') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price"><span class="currency">PKR</span><?= number_format($s['price']) ?></div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <div class="no-results">
        <i class="bi bi-search"></i>
        <h3>No results found</h3>
        <p>Try a different keyword or browse our collection</p>
        <a href="shop.php" class="btn-cart mt-3" style="display:inline-flex;text-decoration:none;padding:12px 24px;">
            <i class="bi bi-grid me-2"></i> View All Products
        </a>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <!-- Before any search — show categories -->
    <div>
        <div class="section-header">
            <div>
                <p class="section-eyebrow">Browse By</p>
                <h2 class="section-title">Categories</h2>
            </div>
        </div>
        <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr)); gap:16px; margin-bottom:48px;">
            <?php
            $cats = [
                ['name'=>'Bridal',     'icon'=>'bi-gem',          'color'=>'#7B1A1A'],
                ['name'=>'Formal',     'icon'=>'bi-suit-heart',   'color'=>'#1e40af'],
                ['name'=>'Casual',     'icon'=>'bi-sun',          'color'=>'#92400e'],
                ['name'=>'Unstitched', 'icon'=>'bi-scissors',     'color'=>'#065f46'],
                ['name'=>'Kids',       'icon'=>'bi-balloon-heart','color'=>'#6d28d9'],
            ];
            foreach ($cats as $c):
            ?>
            <a href="search_suits.php?cat=<?= $c['name'] ?>"
               style="background:var(--white); border:1px solid var(--border); border-radius:var(--radius); padding:24px; text-align:center; text-decoration:none; transition:all 0.2s; display:block;"
               onmouseover="this.style.borderColor='<?= $c['color'] ?>'; this.style.transform='translateY(-3px)'"
               onmouseout="this.style.borderColor='var(--border)'; this.style.transform=''">
                <i class="bi <?= $c['icon'] ?>" style="font-size:32px; color:<?= $c['color'] ?>; display:block; margin-bottom:10px;"></i>
                <span style="font-size:13px; font-weight:600; color:var(--charcoal);"><?= $c['name'] ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
