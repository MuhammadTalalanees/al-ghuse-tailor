<?php
include 'config.php';
error_reporting(0);
session_start();

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (isset($_SESSION['user_id']) && $_SESSION['user_type'] === 'admin') {
    header('location: admin/Admin_index.php');
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;

if (isset($_POST['add_to_cart'])) {
    if (!isset($user_id)) {
        $message[] = 'Please login first to add this suit to your cart';
    } else {
        $suit_name     = $_POST['suit_name'];
        $suit_id       = $_POST['suit_id'];
        $suit_image    = $_POST['suit_image'];
        $suit_price    = $_POST['suit_price'];
        $suit_quantity = '1';
        $total_price   = number_format($suit_price * $suit_quantity);

        $check = $conn->query("SELECT * FROM cart WHERE suit_id='$suit_id' AND user_id='$user_id'") or die('Query failed');

        if (mysqli_num_rows($check) > 0) {
            $message[] = 'This suit is already in your cart';
        } else {
            $conn->query("INSERT INTO cart (user_id, suit_id, name, price, image, quantity, total)
                          VALUES ('$user_id','$suit_id','$suit_name','$suit_price','$suit_image','$suit_quantity','$total_price')")
                 or die('Add to cart query failed');
            $message[] = 'Suit added to cart!';
            header('location:index.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AL-Ghuse Tailor — Kameez Shalwar Collection</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

    <style>
        /* ===== DESIGN TOKENS ===== */
        :root {
            --ivory:      #FAF7F2;
            --cream:      #F3EDE3;
            --maroon:     #7B1A1A;
            --maroon-dark:#5C1010;
            --maroon-light:#9E2A2A;
            --gold:       #C9A84C;
            --gold-light: #E5C96C;
            --charcoal:   #2C2C2A;
            --text-mid:   #5A5751;
            --text-muted: #9A9590;
            --white:      #FFFFFF;
            --border:     #E8E2D9;
            --shadow-sm:  0 1px 4px rgba(44,44,42,0.08);
            --shadow-md:  0 4px 20px rgba(44,44,42,0.12);
            --radius:     10px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--ivory);
            color: var(--charcoal);
        }

        /* ===== TOAST MESSAGE ===== */
        .toast-msg {
            position: fixed;
            top: 80px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--white);
            border: 1.5px solid var(--gold);
            border-radius: var(--radius);
            padding: 12px 24px;
            font-size: 14px;
            color: var(--maroon);
            font-weight: 500;
            box-shadow: var(--shadow-md);
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateX(-50%) translateY(-10px); }
            to   { opacity: 1; transform: translateX(-50%) translateY(0); }
        }

        /* ===== NAVBAR ===== */
        .navbar-main {
            background: var(--white);
            border-bottom: 1px solid var(--border);
            padding: 0 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: var(--shadow-sm);
        }
        .navbar-inner {
            max-width: 1240px;
            margin: auto;
            padding: 0 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 68px;
        }
        .brand-logo {
            font-family: 'Playfair Display', serif;
            font-size: 22px;
            font-weight: 700;
            color: var(--maroon);
            text-decoration: none;
            letter-spacing: 0.3px;
        }
        .brand-logo span {
            color: var(--gold);
        }
        .nav-links {
            display: flex;
            gap: 28px;
            list-style: none;
        }
        .nav-links a {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-mid);
            text-decoration: none;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            transition: color 0.2s;
        }
        .nav-links a:hover { color: var(--maroon); }
        .nav-links a.active { color: var(--maroon); border-bottom: 2px solid var(--gold); padding-bottom: 2px; }
        .nav-actions {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .nav-icon-btn {
            background: none;
            border: none;
            font-size: 20px;
            color: var(--text-mid);
            cursor: pointer;
            position: relative;
            transition: color 0.2s;
        }
        .nav-icon-btn:hover { color: var(--maroon); }
        .cart-badge {
            position: absolute;
            top: -4px;
            right: -6px;
            background: var(--gold);
            color: var(--white);
            font-size: 9px;
            font-weight: 700;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .btn-login-nav {
            background: var(--maroon);
            color: var(--white);
            font-size: 12px;
            font-weight: 600;
            padding: 8px 18px;
            border-radius: 6px;
            text-decoration: none;
            letter-spacing: 0.4px;
            transition: background 0.2s;
        }
        .btn-login-nav:hover {
            background: var(--maroon-dark);
            color: var(--white);
        }

        /* ===== HERO / CAROUSEL ===== */
        .hero-section {
            position: relative;
            height: 520px;
            overflow: hidden;
            background: var(--charcoal);
        }
        .hero-section video {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.6;
        }
        .hero-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to right, rgba(123,26,26,0.75) 0%, rgba(44,44,42,0.25) 100%);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            justify-content: center;
            padding: 0 80px;
        }
        .hero-eyebrow {
            font-size: 11px;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: var(--gold-light);
            margin-bottom: 14px;
            font-weight: 500;
        }
        .hero-title {
            font-family: 'Playfair Display', serif;
            font-size: 52px;
            font-weight: 700;
            color: var(--white);
            line-height: 1.15;
            margin-bottom: 18px;
            max-width: 540px;
        }
        .hero-title em {
            color: var(--gold-light);
            font-style: normal;
        }
        .hero-sub {
            font-size: 15px;
            color: rgba(255,255,255,0.8);
            margin-bottom: 32px;
            font-weight: 300;
        }
        .hero-btns {
            display: flex;
            gap: 14px;
        }
        .btn-hero-primary {
            background: var(--gold);
            color: var(--charcoal);
            font-size: 13px;
            font-weight: 600;
            padding: 13px 28px;
            border-radius: 6px;
            text-decoration: none;
            letter-spacing: 0.5px;
            transition: background 0.2s;
        }
        .btn-hero-primary:hover { background: var(--gold-light); color: var(--charcoal); }
        .btn-hero-ghost {
            background: transparent;
            color: var(--white);
            font-size: 13px;
            font-weight: 500;
            padding: 13px 28px;
            border-radius: 6px;
            border: 1.5px solid rgba(255,255,255,0.5);
            text-decoration: none;
            letter-spacing: 0.5px;
            transition: border-color 0.2s;
        }
        .btn-hero-ghost:hover { border-color: var(--white); color: var(--white); }

        /* ===== TRUST STRIP ===== */
        .trust-strip {
            background: var(--maroon);
            padding: 14px 24px;
        }
        .trust-strip-inner {
            max-width: 1240px;
            margin: auto;
            display: flex;
            justify-content: center;
            gap: 48px;
            flex-wrap: wrap;
        }
        .trust-item {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--white);
            font-size: 12px;
            font-weight: 500;
            letter-spacing: 0.4px;
        }
        .trust-item i { color: var(--gold-light); font-size: 16px; }

        /* ===== CATEGORY NAV ===== */
        .cat-nav {
            background: var(--white);
            border-bottom: 1px solid var(--border);
            padding: 18px 24px;
        }
        .cat-nav-inner {
            max-width: 1240px;
            margin: auto;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .cat-pill {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 8px 18px;
            border-radius: 50px;
            border: 1px solid var(--border);
            font-size: 12px;
            font-weight: 500;
            color: var(--text-mid);
            text-decoration: none;
            background: var(--white);
            transition: all 0.2s;
            letter-spacing: 0.3px;
        }
        .cat-pill:hover,
        .cat-pill.active {
            background: var(--maroon);
            color: var(--white);
            border-color: var(--maroon);
        }
        .cat-pill i { font-size: 14px; }

        /* ===== SECTION HEADER ===== */
        .section-wrap {
            max-width: 1240px;
            margin: auto;
            padding: 56px 24px 0;
        }
        .section-header {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            margin-bottom: 32px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }
        .section-eyebrow {
            font-size: 10px;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: var(--gold);
            font-weight: 600;
            margin-bottom: 6px;
        }
        .section-title {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 700;
            color: var(--charcoal);
        }
        .see-all-link {
            font-size: 12px;
            color: var(--maroon);
            text-decoration: none;
            font-weight: 600;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .see-all-link:hover { color: var(--maroon-dark); }

        /* ===== PRODUCT GRID ===== */
        .products-grid {
            max-width: 1240px;
            margin: auto;
            padding: 0 24px 56px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 24px;
        }

        /* ===== PRODUCT CARD ===== */
        .product-card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            overflow: hidden;
            transition: box-shadow 0.25s, transform 0.25s;
        }
        .product-card:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-3px);
        }
        .card-img-wrap {
            position: relative;
            height: 300px;
            overflow: hidden;
            background: var(--cream);
        }
        .card-img-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.4s ease;
        }
        .product-card:hover .card-img-wrap img {
            transform: scale(1.04);
        }
        .card-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            background: var(--maroon);
            color: var(--white);
            font-size: 9px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 4px;
            letter-spacing: 0.8px;
            text-transform: uppercase;
        }
        .card-badge.sale { background: var(--gold); color: var(--charcoal); }
        .card-wish {
            position: absolute;
            top: 12px;
            right: 12px;
            width: 32px;
            height: 32px;
            background: var(--white);
            border: none;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            color: var(--text-muted);
            cursor: pointer;
            box-shadow: var(--shadow-sm);
            transition: color 0.2s;
        }
        .card-wish:hover { color: var(--maroon); }
        .card-body {
            padding: 16px 18px 18px;
        }
        .card-fabric {
            font-size: 10px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: var(--text-muted);
            margin-bottom: 5px;
        }
        .card-name {
            font-family: 'Playfair Display', serif;
            font-size: 16px;
            font-weight: 500;
            color: var(--charcoal);
            margin-bottom: 10px;
            line-height: 1.3;
        }
        .card-name a {
            color: inherit;
            text-decoration: none;
        }
        .card-name a:hover { color: var(--maroon); }
        .card-footer-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .card-price {
            font-size: 17px;
            font-weight: 600;
            color: var(--maroon);
        }
        .card-price .currency {
            font-size: 11px;
            font-weight: 400;
            color: var(--text-muted);
            margin-right: 2px;
        }
        .card-actions {
            display: flex;
            gap: 8px;
        }
        .btn-cart {
            background: var(--maroon);
            color: var(--white);
            border: none;
            border-radius: 6px;
            padding: 8px 14px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: background 0.2s;
            letter-spacing: 0.3px;
        }
        .btn-cart:hover { background: var(--maroon-dark); }
        .btn-details {
            border: 1px solid var(--border);
            background: var(--white);
            color: var(--text-mid);
            border-radius: 6px;
            padding: 8px 12px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            transition: border-color 0.2s, color 0.2s;
        }
        .btn-details:hover { border-color: var(--maroon); color: var(--maroon); }

        /* ===== WHATSAPP FLOAT ===== */
        .wa-float {
            position: fixed;
            bottom: 28px;
            right: 28px;
            background: #25D366;
            width: 54px;
            height: 54px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 16px rgba(37,211,102,0.45);
            z-index: 999;
            text-decoration: none;
            transition: transform 0.2s;
        }
        .wa-float:hover { transform: scale(1.08); }
        .wa-float i { font-size: 26px; color: #fff; }

        /* ===== CUSTOM STITCHING BANNER ===== */
        .custom-banner {
            background: var(--maroon);
            background-image: repeating-linear-gradient(
                45deg,
                transparent,
                transparent 40px,
                rgba(255,255,255,0.025) 40px,
                rgba(255,255,255,0.025) 80px
            );
            padding: 56px 24px;
            text-align: center;
        }
        .custom-banner-inner { max-width: 640px; margin: auto; }
        .custom-banner h2 {
            font-family: 'Playfair Display', serif;
            font-size: 34px;
            color: var(--white);
            margin-bottom: 12px;
        }
        .custom-banner h2 span { color: var(--gold-light); }
        .custom-banner p {
            font-size: 15px;
            color: rgba(255,255,255,0.75);
            margin-bottom: 28px;
            line-height: 1.7;
        }
        .btn-custom {
            background: var(--gold);
            color: var(--charcoal);
            font-size: 13px;
            font-weight: 700;
            padding: 13px 32px;
            border-radius: 6px;
            text-decoration: none;
            letter-spacing: 0.5px;
            display: inline-block;
            transition: background 0.2s;
        }
        .btn-custom:hover { background: var(--gold-light); color: var(--charcoal); }

        /* ===== FOOTER ===== */
        .footer-main {
            background: var(--charcoal);
            padding: 48px 24px 24px;
            color: rgba(255,255,255,0.7);
        }
        .footer-inner {
            max-width: 1240px;
            margin: auto;
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 40px;
            margin-bottom: 32px;
        }
        .footer-brand-name {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            color: var(--white);
            margin-bottom: 10px;
        }
        .footer-brand-name span { color: var(--gold); }
        .footer-desc {
            font-size: 13px;
            line-height: 1.7;
            margin-bottom: 18px;
        }
        .footer-social { display: flex; gap: 12px; }
        .footer-social a {
            width: 34px;
            height: 34px;
            background: rgba(255,255,255,0.08);
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: rgba(255,255,255,0.7);
            font-size: 16px;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
        }
        .footer-social a:hover { background: var(--gold); color: var(--charcoal); }
        .footer-col h4 {
            font-size: 11px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--gold);
            font-weight: 600;
            margin-bottom: 16px;
        }
        .footer-col ul { list-style: none; }
        .footer-col ul li { margin-bottom: 10px; }
        .footer-col ul li a {
            font-size: 13px;
            color: rgba(255,255,255,0.65);
            text-decoration: none;
            transition: color 0.2s;
        }
        .footer-col ul li a:hover { color: var(--gold-light); }
        .footer-bottom {
            max-width: 1240px;
            margin: auto;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12px;
        }
        .footer-bottom a { color: var(--gold-light); text-decoration: none; }

        /* ===== EMPTY STATE ===== */
        .empty-state {
            text-align: center;
            padding: 48px 24px;
            color: var(--text-muted);
        }
        .empty-state i { font-size: 40px; margin-bottom: 12px; display: block; }
        .empty-state p { font-size: 14px; }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .hero-overlay { padding: 0 28px; }
            .hero-title { font-size: 32px; }
            .nav-links { display: none; }
            .footer-inner { grid-template-columns: 1fr 1fr; }
            .trust-strip-inner { gap: 20px; }
        }
    </style>
</head>
<body>

<!-- ===== TOAST MESSAGES ===== -->
<?php if (isset($message)): ?>
    <?php foreach ($message as $msg): ?>
        <div class="toast-msg" id="toast-msg">
            <i class="bi bi-check-circle-fill"></i>
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- ===== NAVBAR ===== -->
<nav class="navbar-main">
    <div class="navbar-inner">
        <a href="index.php" class="brand-logo">AL-Ghuse <span>Tailor</span></a>

        <ul class="nav-links">
            <li><a href="index.php" class="active">Home</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li><a href="#bridal">Bridal</a></li>
            <li><a href="#formal">Formal</a></li>
            <li><a href="#unstitched">Unstitched</a></li>
            <li><a href="custom_stitching.php">Custom Stitching</a></li>
            <li><a href="contact-us.php">Contact</a></li>
        </ul>

        <div class="nav-actions">
            <button class="nav-icon-btn" onclick="location.href='search_suits.php'" title="Search">
                <i class="bi bi-search"></i>
            </button>
            <button class="nav-icon-btn" onclick="location.href='wishlist.php'" title="Wishlist">
                <i class="bi bi-heart"></i>
            </button>
            <button class="nav-icon-btn" onclick="location.href='cart.php'" title="Cart">
                <i class="bi bi-bag"></i>
                <?php
                if ($user_id) {
                    $cart_count = mysqli_num_rows($conn->query("SELECT * FROM cart WHERE user_id='$user_id'"));
                    if ($cart_count > 0) echo "<span class='cart-badge'>$cart_count</span>";
                }
                ?>
            </button>
            <?php if ($user_id): ?>
                <a href="my_account.php" class="btn-login-nav">My Account</a>
            <?php else: ?>
                <a href="login.php" class="btn-login-nav">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- ===== HERO ===== -->
<section class="hero-section">
    <video autoplay muted loop playsinline>
        <source src="videos/hero.mp4" type="video/mp4">
    </video>
    <div class="hero-overlay">
        <p class="hero-eyebrow">Eid Collection 2025</p>
        <h1 class="hero-title">Every suit tells<br><em>a story</em></h1>
        <p class="hero-sub">Handcrafted kameez shalwar — the pride of Karachi</p>
        <div class="hero-btns">
            <a href="shop.php" class="btn-hero-primary">View Collection</a>
            <a href="custom_stitching.php" class="btn-hero-ghost">Custom Stitching</a>
        </div>
    </div>
</section>

<!-- ===== TRUST STRIP ===== -->
<div class="trust-strip">
    <div class="trust-strip-inner">
        <span class="trust-item"><i class="bi bi-truck"></i> Karachi-wide delivery</span>
        <span class="trust-item"><i class="bi bi-patch-check"></i> Genuine fabric guarantee</span>
        <span class="trust-item"><i class="bi bi-cash-coin"></i> Cash on Delivery available</span>
        <span class="trust-item"><i class="bi bi-arrow-counterclockwise"></i> Easy 7-day returns</span>
        <span class="trust-item"><i class="bi bi-whatsapp"></i> WhatsApp order support</span>
    </div>
</div>

<!-- ===== CATEGORY PILLS ===== -->
<div class="cat-nav">
    <div class="cat-nav-inner">
        <a href="#new-arrivals" class="cat-pill active"><i class="bi bi-stars"></i> New Arrivals</a>
        <a href="#bridal" class="cat-pill"><i class="bi bi-gem"></i> Bridal</a>
        <a href="#formal" class="cat-pill"><i class="bi bi-suit-heart"></i> Formal / Party</a>
        <a href="#casual" class="cat-pill"><i class="bi bi-sun"></i> Casual</a>
        <a href="#unstitched" class="cat-pill"><i class="bi bi-scissors"></i> Unstitched</a>
        <a href="#kids" class="cat-pill"><i class="bi bi-balloon-heart"></i> Kids</a>
        <a href="sale.php" class="cat-pill"><i class="bi bi-tag"></i> Sale</a>
    </div>
</div>


<!-- ================================================================ -->
<!-- SECTION 1 — NEW ARRIVALS                                          -->
<!-- ================================================================ -->
<div id="new-arrivals">
    <div class="section-wrap">
        <div class="section-header">
            <div>
                <p class="section-eyebrow">Just In</p>
                <h2 class="section-title">New Arrivals</h2>
            </div>
            <a href="shop.php?sort=new" class="see-all-link">View All <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
    <div class="products-grid">
        <?php
        $suits = $conn->query("SELECT * FROM suits_info ORDER BY date DESC LIMIT 8") or die('Query failed');
        if (mysqli_num_rows($suits) > 0):
            while ($s = mysqli_fetch_assoc($suits)):
        ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <span class="card-badge">New</span>
                <button class="card-wish" title="Add to wishlist"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? 'Lawn') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price">
                        <span class="currency">PKR</span><?= number_format($s['price']) ?>
                    </div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>"
                           class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            endwhile;
        else:
        ?>
        <div class="empty-state" style="grid-column:1/-1">
            <i class="bi bi-bag-x"></i>
            <p>No products have been added yet</p>
        </div>
        <?php endif; ?>
    </div>
</div>


<!-- ================================================================ -->
<!-- CUSTOM STITCHING BANNER                                           -->
<!-- ================================================================ -->
<div class="custom-banner">
    <div class="custom-banner-inner">
        <h2>Your design,<br><span>our stitching</span></h2>
        <p>Bring your own fabric or choose from ours —<br>
           send us your measurements and we'll make the perfect suit for you.</p>
        <a href="custom_stitching.php" class="btn-custom">Place Custom Order</a>
    </div>
</div>


<!-- ================================================================ -->
<!-- SECTION 2 — BRIDAL                                               -->
<!-- ================================================================ -->
<div id="bridal">
    <div class="section-wrap">
        <div class="section-header">
            <div>
                <p class="section-eyebrow">Wedding Collection</p>
                <h2 class="section-title">Bridal & Wedding Wear</h2>
            </div>
            <a href="shop.php?cat=bridal" class="see-all-link">View All <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
    <div class="products-grid">
        <?php
        $suits = $conn->query("SELECT * FROM suits_info WHERE category='Bridal' LIMIT 8") or die('Query failed');
        if (mysqli_num_rows($suits) > 0):
            while ($s = mysqli_fetch_assoc($suits)):
        ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <span class="card-badge">Bridal</span>
                <button class="card-wish" title="Wishlist"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? 'Chiffon') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price"><span class="currency">PKR</span><?= number_format($s['price']) ?></div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            endwhile;
        else: ?>
        <div class="empty-state" style="grid-column:1/-1">
            <i class="bi bi-gem"></i>
            <p>Bridal collection coming soon</p>
        </div>
        <?php endif; ?>
    </div>
</div>


<!-- ================================================================ -->
<!-- SECTION 3 — FORMAL / PARTY WEAR                                  -->
<!-- ================================================================ -->
<div id="formal">
    <div class="section-wrap">
        <div class="section-header">
            <div>
                <p class="section-eyebrow">Events & Occasions</p>
                <h2 class="section-title">Formal & Party Wear</h2>
            </div>
            <a href="shop.php?cat=formal" class="see-all-link">View All <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
    <div class="products-grid">
        <?php
        $suits = $conn->query("SELECT * FROM suits_info WHERE category='Formal' LIMIT 8") or die('Query failed');
        if (mysqli_num_rows($suits) > 0):
            while ($s = mysqli_fetch_assoc($suits)):
        ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <button class="card-wish" title="Wishlist"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? 'Georgette') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price"><span class="currency">PKR</span><?= number_format($s['price']) ?></div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            endwhile;
        else: ?>
        <div class="empty-state" style="grid-column:1/-1">
            <i class="bi bi-suit-heart"></i>
            <p>Formal collection coming soon</p>
        </div>
        <?php endif; ?>
    </div>
</div>


<!-- ================================================================ -->
<!-- SECTION 4 — CASUAL                                               -->
<!-- ================================================================ -->
<div id="casual">
    <div class="section-wrap">
        <div class="section-header">
            <div>
                <p class="section-eyebrow">Everyday Style</p>
                <h2 class="section-title">Casual & Daily Wear</h2>
            </div>
            <a href="shop.php?cat=casual" class="see-all-link">View All <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
    <div class="products-grid">
        <?php
        $suits = $conn->query("SELECT * FROM suits_info WHERE category='Casual' LIMIT 8") or die('Query failed');
        if (mysqli_num_rows($suits) > 0):
            while ($s = mysqli_fetch_assoc($suits)):
        ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <button class="card-wish" title="Wishlist"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? 'Cotton') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price"><span class="currency">PKR</span><?= number_format($s['price']) ?></div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            endwhile;
        else: ?>
        <div class="empty-state" style="grid-column:1/-1">
            <i class="bi bi-sun"></i>
            <p>Casual collection coming soon</p>
        </div>
        <?php endif; ?>
    </div>
</div>


<!-- ================================================================ -->
<!-- SECTION 5 — UNSTITCHED                                           -->
<!-- ================================================================ -->
<div id="unstitched">
    <div class="section-wrap">
        <div class="section-header">
            <div>
                <p class="section-eyebrow">Fabric by Meter</p>
                <h2 class="section-title">Unstitched Collection</h2>
            </div>
            <a href="shop.php?cat=unstitched" class="see-all-link">View All <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
    <div class="products-grid">
        <?php
        $suits = $conn->query("SELECT * FROM suits_info WHERE category='Unstitched' LIMIT 8") or die('Query failed');
        if (mysqli_num_rows($suits) > 0):
            while ($s = mysqli_fetch_assoc($suits)):
        ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <button class="card-wish" title="Wishlist"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? 'Lawn / Khaddar') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price"><span class="currency">PKR</span><?= number_format($s['price']) ?> <small style="font-size:10px;color:var(--text-muted)">/set</small></div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            endwhile;
        else: ?>
        <div class="empty-state" style="grid-column:1/-1">
            <i class="bi bi-scissors"></i>
            <p>Unstitched collection coming soon</p>
        </div>
        <?php endif; ?>
    </div>
</div>


<!-- ================================================================ -->
<!-- SECTION 6 — KIDS                                                 -->
<!-- ================================================================ -->
<div id="kids">
    <div class="section-wrap">
        <div class="section-header">
            <div>
                <p class="section-eyebrow">Little Guests</p>
                <h2 class="section-title">Kids Collection</h2>
            </div>
            <a href="shop.php?cat=kids" class="see-all-link">View All <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
    <div class="products-grid">
        <?php
        $suits = $conn->query("SELECT * FROM suits_info WHERE category='Kids' LIMIT 8") or die('Query failed');
        if (mysqli_num_rows($suits) > 0):
            while ($s = mysqli_fetch_assoc($suits)):
        ?>
        <div class="product-card">
            <div class="card-img-wrap">
                <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                    <img src="suits/<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['name']) ?>" loading="lazy">
                </a>
                <button class="card-wish" title="Wishlist"><i class="bi bi-heart"></i></button>
            </div>
            <div class="card-body">
                <p class="card-fabric"><?= htmlspecialchars($s['fabric'] ?? 'Cotton') ?></p>
                <h3 class="card-name">
                    <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>">
                        <?= htmlspecialchars($s['name']) ?>
                    </a>
                </h3>
                <div class="card-footer-row">
                    <div class="card-price"><span class="currency">PKR</span><?= number_format($s['price']) ?></div>
                    <div class="card-actions">
                        <form method="POST" action="" style="display:inline">
                            <input type="hidden" name="suit_name"  value="<?= htmlspecialchars($s['name']) ?>">
                            <input type="hidden" name="suit_id"    value="<?= $s['sid'] ?>">
                            <input type="hidden" name="suit_image" value="<?= htmlspecialchars($s['image']) ?>">
                            <input type="hidden" name="suit_price" value="<?= $s['price'] ?>">
                            <button type="submit" name="add_to_cart" class="btn-cart">
                                <i class="bi bi-bag-plus"></i> Cart
                            </button>
                        </form>
                        <a href="suit_detail.php?id=<?= $s['sid'] ?>&name=<?= urlencode($s['name']) ?>" class="btn-details">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            endwhile;
        else: ?>
        <div class="empty-state" style="grid-column:1/-1">
            <i class="bi bi-balloon-heart"></i>
            <p>Kids collection coming soon</p>
        </div>
        <?php endif; ?>
    </div>
</div>


<!-- ===== FOOTER ===== -->
<footer class="footer-main">
    <div class="footer-inner">
        <div>
            <div class="footer-brand-name">AL-Ghuse <span>Tailor</span></div>
            <p class="footer-desc">
                At the heart of Karachi, at your service.<br>
                Premium fabric, perfect stitching, and your satisfaction matter most to us.
            </p>
            <div class="footer-social">
                <a href="#" title="Facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" title="Instagram"><i class="bi bi-instagram"></i></a>
                <a href="https://wa.me/923001234567" title="WhatsApp"><i class="bi bi-whatsapp"></i></a>
                <a href="#" title="TikTok"><i class="bi bi-tiktok"></i></a>
            </div>
        </div>
        <div class="footer-col">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="shop.php">All Products</a></li>
                <li><a href="shop.php?cat=bridal">Bridal</a></li>
                <li><a href="shop.php?cat=formal">Formal</a></li>
                <li><a href="shop.php?cat=unstitched">Unstitched</a></li>
                <li><a href="sale.php">Sale</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Help</h4>
            <ul>
                <li><a href="size_guide.php">Size Guide</a></li>
                <li><a href="track_order.php">Track Order</a></li>
                <li><a href="returns.php">Returns Policy</a></li>
                <li><a href="faq.php">FAQs</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Contact</h4>
            <ul>
                <li><a href="tel:+923001234567"><i class="bi bi-telephone"></i> 0300-1234567</a></li>
                <li><a href="https://wa.me/923001234567"><i class="bi bi-whatsapp"></i> WhatsApp</a></li>
                <li><a href="mailto:info@alghuse.pk"><i class="bi bi-envelope"></i> info@alghuse.pk</a></li>
                <li><a href="contact.php"><i class="bi bi-geo-alt"></i> Karachi, Pakistan</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <span>© <?= date('Y') ?> AL-Ghuse Tailor. All rights reserved.</span>
        <span><a href="privacy.php">Privacy Policy</a> · <a href="terms.php">Terms</a></span>
    </div>
</footer>

<!-- ===== WHATSAPP FLOAT BUTTON ===== -->
<a href="https://wa.me/923001234567?text=Hello!%20I%20would%20like%20to%20place%20an%20order" 
   class="wa-float" target="_blank" title="Order via WhatsApp">
    <i class="bi bi-whatsapp"></i>
</a>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Auto hide toast after 5 seconds
    setTimeout(() => {
        const t = document.getElementById('toast-msg');
        if (t) { t.style.opacity = '0'; t.style.transition = 'opacity 0.5s'; setTimeout(() => t.remove(), 500); }
    }, 5000);

    // Category pill active state on click
    document.querySelectorAll('.cat-pill').forEach(pill => {
        pill.addEventListener('click', () => {
            document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
            pill.classList.add('active');
        });
    });

    // Wishlist heart toggle
    document.querySelectorAll('.card-wish').forEach(btn => {
        btn.addEventListener('click', () => {
            const icon = btn.querySelector('i');
            if (icon.classList.contains('bi-heart')) {
                icon.classList.replace('bi-heart', 'bi-heart-fill');
                btn.style.color = '#7B1A1A';
            } else {
                icon.classList.replace('bi-heart-fill', 'bi-heart');
                btn.style.color = '';
            }
        });
    });
</script>

</body>
</html>